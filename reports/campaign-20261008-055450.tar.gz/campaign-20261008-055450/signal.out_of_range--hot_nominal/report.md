# Evidence Report - signal.out_of_range--hot_nominal

- **Campaign:** signal.out_of_range
- **Scenario:** hot_nominal
- **Run ID:** signal.out_of_range--hot_nominal
- **Generated:** 2026-10-08T06:10:45Z
- **Verdict:** **PASS**

## Provenance and reproduction

- Case (ASC): [case.asc](../experiments/signal.out_of_range/hot_nominal/case.asc)
- Ground truth: [case.ground_truth.yaml](../experiments/signal.out_of_range/hot_nominal/case.ground_truth.yaml)
- Oracle: [case.oracle.yaml](../experiments/signal.out_of_range/hot_nominal/case.oracle.yaml)
- Experiment: [experiment.yaml](../experiments/signal.out_of_range/hot_nominal/experiment.yaml)
- Logs: `can.log`, `collector.log`, `dfm.log`, `dfm_sovd_bridge.log`, `guardian.log`, `vss_bridge.log`, `collector.out`
- Case path (as recorded): `/app/reports/campaign-20261008-055450/experiments/signal.out_of_range/hot_nominal/case`

## Diagnostic chain

```text
replay (ASC) -> KUKSA CAN Provider -> KUKSA Data Broker -> VSS uProtocol Publisher -> Battery Thermal Guardian -> DFM -> OpenSOVD -> Evidence Collector
```

## Fault catalog

| Fault code | Category | Severity | Description |
|---|---|---|---|
| BatteryOverTempCritical | Hardware | Fatal | Maximum cell temperature reached the configured critical band. |
| BatteryOverTempWarning | Hardware | Warn | Maximum cell temperature entered the configured warning band. |
| BatterySignalStuck | Communication | Error | A battery signal stayed flat while other signals changed (stuck signal). |
| BatteryTempAbsoluteLimit | Hardware | Fatal | Battery temperature outside the absolute physical limits. |
| BatteryTempHotspot | Hardware | Error | Max temperature deviates from average beyond the hotspot limit. |
| BatteryTempRate | Configuration | Error | Temperature changed faster than physically possible. |
| BatteryTempSpread | Hardware | Error | Spread between max and min temperature exceeds the physical limit. |
| BatteryTempStreamStale | Communication | Error | No battery temperature sample received within the missing-packet timeout. |

## Injections

### signal-out_of_range-1 - signal.out_of_range

- Verdict: **PASS** (8/8 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 1000..1500 ms (slot 1000..4500)
- `temp_min` / `out_of_range`: requested duration_samples=5, value=-30; executed [-30, -30, -30, -30, -30]

### signal-out_of_range-2 - signal.out_of_range

- Verdict: **PASS** (10/10 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 4500..5000 ms (slot 4500..8000)
- `temp_min` / `out_of_range`: requested duration_samples=5, value=-30.5; executed [-30.5, -30.5, -30.5, -30.5, -30.5]

### signal-out_of_range-3 - signal.out_of_range

- Verdict: **PASS** (14/14 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 8000..8500 ms (slot 8000..11500)
- `temp_max` / `out_of_range`: requested duration_samples=5, value=70; executed [70, 70, 70, 70, 70]

### signal-out_of_range-4 - signal.out_of_range

- Verdict: **PASS** (16/16 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 11500..12000 ms (slot 11500..15000)
- `temp_max` / `out_of_range`: requested duration_samples=5, value=70.5; executed [70.5, 70.5, 70.5, 70.5, 70.5]

### signal-out_of_range-5 - signal.out_of_range

- Verdict: **PASS** (16/16 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 15000..15500 ms (slot 15000..-)
- `temp_max` / `out_of_range`: requested duration_samples=5, value=75; executed [75, 75, 75, 75, 75]

## Expected vs. observed

Oracle: 65 expected, 65 matched, 0 missing, 0 not reached, 0 unexpected, 0 not applicable

| Status | Fault | Class | Level | Stage | Expected ms | Observed ms | Signal | OpenSOVD ms |
|---|---|---|---|---|---|---|---|---|
| MATCHED | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Failed | 0 | 0 | temp_max | 62 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 1000 | 1000 | temp_max | 1067 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 1000 | 1000 | temp_min | 1067 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | 1000 | 1000 | - | 1067 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 1100 | 1100 | temp_min | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 1500 | 1500 | temp_min | 1577 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | 1500 | 1500 | - | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 1600 | 1600 | temp_min | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 2400 | 2400 | temp_avg | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 4500 | 4500 | temp_max | 4571 |
| MATCHED | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Failed | 4500 | 4500 | temp_min | 4571 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 4500 | 4500 | temp_min | 4571 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | 4500 | 4500 | - | 4571 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 4600 | 4600 | temp_min | - |
| MATCHED | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Passed | 5000 | 5000 | temp_min | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 5000 | 5000 | temp_min | 5071 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | 5000 | 5000 | - | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 5100 | 5100 | temp_min | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 5900 | 5900 | temp_max | - |
| MATCHED | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Failed | 8000 | 8000 | temp_max | 8073 |
| MATCHED | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Passed | 8000 | 8000 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 8000 | 8000 | temp_min | 8073 |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | 8000 | 8000 | temp_max | 8073 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 8000 | 8000 | temp_max | 8073 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | 8000 | 8000 | - | 8073 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 8100 | 8100 | temp_max | - |
| MATCHED | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Passed | 8500 | 8500 | temp_max | - |
| MATCHED | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Failed | 8500 | 8500 | temp_max | 8573 |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | 8500 | 8500 | temp_max | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 8500 | 8500 | temp_max | 8573 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | 8500 | 8500 | - | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 8600 | 8600 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 9400 | 9400 | temp_min | - |
| MATCHED | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Failed | 11500 | 11500 | temp_max | 11569 |
| MATCHED | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Passed | 11500 | 11500 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 11500 | 11500 | temp_avg | 11569 |
| MATCHED | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Failed | 11500 | 11500 | temp_max | 11569 |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | 11500 | 11500 | temp_max | 11569 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 11500 | 11500 | temp_max | 11569 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | 11500 | 11500 | - | 11569 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 11600 | 11600 | temp_max | - |
| MATCHED | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Passed | 12000 | 12000 | temp_max | - |
| MATCHED | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Failed | 12000 | 12000 | temp_max | 12077 |
| MATCHED | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Passed | 12000 | 12000 | temp_max | - |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | 12000 | 12000 | temp_max | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 12000 | 12000 | temp_max | 12077 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | 12000 | 12000 | - | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 12100 | 12100 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 12900 | 12900 | temp_avg | - |
| MATCHED | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Failed | 15000 | 15000 | temp_max | 15069 |
| MATCHED | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Passed | 15000 | 15000 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 15000 | 15000 | temp_min | 15069 |
| MATCHED | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Failed | 15000 | 15000 | temp_max | 15069 |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | 15000 | 15000 | temp_max | 15069 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 15000 | 15000 | temp_max | 15069 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | 15000 | 15000 | - | 15069 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 15100 | 15100 | temp_max | - |
| MATCHED | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Passed | 15500 | 15500 | temp_max | - |
| MATCHED | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Failed | 15500 | 15500 | temp_max | 15569 |
| MATCHED | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Passed | 15500 | 15500 | temp_max | - |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | 15500 | 15500 | temp_max | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 15500 | 15500 | temp_max | 15569 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | 15500 | 15500 | - | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 15600 | 15600 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 16400 | 16400 | temp_avg | - |

## Detection evidence

| t_ms | Fault | Class | Level | Stage | Signal | Observed | Limit | Residual | Utilization | Interval ms |
|---|---|---|---|---|---|---|---|---|---|---|
| 0 | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Failed | temp_max | 60 | 60 | 0 | - | - |
| 1000 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_min | 865 | 6 | 859 | 144.16667 | 100 |
| 1000 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | - | 90 | 8.15 | 81.85 | 11.042945 | - |
| 1000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_max | 0 | 0.25 | - | - | - |
| 1100 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 1500 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | - | - | - | - | - | - |
| 1500 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_min | 865 | 5.69 | 859.31 | 152.02109 | 100 |
| 1600 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 2400 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 4500 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_max | 0 | 0.25 | - | - | - |
| 4500 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_min | 870 | 6 | 864 | 145 | 100 |
| 4500 | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Failed | temp_min | -30.5 | -30 | 0.5 | - | - |
| 4500 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | - | 90.5 | 8.15 | 82.35 | 11.104295 | - |
| 4600 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 5000 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | - | - | - | - | - | - |
| 5000 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_min | 870 | 5.69 | 864.31 | 152.89983 | 100 |
| 5000 | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 5100 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 5900 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 8000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 8000 | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Failed | temp_max | 70 | 70 | 0 | - | - |
| 8000 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_max | 100 | 5.69 | 94.31 | 17.574692 | 100 |
| 8000 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | - | 13.5 | 8.15 | 5.3500004 | 1.6564418 | - |
| 8000 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | temp_max | 11.5 | 2.69 | 8.809999 | 4.275093 | - |
| 8000 | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Passed | temp_max | - | - | - | - | - |
| 8100 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 8500 | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Failed | temp_max | 60 | 60 | 0 | - | - |
| 8500 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_max | 100 | 6 | 94 | 16.666666 | 100 |
| 8500 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | - | - | - | - | - | - |
| 8500 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 8500 | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Passed | temp_max | - | - | - | - | - |
| 8600 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 9400 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 11500 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_avg | 0 | 0.25 | - | - | - |
| 11500 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_max | 105 | 5.69 | 99.31 | 18.453426 | 100 |
| 11500 | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Failed | temp_max | 70.5 | 70 | 0.5 | - | - |
| 11500 | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Failed | temp_max | 70.5 | 70 | 0.5 | - | - |
| 11500 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | - | 14 | 8.15 | 5.8500004 | 1.7177914 | - |
| 11500 | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Passed | temp_max | - | - | - | - | - |
| 11500 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | temp_max | 12 | 2.69 | 9.309999 | 4.4609666 | - |
| 11600 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 12000 | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Failed | temp_max | 60 | 60 | 0 | - | - |
| 12000 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | - | - | - | - | - | - |
| 12000 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_max | 105 | 6 | 99 | 17.5 | 100 |
| 12000 | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 12000 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 12000 | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Passed | temp_max | - | - | - | - | - |
| 12100 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 12900 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 15000 | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Failed | temp_max | 75 | 70 | 5 | - | - |
| 15000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 15000 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | temp_max | 16.5 | 2.69 | 13.809999 | 6.1338286 | - |
| 15000 | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Passed | temp_max | - | - | - | - | - |
| 15000 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_max | 150 | 5.69 | 144.31 | 26.362038 | 100 |
| 15000 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | - | 18.5 | 8.15 | 10.35 | 2.2699387 | - |
| 15000 | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Failed | temp_max | 75 | 70 | 5 | - | - |
| 15100 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 15500 | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Failed | temp_max | 60 | 60 | 0 | - | - |
| 15500 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_max | 150 | 6 | 144 | 25 | 100 |
| 15500 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | - | - | - | - | - | - |
| 15500 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 15500 | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 15500 | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Passed | temp_max | - | - | - | - | - |
| 15600 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 16400 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 20500 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | - | 547.6055 | 500 | 47.60553 | - | - |

## DFM / OpenSOVD correlation

- URL: `http://127.0.0.1:7690/sovd/v1/components/battery_guardian/data/faults`
- Polls: 234 (0 failed)
- Activations: 34; not visible: 0; unexplained: 1

| t_ms | Code |
|---|---|
| 62 | BatteryOverTempWarning |
| 1067 | BatterySignalStuck |
| 1067 | BatteryTempRate |
| 1067 | BatteryTempSpread |
| 1577 | BatteryTempRate |
| 4571 | BatterySignalStuck |
| 4571 | BatteryTempAbsoluteLimit |
| 4571 | BatteryTempRate |
| 4571 | BatteryTempSpread |
| 5071 | BatteryTempRate |
| 8073 | BatteryOverTempCritical |
| 8073 | BatterySignalStuck |
| 8073 | BatteryTempHotspot |
| 8073 | BatteryTempRate |
| 8073 | BatteryTempSpread |
| 8573 | BatteryOverTempWarning |
| 8573 | BatteryTempRate |
| 11569 | BatteryOverTempCritical |
| 11569 | BatterySignalStuck |
| 11569 | BatteryTempAbsoluteLimit |
| 11569 | BatteryTempHotspot |
| 11569 | BatteryTempRate |
| 11569 | BatteryTempSpread |
| 12077 | BatteryOverTempWarning |
| 12077 | BatteryTempRate |
| 15069 | BatteryOverTempCritical |
| 15069 | BatterySignalStuck |
| 15069 | BatteryTempAbsoluteLimit |
| 15069 | BatteryTempHotspot |
| 15069 | BatteryTempRate |
| 15069 | BatteryTempSpread |
| 15569 | BatteryOverTempWarning |
| 15569 | BatteryTempRate |
| 20468 | BatteryTempStreamStale |

Unexplained: `BatteryTempStreamStale`@20468ms

## Timing

- Replay end: 19900 ms; battery stream end: 19900 ms

| Injection | Fault | Injected ms | Detected ms | Detection latency ms | OpenSOVD latency ms |
|---|---|---|---|---|---|
| - | BatteryOverTempWarning | - | 0 | - | 62 |
| signal-out_of_range-1 | BatterySignalStuck | 1000 | 1000 | 0 | 67 |
| signal-out_of_range-1 | BatteryTempRate | 1000 | 1000 | 0 | 67 |
| signal-out_of_range-1 | BatteryTempSpread | 1000 | 1000 | 0 | 67 |
| signal-out_of_range-1 | BatteryTempRate | 1000 | 1100 | 100 | - |
| signal-out_of_range-1 | BatteryTempRate | 1000 | 1500 | 500 | 77 |
| signal-out_of_range-1 | BatteryTempSpread | 1000 | 1500 | 500 | - |
| signal-out_of_range-1 | BatteryTempRate | 1000 | 1600 | 600 | - |
| signal-out_of_range-1 | BatterySignalStuck | 1000 | 2400 | 1400 | - |
| signal-out_of_range-2 | BatterySignalStuck | 4500 | 4500 | 0 | 71 |
| signal-out_of_range-2 | BatteryTempAbsoluteLimit | 4500 | 4500 | 0 | 71 |
| signal-out_of_range-2 | BatteryTempRate | 4500 | 4500 | 0 | 71 |
| signal-out_of_range-2 | BatteryTempSpread | 4500 | 4500 | 0 | 71 |
| signal-out_of_range-2 | BatteryTempRate | 4500 | 4600 | 100 | - |
| signal-out_of_range-2 | BatteryTempAbsoluteLimit | 4500 | 5000 | 500 | - |
| signal-out_of_range-2 | BatteryTempRate | 4500 | 5000 | 500 | 71 |
| signal-out_of_range-2 | BatteryTempSpread | 4500 | 5000 | 500 | - |
| signal-out_of_range-2 | BatteryTempRate | 4500 | 5100 | 600 | - |
| signal-out_of_range-2 | BatterySignalStuck | 4500 | 5900 | 1400 | - |
| signal-out_of_range-3 | BatteryOverTempCritical | 8000 | 8000 | 0 | 73 |
| signal-out_of_range-3 | BatteryOverTempWarning | 8000 | 8000 | 0 | - |
| signal-out_of_range-3 | BatterySignalStuck | 8000 | 8000 | 0 | 73 |
| signal-out_of_range-3 | BatteryTempHotspot | 8000 | 8000 | 0 | 73 |
| signal-out_of_range-3 | BatteryTempRate | 8000 | 8000 | 0 | 73 |
| signal-out_of_range-3 | BatteryTempSpread | 8000 | 8000 | 0 | 73 |
| signal-out_of_range-3 | BatteryTempRate | 8000 | 8100 | 100 | - |
| signal-out_of_range-3 | BatteryOverTempCritical | 8000 | 8500 | 500 | - |
| signal-out_of_range-3 | BatteryOverTempWarning | 8000 | 8500 | 500 | 73 |
| signal-out_of_range-3 | BatteryTempHotspot | 8000 | 8500 | 500 | - |
| signal-out_of_range-3 | BatteryTempRate | 8000 | 8500 | 500 | 73 |
| signal-out_of_range-3 | BatteryTempSpread | 8000 | 8500 | 500 | - |
| signal-out_of_range-3 | BatteryTempRate | 8000 | 8600 | 600 | - |
| signal-out_of_range-3 | BatterySignalStuck | 8000 | 9400 | 1400 | - |
| signal-out_of_range-4 | BatteryOverTempCritical | 11500 | 11500 | 0 | 69 |
| signal-out_of_range-4 | BatteryOverTempWarning | 11500 | 11500 | 0 | - |
| signal-out_of_range-4 | BatterySignalStuck | 11500 | 11500 | 0 | 69 |
| signal-out_of_range-4 | BatteryTempAbsoluteLimit | 11500 | 11500 | 0 | 69 |
| signal-out_of_range-4 | BatteryTempHotspot | 11500 | 11500 | 0 | 69 |
| signal-out_of_range-4 | BatteryTempRate | 11500 | 11500 | 0 | 69 |
| signal-out_of_range-4 | BatteryTempSpread | 11500 | 11500 | 0 | 69 |
| signal-out_of_range-4 | BatteryTempRate | 11500 | 11600 | 100 | - |
| signal-out_of_range-4 | BatteryOverTempCritical | 11500 | 12000 | 500 | - |
| signal-out_of_range-4 | BatteryOverTempWarning | 11500 | 12000 | 500 | 77 |
| signal-out_of_range-4 | BatteryTempAbsoluteLimit | 11500 | 12000 | 500 | - |
| signal-out_of_range-4 | BatteryTempHotspot | 11500 | 12000 | 500 | - |
| signal-out_of_range-4 | BatteryTempRate | 11500 | 12000 | 500 | 77 |
| signal-out_of_range-4 | BatteryTempSpread | 11500 | 12000 | 500 | - |
| signal-out_of_range-4 | BatteryTempRate | 11500 | 12100 | 600 | - |
| signal-out_of_range-4 | BatterySignalStuck | 11500 | 12900 | 1400 | - |
| signal-out_of_range-5 | BatteryOverTempCritical | 15000 | 15000 | 0 | 69 |
| signal-out_of_range-5 | BatteryOverTempWarning | 15000 | 15000 | 0 | - |
| signal-out_of_range-5 | BatterySignalStuck | 15000 | 15000 | 0 | 69 |
| signal-out_of_range-5 | BatteryTempAbsoluteLimit | 15000 | 15000 | 0 | 69 |
| signal-out_of_range-5 | BatteryTempHotspot | 15000 | 15000 | 0 | 69 |
| signal-out_of_range-5 | BatteryTempRate | 15000 | 15000 | 0 | 69 |
| signal-out_of_range-5 | BatteryTempSpread | 15000 | 15000 | 0 | 69 |
| signal-out_of_range-5 | BatteryTempRate | 15000 | 15100 | 100 | - |
| signal-out_of_range-5 | BatteryOverTempCritical | 15000 | 15500 | 500 | - |
| signal-out_of_range-5 | BatteryOverTempWarning | 15000 | 15500 | 500 | 69 |
| signal-out_of_range-5 | BatteryTempAbsoluteLimit | 15000 | 15500 | 500 | - |
| signal-out_of_range-5 | BatteryTempHotspot | 15000 | 15500 | 500 | - |
| signal-out_of_range-5 | BatteryTempRate | 15000 | 15500 | 500 | 69 |
| signal-out_of_range-5 | BatteryTempSpread | 15000 | 15500 | 500 | - |
| signal-out_of_range-5 | BatteryTempRate | 15000 | 15600 | 600 | - |
| signal-out_of_range-5 | BatterySignalStuck | 15000 | 16400 | 1400 | - |

## Verdict rationale

All 65 expected Guardian change(s) matched and no unexpected change was observed.

## Observer artifacts

- Final live-observer view: [observer.html](observer.html)

Observer artifacts are illustrative only and never a source of evaluation facts.

## Gaps and limitations

- **Mitigation:** not instrumented (v1 is event-only, ADR-007) - no mitigation event is recorded; this chain link is intentionally absent.
- **OpenSOVD fault status:** only activation times are captured; the `testFailed`/`confirmedDtc`/`warningIndicator` triple is not observable.
- **Unmapped Guardian warnings:** only DFM-mapped `class/level` pairs reach the collector stream (ADR-016 section 11); utilization warnings may be invisible.

## Notes

- BatteryTempStreamStale at the end of the replay ignored (1 change(s))
