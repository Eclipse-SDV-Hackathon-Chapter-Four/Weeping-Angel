# Evidence Report - signal.drift--hot_nominal

- **Campaign:** signal.drift
- **Scenario:** hot_nominal
- **Run ID:** signal.drift--hot_nominal
- **Generated:** 2026-10-08T06:10:45Z
- **Verdict:** **PASS**

## Provenance and reproduction

- Case (ASC): [case.asc](../experiments/signal.drift/hot_nominal/case.asc)
- Ground truth: [case.ground_truth.yaml](../experiments/signal.drift/hot_nominal/case.ground_truth.yaml)
- Oracle: [case.oracle.yaml](../experiments/signal.drift/hot_nominal/case.oracle.yaml)
- Experiment: [experiment.yaml](../experiments/signal.drift/hot_nominal/experiment.yaml)
- Logs: `can.log`, `collector.log`, `dfm.log`, `dfm_sovd_bridge.log`, `guardian.log`, `vss_bridge.log`, `collector.out`
- Case path (as recorded): `/app/reports/campaign-20261008-055450/experiments/signal.drift/hot_nominal/case`

## Diagnostic chain

```text
replay (ASC) -> KUKSA CAN Provider -> KUKSA Data Broker -> VSS uProtocol Publisher -> Battery Thermal Guardian -> DFM -> OpenSOVD -> Evidence Collector
```

## Fault catalog

| Fault code | Category | Severity | Description |
|---|---|---|---|
| BatteryOverTempCritical | Hardware | Fatal | Maximum cell temperature reached the configured critical band. |
| BatteryOverTempWarning | Hardware | Warn | Maximum cell temperature entered the configured warning band. |
| BatterySignalStuck | Communication | Error | A battery signal stayed flat while other signals changed (stuck signal). |
| BatteryTempAbsoluteLimit | Hardware | Fatal | Battery temperature outside the absolute physical limits. |
| BatteryTempHotspot | Hardware | Error | Max temperature deviates from average beyond the hotspot limit. |
| BatteryTempRate | Configuration | Error | Temperature changed faster than physically possible. |
| BatteryTempSpread | Hardware | Error | Spread between max and min temperature exceeds the physical limit. |
| BatteryTempStreamStale | Communication | Error | No battery temperature sample received within the missing-packet timeout. |

## Injections

### signal-drift-1 - signal.drift

- Verdict: **PASS** (0/0 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 1000..1100 ms (slot 1000..4500)
- `temp_max` / `drift`: requested duration_samples=1, rate_per_sample=0.5; executed [60.5]

### signal-drift-2 - signal.drift

- Verdict: **PASS** (12/12 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 4500..6500 ms (slot 4500..8000)
- `temp_max` / `drift`: requested duration_samples=20, rate_per_sample=0.5; executed [60.5, 61, 61.5, 62, 62.5, 63, 63.5, 64, 64.5, 65, 65.5, 66, 66.5, 67, 67.5, 68, 68.5, 69, 69.5, 70]

### signal-drift-3 - signal.drift

- Verdict: **PASS** (12/12 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 8000..10000 ms (slot 8000..11500)
- `temp_max` / `drift`: requested duration_samples=20, rate_per_sample=0.5; executed [60.5, 61, 61.5, 62, 62.5, 63, 63.5, 64, 64.5, 65, 65.5, 66, 66.5, 67, 67.5, 68, 68.5, 69, 69.5, 70]

### signal-drift-4 - signal.drift

- Verdict: **PASS** (12/12 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 11500..13500 ms (slot 11500..15000)
- `temp_max` / `drift`: requested duration_samples=20, rate_per_sample=0.5; executed [60.5, 61, 61.5, 62, 62.5, 63, 63.5, 64, 64.5, 65, 65.5, 66, 66.5, 67, 67.5, 68, 68.5, 69, 69.5, 70]

### signal-drift-5 - signal.drift

- Verdict: **PASS** (14/14 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 15000..17000 ms (slot 15000..-)
- `temp_max` / `drift`: requested duration_samples=20, rate_per_sample=0.5; executed [61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80]

## Expected vs. observed

Oracle: 51 expected, 51 matched, 0 missing, 0 not reached, 0 unexpected, 24 not applicable

| Status | Fault | Class | Level | Stage | Expected ms | Observed ms | Signal | OpenSOVD ms |
|---|---|---|---|---|---|---|---|---|
| MATCHED | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Failed | 0 | 0 | temp_max | 60 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 4600 | 4600 | temp_avg | 4671 |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | 4700 | 4700 | temp_max | 4762 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | 5400 | 5400 | - | 5462 |
| MATCHED | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Failed | 6400 | 6400 | temp_max | 6470 |
| MATCHED | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Passed | 6400 | 6400 | temp_max | - |
| MATCHED | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Passed | 6500 | 6500 | temp_max | - |
| MATCHED | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Failed | 6500 | 6500 | temp_max | 6564 |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | 6500 | 6500 | temp_max | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 6500 | 6500 | temp_max | 6564 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | 6500 | 6500 | - | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 6600 | 6600 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 7400 | 7400 | temp_avg | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 8100 | 8100 | temp_min | 8163 |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | 8200 | 8200 | temp_max | 8265 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | 8900 | 8900 | - | 8968 |
| MATCHED | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Failed | 9900 | 9900 | temp_max | 9964 |
| MATCHED | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Passed | 9900 | 9900 | temp_max | - |
| MATCHED | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Passed | 10000 | 10000 | temp_max | - |
| MATCHED | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Failed | 10000 | 10000 | temp_max | 10066 |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | 10000 | 10000 | temp_max | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 10000 | 10000 | temp_max | 10066 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | 10000 | 10000 | - | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 10100 | 10100 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 10900 | 10900 | temp_min | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 11600 | 11600 | temp_min | 11666 |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | 11700 | 11700 | temp_max | 11768 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | 12400 | 12400 | - | 12461 |
| MATCHED | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Failed | 13400 | 13400 | temp_max | 13469 |
| MATCHED | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Passed | 13400 | 13400 | temp_max | - |
| MATCHED | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Passed | 13500 | 13500 | temp_max | - |
| MATCHED | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Failed | 13500 | 13500 | temp_max | 13563 |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | 13500 | 13500 | temp_max | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 13500 | 13500 | temp_max | 13563 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | 13500 | 13500 | - | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 13600 | 13600 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 14400 | 14400 | temp_avg | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 15000 | 15000 | temp_min | 15068 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 15000 | 15000 | temp_max | 15068 |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | 15100 | 15100 | temp_max | 15169 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | 15400 | 15400 | - | 15465 |
| MATCHED | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Failed | 15900 | 15900 | temp_max | 15964 |
| MATCHED | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Passed | 15900 | 15900 | temp_max | - |
| MATCHED | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Failed | 16000 | 16000 | temp_max | 16066 |
| MATCHED | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Passed | 17000 | 17000 | temp_max | - |
| MATCHED | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Failed | 17000 | 17000 | temp_max | 17064 |
| MATCHED | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Passed | 17000 | 17000 | temp_max | - |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | 17000 | 17000 | temp_max | - |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | 17000 | 17000 | - | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 17100 | 17100 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 17900 | 17900 | temp_min | - |

## Detection evidence

| t_ms | Fault | Class | Level | Stage | Signal | Observed | Limit | Residual | Utilization | Interval ms |
|---|---|---|---|---|---|---|---|---|---|---|
| 0 | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Failed | temp_max | 60 | 60 | 0 | - | - |
| 4600 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_avg | 0 | 0.25 | - | - | - |
| 4700 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | temp_max | 3 | 2.69 | 0.30999994 | 1.1152416 | - |
| 5400 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | - | 8.5 | 8.15 | 0.35000038 | 1.0429448 | - |
| 6400 | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Passed | temp_max | - | - | - | - | - |
| 6400 | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Failed | temp_max | 70 | 70 | 0 | - | - |
| 6500 | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Failed | temp_max | 60 | 60 | 0 | - | - |
| 6500 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_max | 100 | 6 | 94 | 16.666666 | 100 |
| 6500 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 6500 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | - | - | - | - | - | - |
| 6500 | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Passed | temp_max | - | - | - | - | - |
| 6600 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 7400 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 8100 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 8200 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | temp_max | 3 | 2.69 | 0.30999994 | 1.1152416 | - |
| 8900 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | - | 8.5 | 8.15 | 0.35000038 | 1.0429448 | - |
| 9900 | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Passed | temp_max | - | - | - | - | - |
| 9900 | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Failed | temp_max | 70 | 70 | 0 | - | - |
| 10000 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_max | 100 | 6 | 94 | 16.666666 | 100 |
| 10000 | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Failed | temp_max | 60 | 60 | 0 | - | - |
| 10000 | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Passed | temp_max | - | - | - | - | - |
| 10000 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 10000 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | - | - | - | - | - | - |
| 10100 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 10900 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 11600 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 11700 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | temp_max | 3 | 2.69 | 0.30999994 | 1.1152416 | - |
| 12400 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | - | 8.5 | 8.15 | 0.35000038 | 1.0429448 | - |
| 13400 | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Passed | temp_max | - | - | - | - | - |
| 13400 | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Failed | temp_max | 70 | 70 | 0 | - | - |
| 13500 | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Failed | temp_max | 60 | 60 | 0 | - | - |
| 13500 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_max | 100 | 6 | 94 | 16.666666 | 100 |
| 13500 | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Passed | temp_max | - | - | - | - | - |
| 13500 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | - | - | - | - | - | - |
| 13500 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 13600 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 14400 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 15000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 15000 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_max | 10 | 5.69 | 4.31 | 1.7574692 | 100 |
| 15100 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | temp_max | 3.5 | 2.69 | 0.80999994 | 1.3011152 | - |
| 15400 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | - | 8.5 | 8.15 | 0.35000038 | 1.0429448 | - |
| 15900 | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Failed | temp_max | 70 | 70 | 0 | - | - |
| 15900 | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Passed | temp_max | - | - | - | - | - |
| 16000 | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Failed | temp_max | 71 | 70 | 1 | - | - |
| 17000 | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Failed | temp_max | 60 | 60 | 0 | - | - |
| 17000 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | - | - | - | - | - | - |
| 17000 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 17000 | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Passed | temp_max | - | - | - | - | - |
| 17000 | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 17100 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 17900 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 20500 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | - | 538.4858 | 500 | 38.48578 | - | - |

## DFM / OpenSOVD correlation

- URL: `http://127.0.0.1:7690/sovd/v1/components/battery_guardian/data/faults`
- Polls: 234 (0 failed)
- Activations: 27; not visible: 0; unexplained: 1

| t_ms | Code |
|---|---|
| 60 | BatteryOverTempWarning |
| 4671 | BatterySignalStuck |
| 4762 | BatteryTempHotspot |
| 5462 | BatteryTempSpread |
| 6470 | BatteryOverTempCritical |
| 6564 | BatteryOverTempWarning |
| 6564 | BatteryTempRate |
| 8163 | BatterySignalStuck |
| 8265 | BatteryTempHotspot |
| 8968 | BatteryTempSpread |
| 9964 | BatteryOverTempCritical |
| 10066 | BatteryOverTempWarning |
| 10066 | BatteryTempRate |
| 11666 | BatterySignalStuck |
| 11768 | BatteryTempHotspot |
| 12461 | BatteryTempSpread |
| 13469 | BatteryOverTempCritical |
| 13563 | BatteryOverTempWarning |
| 13563 | BatteryTempRate |
| 15068 | BatterySignalStuck |
| 15068 | BatteryTempRate |
| 15169 | BatteryTempHotspot |
| 15465 | BatteryTempSpread |
| 15964 | BatteryOverTempCritical |
| 16066 | BatteryTempAbsoluteLimit |
| 17064 | BatteryOverTempWarning |
| 20462 | BatteryTempStreamStale |

Unexplained: `BatteryTempStreamStale`@20462ms

## Timing

- Replay end: 19900 ms; battery stream end: 19900 ms

| Injection | Fault | Injected ms | Detected ms | Detection latency ms | OpenSOVD latency ms |
|---|---|---|---|---|---|
| - | BatteryOverTempWarning | - | 0 | - | 60 |
| signal-drift-2 | BatterySignalStuck | 4500 | 4600 | 100 | 71 |
| signal-drift-2 | BatteryTempHotspot | 4500 | 4700 | 200 | 62 |
| signal-drift-2 | BatteryTempSpread | 4500 | 5400 | 900 | 62 |
| signal-drift-2 | BatteryOverTempCritical | 4500 | 6400 | 1900 | 70 |
| signal-drift-2 | BatteryOverTempWarning | 4500 | 6400 | 1900 | - |
| signal-drift-2 | BatteryOverTempCritical | 4500 | 6500 | 2000 | - |
| signal-drift-2 | BatteryOverTempWarning | 4500 | 6500 | 2000 | 64 |
| signal-drift-2 | BatteryTempHotspot | 4500 | 6500 | 2000 | - |
| signal-drift-2 | BatteryTempRate | 4500 | 6500 | 2000 | 64 |
| signal-drift-2 | BatteryTempSpread | 4500 | 6500 | 2000 | - |
| signal-drift-2 | BatteryTempRate | 4500 | 6600 | 2100 | - |
| signal-drift-2 | BatterySignalStuck | 4500 | 7400 | 2900 | - |
| signal-drift-3 | BatterySignalStuck | 8000 | 8100 | 100 | 63 |
| signal-drift-3 | BatteryTempHotspot | 8000 | 8200 | 200 | 65 |
| signal-drift-3 | BatteryTempSpread | 8000 | 8900 | 900 | 68 |
| signal-drift-3 | BatteryOverTempCritical | 8000 | 9900 | 1900 | 64 |
| signal-drift-3 | BatteryOverTempWarning | 8000 | 9900 | 1900 | - |
| signal-drift-3 | BatteryOverTempCritical | 8000 | 10000 | 2000 | - |
| signal-drift-3 | BatteryOverTempWarning | 8000 | 10000 | 2000 | 66 |
| signal-drift-3 | BatteryTempHotspot | 8000 | 10000 | 2000 | - |
| signal-drift-3 | BatteryTempRate | 8000 | 10000 | 2000 | 66 |
| signal-drift-3 | BatteryTempSpread | 8000 | 10000 | 2000 | - |
| signal-drift-3 | BatteryTempRate | 8000 | 10100 | 2100 | - |
| signal-drift-3 | BatterySignalStuck | 8000 | 10900 | 2900 | - |
| signal-drift-4 | BatterySignalStuck | 11500 | 11600 | 100 | 66 |
| signal-drift-4 | BatteryTempHotspot | 11500 | 11700 | 200 | 68 |
| signal-drift-4 | BatteryTempSpread | 11500 | 12400 | 900 | 61 |
| signal-drift-4 | BatteryOverTempCritical | 11500 | 13400 | 1900 | 69 |
| signal-drift-4 | BatteryOverTempWarning | 11500 | 13400 | 1900 | - |
| signal-drift-4 | BatteryOverTempCritical | 11500 | 13500 | 2000 | - |
| signal-drift-4 | BatteryOverTempWarning | 11500 | 13500 | 2000 | 63 |
| signal-drift-4 | BatteryTempHotspot | 11500 | 13500 | 2000 | - |
| signal-drift-4 | BatteryTempRate | 11500 | 13500 | 2000 | 63 |
| signal-drift-4 | BatteryTempSpread | 11500 | 13500 | 2000 | - |
| signal-drift-4 | BatteryTempRate | 11500 | 13600 | 2100 | - |
| signal-drift-4 | BatterySignalStuck | 11500 | 14400 | 2900 | - |
| signal-drift-5 | BatterySignalStuck | 15000 | 15000 | 0 | 68 |
| signal-drift-5 | BatteryTempRate | 15000 | 15000 | 0 | 68 |
| signal-drift-5 | BatteryTempHotspot | 15000 | 15100 | 100 | 69 |
| signal-drift-5 | BatteryTempSpread | 15000 | 15400 | 400 | 65 |
| signal-drift-5 | BatteryOverTempCritical | 15000 | 15900 | 900 | 64 |
| signal-drift-5 | BatteryOverTempWarning | 15000 | 15900 | 900 | - |
| signal-drift-5 | BatteryTempAbsoluteLimit | 15000 | 16000 | 1000 | 66 |
| signal-drift-5 | BatteryOverTempCritical | 15000 | 17000 | 2000 | - |
| signal-drift-5 | BatteryOverTempWarning | 15000 | 17000 | 2000 | 64 |
| signal-drift-5 | BatteryTempAbsoluteLimit | 15000 | 17000 | 2000 | - |
| signal-drift-5 | BatteryTempHotspot | 15000 | 17000 | 2000 | - |
| signal-drift-5 | BatteryTempSpread | 15000 | 17000 | 2000 | - |
| signal-drift-5 | BatteryTempRate | 15000 | 17100 | 2100 | - |
| signal-drift-5 | BatterySignalStuck | 15000 | 17900 | 2900 | - |

## Verdict rationale

All 51 expected Guardian change(s) matched and no unexpected change was observed.

## Observer artifacts

- Final live-observer view: [observer.html](observer.html)

Observer artifacts are illustrative only and never a source of evaluation facts.

## Gaps and limitations

- **Mitigation:** not instrumented (v1 is event-only, ADR-007) - no mitigation event is recorded; this chain link is intentionally absent.
- **OpenSOVD fault status:** only activation times are captured; the `testFailed`/`confirmedDtc`/`warningIndicator` triple is not observable.
- **Unmapped Guardian warnings:** only DFM-mapped `class/level` pairs reach the collector stream (ADR-016 section 11); utilization warnings may be invisible.

## Notes

- BatteryTempStreamStale at the end of the replay ignored (1 change(s))
