# Evidence Report - signal.drift--warm_nominal

- **Campaign:** signal.drift
- **Scenario:** warm_nominal
- **Run ID:** signal.drift--warm_nominal
- **Generated:** 2026-10-08T06:10:45Z
- **Verdict:** **PASS**

## Provenance and reproduction

- Case (ASC): [case.asc](../experiments/signal.drift/warm_nominal/case.asc)
- Ground truth: [case.ground_truth.yaml](../experiments/signal.drift/warm_nominal/case.ground_truth.yaml)
- Oracle: [case.oracle.yaml](../experiments/signal.drift/warm_nominal/case.oracle.yaml)
- Experiment: [experiment.yaml](../experiments/signal.drift/warm_nominal/experiment.yaml)
- Logs: `can.log`, `collector.log`, `dfm.log`, `dfm_sovd_bridge.log`, `guardian.log`, `vss_bridge.log`, `collector.out`
- Case path (as recorded): `/app/reports/campaign-20261008-055450/experiments/signal.drift/warm_nominal/case`

## Diagnostic chain

```text
replay (ASC) -> KUKSA CAN Provider -> KUKSA Data Broker -> VSS uProtocol Publisher -> Battery Thermal Guardian -> DFM -> OpenSOVD -> Evidence Collector
```

## Fault catalog

| Fault code | Category | Severity | Description |
|---|---|---|---|
| BatteryOverTempCritical | Hardware | Fatal | Maximum cell temperature reached the configured critical band. |
| BatteryOverTempWarning | Hardware | Warn | Maximum cell temperature entered the configured warning band. |
| BatterySignalStuck | Communication | Error | A battery signal stayed flat while other signals changed (stuck signal). |
| BatteryTempAbsoluteLimit | Hardware | Fatal | Battery temperature outside the absolute physical limits. |
| BatteryTempHotspot | Hardware | Error | Max temperature deviates from average beyond the hotspot limit. |
| BatteryTempRate | Configuration | Error | Temperature changed faster than physically possible. |
| BatteryTempSpread | Hardware | Error | Spread between max and min temperature exceeds the physical limit. |
| BatteryTempStreamStale | Communication | Error | No battery temperature sample received within the missing-packet timeout. |

## Injections

### signal-drift-1 - signal.drift

- Verdict: **PASS** (0/0 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 1000..1100 ms (slot 1000..4500)
- `temp_max` / `drift`: requested duration_samples=1, rate_per_sample=0.5; executed [32]

### signal-drift-2 - signal.drift

- Verdict: **PASS** (18/18 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 4500..6500 ms (slot 4500..8000)
- `temp_max` / `drift`: requested duration_samples=20, rate_per_sample=0.5; executed [35.5, 38, 40.5, 43, 45.5, 48, 50.5, 53, 55.5, 58, 60.5, 63, 65.5, 68, 70.5, 73, 75.5, 78, 80.5, 83]

### signal-drift-3 - signal.drift

- Verdict: **PASS** (18/18 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 8000..10000 ms (slot 8000..11500)
- `temp_max` / `drift`: requested duration_samples=20, rate_per_sample=0.5; executed [37, 39.5, 42, 44.5, 47, 49.5, 52, 54.5, 57, 59.5, 62, 64.5, 67, 69.5, 72, 74.5, 77, 79.5, 82, 84.5]

### signal-drift-4 - signal.drift

- Verdict: **PASS** (12/12 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 11500..13500 ms (slot 11500..15000)
- `temp_max` / `drift`: requested duration_samples=20, rate_per_sample=0.5; executed [36.5, 37, 37.5, 38, 38.5, 39, 39.5, 40, 40.5, 41, 41.5, 42, 42.5, 43, 43.5, 44, 44.5, 45, 45.5, 46]

### signal-drift-5 - signal.drift

- Verdict: **PASS** (18/18 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 15000..17000 ms (slot 15000..-)
- `temp_max` / `drift`: requested duration_samples=20, rate_per_sample=0.5; executed [39.5, 41.5, 43.5, 45.5, 47.5, 49.5, 51.5, 53.5, 55.5, 57.5, 59.5, 61.5, 63.5, 65.5, 67.5, 69.5, 71.5, 73.5, 75.5, 77.5]

## Expected vs. observed

Oracle: 66 expected, 66 matched, 0 missing, 0 not reached, 0 unexpected, 18 not applicable

| Status | Fault | Class | Level | Stage | Expected ms | Observed ms | Signal | OpenSOVD ms |
|---|---|---|---|---|---|---|---|---|
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 4500 | 4500 | temp_avg | 4570 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 4500 | 4500 | temp_max | 4570 |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | 4600 | 4600 | temp_max | 4662 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | 4700 | 4700 | - | 4763 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 4800 | 4800 | temp_avg | - |
| MATCHED | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Failed | 5500 | 5500 | temp_max | 5568 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 5700 | 5700 | temp_min | 5761 |
| MATCHED | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Failed | 5900 | 5900 | temp_max | 5965 |
| MATCHED | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Passed | 5900 | 5900 | temp_max | - |
| MATCHED | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Failed | 5900 | 5900 | temp_max | 5965 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 6000 | 6000 | temp_avg | - |
| MATCHED | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Passed | 6500 | 6500 | temp_max | - |
| MATCHED | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Passed | 6500 | 6500 | temp_max | - |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | 6500 | 6500 | temp_max | - |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | 6500 | 6500 | - | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 6600 | 6600 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 6900 | 6900 | temp_min | 6966 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 7200 | 7200 | temp_avg | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 8000 | 8000 | temp_max | 8066 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 8100 | 8100 | temp_avg | 8168 |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | 8100 | 8100 | temp_max | 8168 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | 8200 | 8200 | - | 8270 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 8400 | 8400 | temp_min | - |
| MATCHED | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Failed | 9000 | 9000 | temp_max | 9063 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 9300 | 9300 | temp_min | 9369 |
| MATCHED | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Failed | 9400 | 9400 | temp_max | 9471 |
| MATCHED | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Passed | 9400 | 9400 | temp_max | - |
| MATCHED | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Failed | 9400 | 9400 | temp_max | 9471 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 9600 | 9600 | temp_avg | - |
| MATCHED | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Passed | 10000 | 10000 | temp_max | - |
| MATCHED | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Passed | 10000 | 10000 | temp_max | - |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | 10000 | 10000 | temp_max | - |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | 10000 | 10000 | - | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 10100 | 10100 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 10500 | 10500 | temp_min | 10571 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 10800 | 10800 | temp_avg | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 11700 | 11700 | temp_avg | 11763 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 12000 | 12000 | temp_avg | - |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | 12100 | 12100 | temp_max | 12169 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 12900 | 12900 | temp_min | 12965 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | 12900 | 12900 | - | 12965 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 13200 | 13200 | temp_min | - |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | 13500 | 13500 | temp_max | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 13500 | 13500 | temp_max | 13566 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | 13500 | 13500 | - | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 13600 | 13600 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 14100 | 14100 | temp_min | 14169 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 14400 | 14400 | temp_min | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 15000 | 15000 | temp_max | 15065 |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | 15100 | 15100 | temp_max | 15166 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 15300 | 15300 | temp_min | 15370 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | 15300 | 15300 | - | 15370 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 15600 | 15600 | temp_avg | - |
| MATCHED | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Failed | 16100 | 16100 | temp_max | 16166 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 16500 | 16500 | temp_min | 16563 |
| MATCHED | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Failed | 16600 | 16600 | temp_max | 16665 |
| MATCHED | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Passed | 16600 | 16600 | temp_max | - |
| MATCHED | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Failed | 16600 | 16600 | temp_max | 16665 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 16800 | 16800 | temp_min | - |
| MATCHED | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Passed | 17000 | 17000 | temp_max | - |
| MATCHED | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Passed | 17000 | 17000 | temp_max | - |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | 17000 | 17000 | temp_max | - |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | 17000 | 17000 | - | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 17100 | 17100 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 17700 | 17700 | temp_avg | 17768 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 17900 | 17900 | temp_avg | - |

## Detection evidence

| t_ms | Fault | Class | Level | Stage | Signal | Observed | Limit | Residual | Utilization | Interval ms |
|---|---|---|---|---|---|---|---|---|---|---|
| 4500 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_max | 25 | 7.31 | 17.69 | 3.4199727 | 100 |
| 4500 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_avg | 0 | 0.25 | - | - | - |
| 4600 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | temp_max | 6.5 | 4.31 | 2.19 | 1.5081207 | - |
| 4700 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | - | 11.5 | 10.85 | 0.6499996 | 1.0599078 | - |
| 4800 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 5500 | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Failed | temp_max | 60.5 | 60 | 0.5 | - | - |
| 5700 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 5900 | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Passed | temp_max | - | - | - | - | - |
| 5900 | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Failed | temp_max | 70.5 | 70 | 0.5 | - | - |
| 5900 | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Failed | temp_max | 70.5 | 70 | 0.5 | - | - |
| 6000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 6500 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | - | - | - | - | - | - |
| 6500 | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 6500 | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Passed | temp_max | - | - | - | - | - |
| 6500 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 6600 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 6900 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 7200 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 8000 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_max | 25 | 7.2200003 | 17.779999 | 3.4626038 | 100 |
| 8100 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_avg | 0 | 0.25 | - | - | - |
| 8100 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | temp_max | 6.5 | 4.2200003 | 2.2799997 | 1.5402843 | - |
| 8200 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | - | 11.5 | 10.7 | 0.8000002 | 1.0747664 | - |
| 8400 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 9000 | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Failed | temp_max | 62 | 60 | 2 | - | - |
| 9300 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 9400 | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Failed | temp_max | 72 | 70 | 2 | - | - |
| 9400 | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Failed | temp_max | 72 | 70 | 2 | - | - |
| 9400 | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Passed | temp_max | - | - | - | - | - |
| 9600 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 10000 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | - | - | - | - | - | - |
| 10000 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 10000 | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Passed | temp_max | - | - | - | - | - |
| 10000 | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 10100 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 10500 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 10800 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 11700 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_avg | 0 | 0.25 | - | - | - |
| 12000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 12100 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | temp_max | 4.5 | 4.1 | 0.4000001 | 1.097561 | - |
| 12900 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 12900 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | - | 11 | 10.5 | 0.5 | 1.0476191 | - |
| 13200 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 13500 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_max | 90 | 6 | 84 | 15 | 100 |
| 13500 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 13500 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | - | - | - | - | - | - |
| 13600 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 14100 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 14400 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 15000 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_max | 20 | 7.04 | 12.96 | 2.840909 | 100 |
| 15100 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | temp_max | 5.5 | 4.04 | 1.46 | 1.3613862 | - |
| 15300 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | - | 12 | 10.4 | 1.6000004 | 1.1538461 | - |
| 15300 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 15600 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 16100 | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Failed | temp_max | 61.5 | 60 | 1.5 | - | - |
| 16500 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 16600 | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Failed | temp_max | 71.5 | 70 | 1.5 | - | - |
| 16600 | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Failed | temp_max | 71.5 | 70 | 1.5 | - | - |
| 16600 | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Passed | temp_max | - | - | - | - | - |
| 16800 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 17000 | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 17000 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | - | - | - | - | - | - |
| 17000 | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Passed | temp_max | - | - | - | - | - |
| 17000 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 17100 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 17700 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_avg | 0 | 0.25 | - | - | - |
| 17900 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 20500 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | - | 539.12366 | 500 | 39.123657 | - | - |

## DFM / OpenSOVD correlation

- URL: `http://127.0.0.1:7690/sovd/v1/components/battery_guardian/data/faults`
- Polls: 234 (0 failed)
- Activations: 34; not visible: 0; unexplained: 1

| t_ms | Code |
|---|---|
| 4570 | BatterySignalStuck |
| 4570 | BatteryTempRate |
| 4662 | BatteryTempHotspot |
| 4763 | BatteryTempSpread |
| 5568 | BatteryOverTempWarning |
| 5761 | BatterySignalStuck |
| 5965 | BatteryOverTempCritical |
| 5965 | BatteryTempAbsoluteLimit |
| 6966 | BatterySignalStuck |
| 8066 | BatteryTempRate |
| 8168 | BatterySignalStuck |
| 8168 | BatteryTempHotspot |
| 8270 | BatteryTempSpread |
| 9063 | BatteryOverTempWarning |
| 9369 | BatterySignalStuck |
| 9471 | BatteryOverTempCritical |
| 9471 | BatteryTempAbsoluteLimit |
| 10571 | BatterySignalStuck |
| 11763 | BatterySignalStuck |
| 12169 | BatteryTempHotspot |
| 12965 | BatterySignalStuck |
| 12965 | BatteryTempSpread |
| 13566 | BatteryTempRate |
| 14169 | BatterySignalStuck |
| 15065 | BatteryTempRate |
| 15166 | BatteryTempHotspot |
| 15370 | BatterySignalStuck |
| 15370 | BatteryTempSpread |
| 16166 | BatteryOverTempWarning |
| 16563 | BatterySignalStuck |
| 16665 | BatteryOverTempCritical |
| 16665 | BatteryTempAbsoluteLimit |
| 17768 | BatterySignalStuck |
| 20465 | BatteryTempStreamStale |

Unexplained: `BatteryTempStreamStale`@20465ms

## Timing

- Replay end: 19900 ms; battery stream end: 19900 ms

| Injection | Fault | Injected ms | Detected ms | Detection latency ms | OpenSOVD latency ms |
|---|---|---|---|---|---|
| signal-drift-2 | BatterySignalStuck | 4500 | 4500 | 0 | 70 |
| signal-drift-2 | BatteryTempRate | 4500 | 4500 | 0 | 70 |
| signal-drift-2 | BatteryTempHotspot | 4500 | 4600 | 100 | 62 |
| signal-drift-2 | BatteryTempSpread | 4500 | 4700 | 200 | 63 |
| signal-drift-2 | BatterySignalStuck | 4500 | 4800 | 300 | - |
| signal-drift-2 | BatteryOverTempWarning | 4500 | 5500 | 1000 | 68 |
| signal-drift-2 | BatterySignalStuck | 4500 | 5700 | 1200 | 61 |
| signal-drift-2 | BatteryOverTempCritical | 4500 | 5900 | 1400 | 65 |
| signal-drift-2 | BatteryOverTempWarning | 4500 | 5900 | 1400 | - |
| signal-drift-2 | BatteryTempAbsoluteLimit | 4500 | 5900 | 1400 | 65 |
| signal-drift-2 | BatterySignalStuck | 4500 | 6000 | 1500 | - |
| signal-drift-2 | BatteryOverTempCritical | 4500 | 6500 | 2000 | - |
| signal-drift-2 | BatteryTempAbsoluteLimit | 4500 | 6500 | 2000 | - |
| signal-drift-2 | BatteryTempHotspot | 4500 | 6500 | 2000 | - |
| signal-drift-2 | BatteryTempSpread | 4500 | 6500 | 2000 | - |
| signal-drift-2 | BatteryTempRate | 4500 | 6600 | 2100 | - |
| signal-drift-2 | BatterySignalStuck | 4500 | 6900 | 2400 | 66 |
| signal-drift-2 | BatterySignalStuck | 4500 | 7200 | 2700 | - |
| signal-drift-3 | BatteryTempRate | 8000 | 8000 | 0 | 66 |
| signal-drift-3 | BatterySignalStuck | 8000 | 8100 | 100 | 68 |
| signal-drift-3 | BatteryTempHotspot | 8000 | 8100 | 100 | 68 |
| signal-drift-3 | BatteryTempSpread | 8000 | 8200 | 200 | 70 |
| signal-drift-3 | BatterySignalStuck | 8000 | 8400 | 400 | - |
| signal-drift-3 | BatteryOverTempWarning | 8000 | 9000 | 1000 | 63 |
| signal-drift-3 | BatterySignalStuck | 8000 | 9300 | 1300 | 69 |
| signal-drift-3 | BatteryOverTempCritical | 8000 | 9400 | 1400 | 71 |
| signal-drift-3 | BatteryOverTempWarning | 8000 | 9400 | 1400 | - |
| signal-drift-3 | BatteryTempAbsoluteLimit | 8000 | 9400 | 1400 | 71 |
| signal-drift-3 | BatterySignalStuck | 8000 | 9600 | 1600 | - |
| signal-drift-3 | BatteryOverTempCritical | 8000 | 10000 | 2000 | - |
| signal-drift-3 | BatteryTempAbsoluteLimit | 8000 | 10000 | 2000 | - |
| signal-drift-3 | BatteryTempHotspot | 8000 | 10000 | 2000 | - |
| signal-drift-3 | BatteryTempSpread | 8000 | 10000 | 2000 | - |
| signal-drift-3 | BatteryTempRate | 8000 | 10100 | 2100 | - |
| signal-drift-3 | BatterySignalStuck | 8000 | 10500 | 2500 | 71 |
| signal-drift-3 | BatterySignalStuck | 8000 | 10800 | 2800 | - |
| signal-drift-4 | BatterySignalStuck | 11500 | 11700 | 200 | 63 |
| signal-drift-4 | BatterySignalStuck | 11500 | 12000 | 500 | - |
| signal-drift-4 | BatteryTempHotspot | 11500 | 12100 | 600 | 69 |
| signal-drift-4 | BatterySignalStuck | 11500 | 12900 | 1400 | 65 |
| signal-drift-4 | BatteryTempSpread | 11500 | 12900 | 1400 | 65 |
| signal-drift-4 | BatterySignalStuck | 11500 | 13200 | 1700 | - |
| signal-drift-4 | BatteryTempHotspot | 11500 | 13500 | 2000 | - |
| signal-drift-4 | BatteryTempRate | 11500 | 13500 | 2000 | 66 |
| signal-drift-4 | BatteryTempSpread | 11500 | 13500 | 2000 | - |
| signal-drift-4 | BatteryTempRate | 11500 | 13600 | 2100 | - |
| signal-drift-4 | BatterySignalStuck | 11500 | 14100 | 2600 | 69 |
| signal-drift-4 | BatterySignalStuck | 11500 | 14400 | 2900 | - |
| signal-drift-5 | BatteryTempRate | 15000 | 15000 | 0 | 65 |
| signal-drift-5 | BatteryTempHotspot | 15000 | 15100 | 100 | 66 |
| signal-drift-5 | BatterySignalStuck | 15000 | 15300 | 300 | 70 |
| signal-drift-5 | BatteryTempSpread | 15000 | 15300 | 300 | 70 |
| signal-drift-5 | BatterySignalStuck | 15000 | 15600 | 600 | - |
| signal-drift-5 | BatteryOverTempWarning | 15000 | 16100 | 1100 | 66 |
| signal-drift-5 | BatterySignalStuck | 15000 | 16500 | 1500 | 63 |
| signal-drift-5 | BatteryOverTempCritical | 15000 | 16600 | 1600 | 65 |
| signal-drift-5 | BatteryOverTempWarning | 15000 | 16600 | 1600 | - |
| signal-drift-5 | BatteryTempAbsoluteLimit | 15000 | 16600 | 1600 | 65 |
| signal-drift-5 | BatterySignalStuck | 15000 | 16800 | 1800 | - |
| signal-drift-5 | BatteryOverTempCritical | 15000 | 17000 | 2000 | - |
| signal-drift-5 | BatteryTempAbsoluteLimit | 15000 | 17000 | 2000 | - |
| signal-drift-5 | BatteryTempHotspot | 15000 | 17000 | 2000 | - |
| signal-drift-5 | BatteryTempSpread | 15000 | 17000 | 2000 | - |
| signal-drift-5 | BatteryTempRate | 15000 | 17100 | 2100 | - |
| signal-drift-5 | BatterySignalStuck | 15000 | 17700 | 2700 | 68 |
| signal-drift-5 | BatterySignalStuck | 15000 | 17900 | 2900 | - |

## Verdict rationale

All 66 expected Guardian change(s) matched and no unexpected change was observed.

## Observer artifacts

- Final live-observer view: [observer.html](observer.html)

Observer artifacts are illustrative only and never a source of evaluation facts.

## Gaps and limitations

- **Mitigation:** not instrumented (v1 is event-only, ADR-007) - no mitigation event is recorded; this chain link is intentionally absent.
- **OpenSOVD fault status:** only activation times are captured; the `testFailed`/`confirmedDtc`/`warningIndicator` triple is not observable.
- **Unmapped Guardian warnings:** only DFM-mapped `class/level` pairs reach the collector stream (ADR-016 section 11); utilization warnings may be invisible.

## Notes

- BatteryTempStreamStale at the end of the replay ignored (1 change(s))
