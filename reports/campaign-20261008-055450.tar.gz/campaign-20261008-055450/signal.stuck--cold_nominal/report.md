# Evidence Report - signal.stuck--cold_nominal

- **Campaign:** signal.stuck
- **Scenario:** cold_nominal
- **Run ID:** signal.stuck--cold_nominal
- **Generated:** 2026-10-08T06:10:45Z
- **Verdict:** **PASS**

## Provenance and reproduction

- Case (ASC): [case.asc](../experiments/signal.stuck/cold_nominal/case.asc)
- Ground truth: [case.ground_truth.yaml](../experiments/signal.stuck/cold_nominal/case.ground_truth.yaml)
- Oracle: [case.oracle.yaml](../experiments/signal.stuck/cold_nominal/case.oracle.yaml)
- Experiment: [experiment.yaml](../experiments/signal.stuck/cold_nominal/experiment.yaml)
- Logs: `can.log`, `collector.log`, `dfm.log`, `dfm_sovd_bridge.log`, `guardian.log`, `vss_bridge.log`, `collector.out`
- Case path (as recorded): `/app/reports/campaign-20261008-055450/experiments/signal.stuck/cold_nominal/case`

## Diagnostic chain

```text
replay (ASC) -> KUKSA CAN Provider -> KUKSA Data Broker -> VSS uProtocol Publisher -> Battery Thermal Guardian -> DFM -> OpenSOVD -> Evidence Collector
```

## Fault catalog

| Fault code | Category | Severity | Description |
|---|---|---|---|
| BatterySignalStuck | Communication | Error | A battery signal stayed flat while other signals changed (stuck signal). |
| BatterySocRate | Configuration | Error | State of charge changed faster than physically possible. |
| BatteryTempRate | Configuration | Error | Temperature changed faster than physically possible. |
| BatteryTempStreamStale | Communication | Error | No battery temperature sample received within the missing-packet timeout. |

## Injections

### signal-stuck-1 - signal.stuck

- Verdict: **PASS** (0/0 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 1000..1900 ms (slot 1000..4500)
- `temp_avg` / `stuck`: requested duration_samples=9; executed [-9, -9, -9, -9, -9, -9, -9, -9, -9]

### signal-stuck-2 - signal.stuck

- Verdict: **PASS** (6/6 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 4500..5500 ms (slot 4500..8000)
- `temp_avg` / `stuck`: requested duration_samples=10; executed [-7.5, -7.5, -7.5, -7.5, -7.5, -7.5, -7.5, -7.5, -7.5, -7.5]
- `soc` / `drift`: requested duration_samples=10, rate_per_sample=-0.5; executed [86.5, 86, 85.5, 85, 84.5, 84, 83.5, 83, 82.5, 82]

### signal-stuck-3 - signal.stuck

- Verdict: **PASS** (8/8 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 8000..9100 ms (slot 8000..11500)
- `temp_avg` / `stuck`: requested duration_samples=11; executed [-6, -6, -6, -6, -6, -6, -6, -6, -6, -6, -6]
- `soc` / `drift`: requested duration_samples=11, rate_per_sample=-0.5; executed [86, 85.5, 85, 84.5, 84, 83.5, 83, 82.5, 82, 81.5, 81]

### signal-stuck-4 - signal.stuck

- Verdict: **PASS** (6/6 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 11500..13000 ms (slot 11500..15000)
- `temp_avg` / `stuck`: requested duration_samples=15; executed [-4, -4, -4, -4, -4, -4, -4, -4, -4, -4, -4, -4, -4, -4, -4]
- `soc` / `drift`: requested duration_samples=15, rate_per_sample=-0.5; executed [85, 84.5, 84, 83.5, 83, 82.5, 82, 81.5, 81, 80.5, 80, 79.5, 79, 78.5, 78]

### signal-stuck-5 - signal.stuck

- Verdict: **PASS** (6/6 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 15000..17000 ms (slot 15000..-)
- `temp_avg` / `stuck`: requested duration_samples=20; executed [-2.5, -2.5, -2.5, -2.5, -2.5, -2.5, -2.5, -2.5, -2.5, -2.5, -2.5, -2.5, -2.5, -2.5, -2.5, -2.5, -2.5, -2.5, -2.5, -2.5]
- `soc` / `drift`: requested duration_samples=20, rate_per_sample=-0.5; executed [84, 83.5, 83, 82.5, 82, 81.5, 81, 80.5, 80, 79.5, 79, 78.5, 78, 77.5, 77, 76.5, 76, 75.5, 75, 74.5]

## Expected vs. observed

Oracle: 26 expected, 26 matched, 0 missing, 0 not reached, 0 unexpected, 0 not applicable

| Status | Fault | Class | Level | Stage | Expected ms | Observed ms | Signal | OpenSOVD ms |
|---|---|---|---|---|---|---|---|---|
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 4900 | 4900 | temp_max | 4967 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 5500 | 5500 | temp_avg | - |
| MATCHED | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Failed | 5500 | 5500 | soc | 5568 |
| MATCHED | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Passed | 5600 | 5600 | soc | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 5900 | 5900 | temp_min | 5965 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 6000 | 6000 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 8100 | 8100 | temp_avg | 8171 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 9100 | 9100 | temp_avg | - |
| MATCHED | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Failed | 9100 | 9100 | soc | 9168 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 9100 | 9100 | temp_avg | 9168 |
| MATCHED | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Passed | 9200 | 9200 | soc | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 9200 | 9200 | temp_avg | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 9900 | 9900 | temp_min | 9973 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 10000 | 10000 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 11900 | 11900 | temp_avg | 11976 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 13000 | 13000 | temp_min | - |
| MATCHED | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Failed | 13000 | 13000 | soc | 13076 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 13000 | 13000 | temp_avg | 13076 |
| MATCHED | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Passed | 13100 | 13100 | soc | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 13100 | 13100 | temp_avg | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 15100 | 15100 | temp_avg | 15171 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 17000 | 17000 | temp_avg | - |
| MATCHED | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Failed | 17000 | 17000 | soc | 17065 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 17000 | 17000 | temp_avg | 17065 |
| MATCHED | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Passed | 17100 | 17100 | soc | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 17100 | 17100 | temp_avg | - |

## Detection evidence

| t_ms | Fault | Class | Level | Stage | Signal | Observed | Limit | Residual | Utilization | Interval ms |
|---|---|---|---|---|---|---|---|---|---|---|
| 4900 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_max | 0 | 0.25 | - | - | - |
| 5500 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 5500 | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Failed | soc | 50 | 5 | 45 | - | 100 |
| 5600 | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Passed | soc | - | - | - | - | - |
| 5900 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 6000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 8100 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_avg | 0 | 0.25 | - | - | - |
| 9100 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_avg | 10 | 8 | 2 | 1.25 | 100 |
| 9100 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 9100 | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Failed | soc | 50 | 5 | 45 | - | 100 |
| 9200 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 9200 | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Passed | soc | - | - | - | - | - |
| 9900 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 10000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 11900 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_avg | 0 | 0.25 | - | - | - |
| 13000 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_avg | 10 | 8 | 2 | 1.25 | 100 |
| 13000 | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Failed | soc | 70 | 5 | 65 | - | 100 |
| 13000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 13100 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 13100 | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Passed | soc | - | - | - | - | - |
| 15100 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_avg | 0 | 0.25 | - | - | - |
| 17000 | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Failed | soc | 95 | 5 | 90 | - | 100 |
| 17000 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_avg | 15 | 8 | 7 | 1.875 | 100 |
| 17000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 17100 | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Passed | soc | - | - | - | - | - |
| 17100 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 20500 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | - | 545.0838 | 500 | 45.0838 | - | - |

## DFM / OpenSOVD correlation

- URL: `http://127.0.0.1:7690/sovd/v1/components/battery_guardian/data/faults`
- Polls: 234 (0 failed)
- Activations: 14; not visible: 0; unexplained: 1

| t_ms | Code |
|---|---|
| 4967 | BatterySignalStuck |
| 5568 | BatterySocRate |
| 5965 | BatterySignalStuck |
| 8171 | BatterySignalStuck |
| 9168 | BatterySocRate |
| 9168 | BatteryTempRate |
| 9973 | BatterySignalStuck |
| 11976 | BatterySignalStuck |
| 13076 | BatterySocRate |
| 13076 | BatteryTempRate |
| 15171 | BatterySignalStuck |
| 17065 | BatterySocRate |
| 17065 | BatteryTempRate |
| 20473 | BatteryTempStreamStale |

Unexplained: `BatteryTempStreamStale`@20473ms

## Timing

- Replay end: 19900 ms; battery stream end: 19900 ms

| Injection | Fault | Injected ms | Detected ms | Detection latency ms | OpenSOVD latency ms |
|---|---|---|---|---|---|
| signal-stuck-2 | BatterySignalStuck | 4500 | 4900 | 400 | 67 |
| signal-stuck-2 | BatterySignalStuck | 4500 | 5500 | 1000 | - |
| signal-stuck-2 | BatterySocRate | 4500 | 5500 | 1000 | 68 |
| signal-stuck-2 | BatterySocRate | 4500 | 5600 | 1100 | - |
| signal-stuck-2 | BatterySignalStuck | 4500 | 5900 | 1400 | 65 |
| signal-stuck-2 | BatterySignalStuck | 4500 | 6000 | 1500 | - |
| signal-stuck-3 | BatterySignalStuck | 8000 | 8100 | 100 | 71 |
| signal-stuck-3 | BatterySignalStuck | 8000 | 9100 | 1100 | - |
| signal-stuck-3 | BatterySocRate | 8000 | 9100 | 1100 | 68 |
| signal-stuck-3 | BatteryTempRate | 8000 | 9100 | 1100 | 68 |
| signal-stuck-3 | BatterySocRate | 8000 | 9200 | 1200 | - |
| signal-stuck-3 | BatteryTempRate | 8000 | 9200 | 1200 | - |
| signal-stuck-3 | BatterySignalStuck | 8000 | 9900 | 1900 | 73 |
| signal-stuck-3 | BatterySignalStuck | 8000 | 10000 | 2000 | - |
| signal-stuck-4 | BatterySignalStuck | 11500 | 11900 | 400 | 76 |
| signal-stuck-4 | BatterySignalStuck | 11500 | 13000 | 1500 | - |
| signal-stuck-4 | BatterySocRate | 11500 | 13000 | 1500 | 76 |
| signal-stuck-4 | BatteryTempRate | 11500 | 13000 | 1500 | 76 |
| signal-stuck-4 | BatterySocRate | 11500 | 13100 | 1600 | - |
| signal-stuck-4 | BatteryTempRate | 11500 | 13100 | 1600 | - |
| signal-stuck-5 | BatterySignalStuck | 15000 | 15100 | 100 | 71 |
| signal-stuck-5 | BatterySignalStuck | 15000 | 17000 | 2000 | - |
| signal-stuck-5 | BatterySocRate | 15000 | 17000 | 2000 | 65 |
| signal-stuck-5 | BatteryTempRate | 15000 | 17000 | 2000 | 65 |
| signal-stuck-5 | BatterySocRate | 15000 | 17100 | 2100 | - |
| signal-stuck-5 | BatteryTempRate | 15000 | 17100 | 2100 | - |

## Verdict rationale

All 26 expected Guardian change(s) matched and no unexpected change was observed.

## Observer artifacts

- Final live-observer view: [observer.html](observer.html)

Observer artifacts are illustrative only and never a source of evaluation facts.

## Gaps and limitations

- **Mitigation:** not instrumented (v1 is event-only, ADR-007) - no mitigation event is recorded; this chain link is intentionally absent.
- **OpenSOVD fault status:** only activation times are captured; the `testFailed`/`confirmedDtc`/`warningIndicator` triple is not observable.
- **Unmapped Guardian warnings:** only DFM-mapped `class/level` pairs reach the collector stream (ADR-016 section 11); utilization warnings may be invisible.

## Notes

- BatteryTempStreamStale at the end of the replay ignored (1 change(s))
