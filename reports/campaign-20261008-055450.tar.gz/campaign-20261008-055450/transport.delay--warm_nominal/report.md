# Evidence Report - transport.delay--warm_nominal

- **Campaign:** transport.delay
- **Scenario:** warm_nominal
- **Run ID:** transport.delay--warm_nominal
- **Generated:** 2026-10-08T06:10:45Z
- **Verdict:** **PASS**

## Provenance and reproduction

- Case (ASC): [case.asc](../experiments/transport.delay/warm_nominal/case.asc)
- Ground truth: [case.ground_truth.yaml](../experiments/transport.delay/warm_nominal/case.ground_truth.yaml)
- Oracle: [case.oracle.yaml](../experiments/transport.delay/warm_nominal/case.oracle.yaml)
- Experiment: [experiment.yaml](../experiments/transport.delay/warm_nominal/experiment.yaml)
- Logs: `can.log`, `collector.log`, `dfm.log`, `dfm_sovd_bridge.log`, `guardian.log`, `vss_bridge.log`, `collector.out`
- Case path (as recorded): `/app/reports/campaign-20261008-055450/experiments/transport.delay/warm_nominal/case`

## Diagnostic chain

```text
replay (ASC) -> KUKSA CAN Provider -> KUKSA Data Broker -> VSS uProtocol Publisher -> Battery Thermal Guardian -> DFM -> OpenSOVD -> Evidence Collector
```

## Fault catalog

| Fault code | Category | Severity | Description |
|---|---|---|---|
| BatteryTempStreamStale | Communication | Error | No battery temperature sample received within the missing-packet timeout. |

## Injections

### transport-delay-1 - transport.delay

- Verdict: **PASS** (0/0 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 1000..1100 ms (slot 1000..4800)
- Mutations: _(none - transport/source fault)_

### transport-delay-2 - transport.delay

- Verdict: **PASS** (0/0 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 4500..4600 ms (slot 4800..8700)
- Mutations: _(none - transport/source fault)_

### transport-delay-3 - transport.delay

- Verdict: **PASS** (2/2 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 8000..8100 ms (slot 8700..12800)
- Mutations: _(none - transport/source fault)_

### transport-delay-4 - transport.delay

- Verdict: **PASS** (2/2 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 11500..11600 ms (slot 12800..17200)
- Mutations: _(none - transport/source fault)_

### transport-delay-5 - transport.delay

- Verdict: **PASS** (2/2 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 15000..15100 ms (slot 17200..-)
- Mutations: _(none - transport/source fault)_

## Expected vs. observed

Oracle: 6 expected, 6 matched, 0 missing, 0 not reached, 0 unexpected, 0 not applicable

| Status | Fault | Class | Level | Stage | Expected ms | Observed ms | Signal | OpenSOVD ms |
|---|---|---|---|---|---|---|---|---|
| MATCHED | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | 9200 | 9200 | - | 9168 |
| MATCHED | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Passed | 9300 | 9300 | - | - |
| MATCHED | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | 13300 | 13300 | - | 13264 |
| MATCHED | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Passed | 13700 | 13700 | - | - |
| MATCHED | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | 17700 | 17700 | - | 17664 |
| MATCHED | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Passed | 19100 | 19100 | - | - |

## Detection evidence

| t_ms | Fault | Class | Level | Stage | Signal | Observed | Limit | Residual | Utilization | Interval ms |
|---|---|---|---|---|---|---|---|---|---|---|
| 9200 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | - | 540.81854 | 500 | 40.818542 | - | - |
| 9300 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Passed | - | - | - | - | - | - |
| 13300 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | - | 541.78064 | 500 | 41.78064 | - | - |
| 13700 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Passed | - | - | - | - | - | - |
| 17700 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | - | 541.494 | 500 | 41.49402 | - | - |
| 19100 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Passed | - | - | - | - | - | - |
| 24600 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | - | 541.2692 | 500 | 41.269226 | - | - |

## DFM / OpenSOVD correlation

- URL: `http://127.0.0.1:7690/sovd/v1/components/battery_guardian/data/faults`
- Polls: 275 (0 failed)
- Activations: 4; not visible: 0; unexplained: 1

| t_ms | Code |
|---|---|
| 9168 | BatteryTempStreamStale |
| 13264 | BatteryTempStreamStale |
| 17664 | BatteryTempStreamStale |
| 24567 | BatteryTempStreamStale |

Unexplained: `BatteryTempStreamStale`@24567ms

## Timing

- Replay end: 24000 ms; battery stream end: 24000 ms

| Injection | Fault | Injected ms | Detected ms | Detection latency ms | OpenSOVD latency ms |
|---|---|---|---|---|---|
| transport-delay-3 | BatteryTempStreamStale | 8000 | 9200 | 1200 | -32 |
| transport-delay-3 | BatteryTempStreamStale | 8000 | 9300 | 1300 | - |
| transport-delay-4 | BatteryTempStreamStale | 11500 | 13300 | 1800 | -36 |
| transport-delay-4 | BatteryTempStreamStale | 11500 | 13700 | 2200 | - |
| transport-delay-5 | BatteryTempStreamStale | 15000 | 17700 | 2700 | -36 |
| transport-delay-5 | BatteryTempStreamStale | 15000 | 19100 | 4100 | - |

## Verdict rationale

All 6 expected Guardian change(s) matched and no unexpected change was observed.

## Observer artifacts

- Final live-observer view: [observer.html](observer.html)

Observer artifacts are illustrative only and never a source of evaluation facts.

## Gaps and limitations

- **Mitigation:** not instrumented (v1 is event-only, ADR-007) - no mitigation event is recorded; this chain link is intentionally absent.
- **OpenSOVD fault status:** only activation times are captured; the `testFailed`/`confirmedDtc`/`warningIndicator` triple is not observable.
- **Unmapped Guardian warnings:** only DFM-mapped `class/level` pairs reach the collector stream (ADR-016 section 11); utilization warnings may be invisible.

## Notes

- BatteryTempStreamStale at the end of the replay ignored (1 change(s))
