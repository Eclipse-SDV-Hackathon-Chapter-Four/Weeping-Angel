# Evidence Report - transport.drop--hot_nominal

- **Campaign:** transport.drop
- **Scenario:** hot_nominal
- **Run ID:** transport.drop--hot_nominal
- **Generated:** 2026-10-08T06:10:45Z
- **Verdict:** **PASS**

## Provenance and reproduction

- Case (ASC): [case.asc](../experiments/transport.drop/hot_nominal/case.asc)
- Ground truth: [case.ground_truth.yaml](../experiments/transport.drop/hot_nominal/case.ground_truth.yaml)
- Oracle: [case.oracle.yaml](../experiments/transport.drop/hot_nominal/case.oracle.yaml)
- Experiment: [experiment.yaml](../experiments/transport.drop/hot_nominal/experiment.yaml)
- Logs: `can.log`, `collector.log`, `dfm.log`, `dfm_sovd_bridge.log`, `guardian.log`, `vss_bridge.log`, `collector.out`
- Case path (as recorded): `/app/reports/campaign-20261008-055450/experiments/transport.drop/hot_nominal/case`

## Diagnostic chain

```text
replay (ASC) -> KUKSA CAN Provider -> KUKSA Data Broker -> VSS uProtocol Publisher -> Battery Thermal Guardian -> DFM -> OpenSOVD -> Evidence Collector
```

## Fault catalog

| Fault code | Category | Severity | Description |
|---|---|---|---|
| BatteryOverTempWarning | Hardware | Warn | Maximum cell temperature entered the configured warning band. |
| BatterySignalStuck | Communication | Error | A battery signal stayed flat while other signals changed (stuck signal). |
| BatteryTempGenerationGap | Communication | Error | Source timestamps skipped at least one generation; battery samples were lost. |
| BatteryTempStreamStale | Communication | Error | No battery temperature sample received within the missing-packet timeout. |

## Injections

### transport-drop-1 - transport.drop

- Verdict: **PASS** (4/4 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 1000..1300 ms (slot 1000..4500)
- Mutations: _(none - transport/source fault)_

### transport-drop-2 - transport.drop

- Verdict: **PASS** (4/4 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 4500..4900 ms (slot 4500..8000)
- Mutations: _(none - transport/source fault)_

### transport-drop-3 - transport.drop

- Verdict: **PASS** (6/6 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 8000..8600 ms (slot 8000..11500)
- Mutations: _(none - transport/source fault)_

### transport-drop-4 - transport.drop

- Verdict: **PASS** (8/8 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 11500..12400 ms (slot 11500..15000)
- Mutations: _(none - transport/source fault)_

### transport-drop-5 - transport.drop

- Verdict: **PASS** (6/6 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 15000..16900 ms (slot 15000..-)
- Mutations: _(none - transport/source fault)_

## Expected vs. observed

Oracle: 29 expected, 29 matched, 0 missing, 0 not reached, 0 unexpected, 0 not applicable

| Status | Fault | Class | Level | Stage | Expected ms | Observed ms | Signal | OpenSOVD ms |
|---|---|---|---|---|---|---|---|---|
| MATCHED | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Failed | 0 | 0 | temp_max | 54 |
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | 1300 | 1300 | - | 1360 |
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | 1400 | 1400 | - | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 2000 | 2000 | temp_min | 2062 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 2200 | 2200 | temp_max | - |
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | 4900 | 4900 | - | 4958 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 5000 | 5000 | temp_min | 5061 |
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | 5000 | 5000 | - | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 5300 | 5300 | temp_avg | - |
| MATCHED | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | 8500 | 8500 | - | 8458 |
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | 8600 | 8600 | - | 8661 |
| MATCHED | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Passed | 8600 | 8600 | - | - |
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | 8700 | 8700 | - | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 9000 | 9000 | temp_avg | 9059 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 9500 | 9500 | temp_avg | - |
| MATCHED | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | 12000 | 12000 | - | 11960 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 12400 | 12400 | temp_avg | 12457 |
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | 12400 | 12400 | - | 12457 |
| MATCHED | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Passed | 12400 | 12400 | - | - |
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | 12500 | 12500 | - | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 12800 | 12800 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 13000 | 13000 | temp_max | 13059 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 13300 | 13300 | temp_avg | - |
| MATCHED | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | 15500 | 15500 | - | 15466 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 16900 | 16900 | temp_max | 16961 |
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | 16900 | 16900 | - | 16961 |
| MATCHED | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Passed | 16900 | 16900 | - | - |
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | 17000 | 17000 | - | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 17800 | 17800 | temp_min | - |

## Detection evidence

| t_ms | Fault | Class | Level | Stage | Signal | Observed | Limit | Residual | Utilization | Interval ms |
|---|---|---|---|---|---|---|---|---|---|---|
| 0 | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Failed | temp_max | 60 | 60 | 0 | - | - |
| 1300 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | - | 400 | 150 | 250 | - | 400 |
| 1400 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | - | - | - | - | - | - |
| 2000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 2200 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 4900 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | - | 500 | 150 | 350 | - | 500 |
| 5000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 5000 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | - | - | - | - | - | - |
| 5300 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 8500 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | - | 537.3798 | 500 | 37.37982 | - | - |
| 8600 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Passed | - | - | - | - | - | - |
| 8600 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | - | 700 | 150 | 550 | - | 700 |
| 8700 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | - | - | - | - | - | - |
| 9000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_avg | 0 | 0.25 | - | - | - |
| 9500 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 12000 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | - | 537.81946 | 500 | 37.819458 | - | - |
| 12400 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_avg | 0 | 0.25 | - | - | - |
| 12400 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | - | 1000 | 150 | 850 | - | 1000 |
| 12400 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Passed | - | - | - | - | - | - |
| 12500 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | - | - | - | - | - | - |
| 12800 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 13000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_max | 0 | 0.25 | - | - | - |
| 13300 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 15500 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | - | 538.16675 | 500 | 38.166748 | - | - |
| 16900 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_max | 0 | 0.25 | - | - | - |
| 16900 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | - | 2000 | 150 | 1850 | - | 2000 |
| 16900 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Passed | - | - | - | - | - | - |
| 17000 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | - | - | - | - | - | - |
| 17800 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 20500 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | - | 538.00684 | 500 | 38.006836 | - | - |

## DFM / OpenSOVD correlation

- URL: `http://127.0.0.1:7690/sovd/v1/components/battery_guardian/data/faults`
- Polls: 234 (0 failed)
- Activations: 16; not visible: 0; unexplained: 1

| t_ms | Code |
|---|---|
| 54 | BatteryOverTempWarning |
| 1360 | BatteryTempGenerationGap |
| 2062 | BatterySignalStuck |
| 4958 | BatteryTempGenerationGap |
| 5061 | BatterySignalStuck |
| 8458 | BatteryTempStreamStale |
| 8661 | BatteryTempGenerationGap |
| 9059 | BatterySignalStuck |
| 11960 | BatteryTempStreamStale |
| 12457 | BatterySignalStuck |
| 12457 | BatteryTempGenerationGap |
| 13059 | BatterySignalStuck |
| 15466 | BatteryTempStreamStale |
| 16961 | BatterySignalStuck |
| 16961 | BatteryTempGenerationGap |
| 20459 | BatteryTempStreamStale |

Unexplained: `BatteryTempStreamStale`@20459ms

## Timing

- Replay end: 19900 ms; battery stream end: 19900 ms

| Injection | Fault | Injected ms | Detected ms | Detection latency ms | OpenSOVD latency ms |
|---|---|---|---|---|---|
| - | BatteryOverTempWarning | - | 0 | - | 54 |
| transport-drop-1 | BatteryTempGenerationGap | 1000 | 1300 | 300 | 60 |
| transport-drop-1 | BatteryTempGenerationGap | 1000 | 1400 | 400 | - |
| transport-drop-1 | BatterySignalStuck | 1000 | 2000 | 1000 | 62 |
| transport-drop-1 | BatterySignalStuck | 1000 | 2200 | 1200 | - |
| transport-drop-2 | BatteryTempGenerationGap | 4500 | 4900 | 400 | 58 |
| transport-drop-2 | BatterySignalStuck | 4500 | 5000 | 500 | 61 |
| transport-drop-2 | BatteryTempGenerationGap | 4500 | 5000 | 500 | - |
| transport-drop-2 | BatterySignalStuck | 4500 | 5300 | 800 | - |
| transport-drop-3 | BatteryTempStreamStale | 8000 | 8500 | 500 | -42 |
| transport-drop-3 | BatteryTempGenerationGap | 8000 | 8600 | 600 | 61 |
| transport-drop-3 | BatteryTempStreamStale | 8000 | 8600 | 600 | - |
| transport-drop-3 | BatteryTempGenerationGap | 8000 | 8700 | 700 | - |
| transport-drop-3 | BatterySignalStuck | 8000 | 9000 | 1000 | 59 |
| transport-drop-3 | BatterySignalStuck | 8000 | 9500 | 1500 | - |
| transport-drop-4 | BatteryTempStreamStale | 11500 | 12000 | 500 | -40 |
| transport-drop-4 | BatterySignalStuck | 11500 | 12400 | 900 | 57 |
| transport-drop-4 | BatteryTempGenerationGap | 11500 | 12400 | 900 | 57 |
| transport-drop-4 | BatteryTempStreamStale | 11500 | 12400 | 900 | - |
| transport-drop-4 | BatteryTempGenerationGap | 11500 | 12500 | 1000 | - |
| transport-drop-4 | BatterySignalStuck | 11500 | 12800 | 1300 | - |
| transport-drop-4 | BatterySignalStuck | 11500 | 13000 | 1500 | 59 |
| transport-drop-4 | BatterySignalStuck | 11500 | 13300 | 1800 | - |
| transport-drop-5 | BatteryTempStreamStale | 15000 | 15500 | 500 | -34 |
| transport-drop-5 | BatterySignalStuck | 15000 | 16900 | 1900 | 61 |
| transport-drop-5 | BatteryTempGenerationGap | 15000 | 16900 | 1900 | 61 |
| transport-drop-5 | BatteryTempStreamStale | 15000 | 16900 | 1900 | - |
| transport-drop-5 | BatteryTempGenerationGap | 15000 | 17000 | 2000 | - |
| transport-drop-5 | BatterySignalStuck | 15000 | 17800 | 2800 | - |

## Verdict rationale

All 29 expected Guardian change(s) matched and no unexpected change was observed.

## Observer artifacts

- Final live-observer view: [observer.html](observer.html)

Observer artifacts are illustrative only and never a source of evaluation facts.

## Gaps and limitations

- **Mitigation:** not instrumented (v1 is event-only, ADR-007) - no mitigation event is recorded; this chain link is intentionally absent.
- **OpenSOVD fault status:** only activation times are captured; the `testFailed`/`confirmedDtc`/`warningIndicator` triple is not observable.
- **Unmapped Guardian warnings:** only DFM-mapped `class/level` pairs reach the collector stream (ADR-016 section 11); utilization warnings may be invisible.

## Notes

- BatteryTempStreamStale at the end of the replay ignored (1 change(s))
