# Evidence Report - signal.spike--warm_nominal

- **Campaign:** signal.spike
- **Scenario:** warm_nominal
- **Run ID:** signal.spike--warm_nominal
- **Generated:** 2026-10-08T06:10:45Z
- **Verdict:** **PASS**

## Provenance and reproduction

- Case (ASC): [case.asc](../experiments/signal.spike/warm_nominal/case.asc)
- Ground truth: [case.ground_truth.yaml](../experiments/signal.spike/warm_nominal/case.ground_truth.yaml)
- Oracle: [case.oracle.yaml](../experiments/signal.spike/warm_nominal/case.oracle.yaml)
- Experiment: [experiment.yaml](../experiments/signal.spike/warm_nominal/experiment.yaml)
- Logs: `can.log`, `collector.log`, `dfm.log`, `dfm_sovd_bridge.log`, `guardian.log`, `vss_bridge.log`, `collector.out`
- Case path (as recorded): `/app/reports/campaign-20261008-055450/experiments/signal.spike/warm_nominal/case`

## Diagnostic chain

```text
replay (ASC) -> KUKSA CAN Provider -> KUKSA Data Broker -> VSS uProtocol Publisher -> Battery Thermal Guardian -> DFM -> OpenSOVD -> Evidence Collector
```

## Fault catalog

| Fault code | Category | Severity | Description |
|---|---|---|---|
| BatterySignalStuck | Communication | Error | A battery signal stayed flat while other signals changed (stuck signal). |
| BatteryTempRate | Configuration | Error | Temperature changed faster than physically possible. |
| BatteryTempStreamStale | Communication | Error | No battery temperature sample received within the missing-packet timeout. |

## Injections

### signal-spike-1 - signal.spike

- Verdict: **PASS** (0/0 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 1000..1100 ms (slot 1000..4500)
- `temp_max` / `spike`: requested duration_samples=1, delta=0.5; executed [32]

### signal-spike-2 - signal.spike

- Verdict: **PASS** (0/0 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 4500..4600 ms (slot 4500..8000)
- `temp_max` / `spike`: requested duration_samples=1, delta=0.5; executed [33.5]

### signal-spike-3 - signal.spike

- Verdict: **PASS** (0/0 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 8000..8100 ms (slot 8000..11500)
- `temp_max` / `spike`: requested duration_samples=1, delta=0.5; executed [35]

### signal-spike-4 - signal.spike

- Verdict: **PASS** (4/4 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 11500..11600 ms (slot 11500..15000)
- `temp_max` / `spike`: requested duration_samples=1, delta=0.5; executed [37]

### signal-spike-5 - signal.spike

- Verdict: **PASS** (4/4 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 15000..15100 ms (slot 15000..-)
- `temp_max` / `spike`: requested duration_samples=1, delta=0.5; executed [38.5]

## Expected vs. observed

Oracle: 8 expected, 8 matched, 0 missing, 0 not reached, 0 unexpected, 6 not applicable

| Status | Fault | Class | Level | Stage | Expected ms | Observed ms | Signal | OpenSOVD ms |
|---|---|---|---|---|---|---|---|---|
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 11500 | 11500 | temp_max | 11560 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 11700 | 11700 | temp_avg | 11763 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 11700 | 11700 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 12000 | 12000 | temp_min | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 15000 | 15000 | temp_max | 15061 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 15200 | 15200 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 15300 | 15300 | temp_avg | 15366 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 15600 | 15600 | temp_avg | - |

## Detection evidence

| t_ms | Fault | Class | Level | Stage | Signal | Observed | Limit | Residual | Utilization | Interval ms |
|---|---|---|---|---|---|---|---|---|---|---|
| 11500 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_max | 10 | 7.13 | 2.87 | 1.4025245 | 100 |
| 11700 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_avg | 0 | 0.25 | - | - | - |
| 11700 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 12000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 15000 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_max | 10 | 7.04 | 2.96 | 1.4204545 | 100 |
| 15200 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 15300 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_avg | 0 | 0.25 | - | - | - |
| 15600 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 20500 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | - | 539.15875 | 500 | 39.158752 | - | - |

## DFM / OpenSOVD correlation

- URL: `http://127.0.0.1:7690/sovd/v1/components/battery_guardian/data/faults`
- Polls: 234 (0 failed)
- Activations: 5; not visible: 0; unexplained: 1

| t_ms | Code |
|---|---|
| 11560 | BatteryTempRate |
| 11763 | BatterySignalStuck |
| 15061 | BatteryTempRate |
| 15366 | BatterySignalStuck |
| 20462 | BatteryTempStreamStale |

Unexplained: `BatteryTempStreamStale`@20462ms

## Timing

- Replay end: 19900 ms; battery stream end: 19900 ms

| Injection | Fault | Injected ms | Detected ms | Detection latency ms | OpenSOVD latency ms |
|---|---|---|---|---|---|
| signal-spike-4 | BatteryTempRate | 11500 | 11500 | 0 | 60 |
| signal-spike-4 | BatterySignalStuck | 11500 | 11700 | 200 | 63 |
| signal-spike-4 | BatteryTempRate | 11500 | 11700 | 200 | - |
| signal-spike-4 | BatterySignalStuck | 11500 | 12000 | 500 | - |
| signal-spike-5 | BatteryTempRate | 15000 | 15000 | 0 | 61 |
| signal-spike-5 | BatteryTempRate | 15000 | 15200 | 200 | - |
| signal-spike-5 | BatterySignalStuck | 15000 | 15300 | 300 | 66 |
| signal-spike-5 | BatterySignalStuck | 15000 | 15600 | 600 | - |

## Verdict rationale

All 8 expected Guardian change(s) matched and no unexpected change was observed.

## Observer artifacts

- Final live-observer view: [observer.html](observer.html)

Observer artifacts are illustrative only and never a source of evaluation facts.

## Gaps and limitations

- **Mitigation:** not instrumented (v1 is event-only, ADR-007) - no mitigation event is recorded; this chain link is intentionally absent.
- **OpenSOVD fault status:** only activation times are captured; the `testFailed`/`confirmedDtc`/`warningIndicator` triple is not observable.
- **Unmapped Guardian warnings:** only DFM-mapped `class/level` pairs reach the collector stream (ADR-016 section 11); utilization warnings may be invisible.

## Notes

- BatteryTempStreamStale at the end of the replay ignored (1 change(s))
