# Evidence Report - signal.out_of_range--warm_nominal

- **Campaign:** signal.out_of_range
- **Scenario:** warm_nominal
- **Run ID:** signal.out_of_range--warm_nominal
- **Generated:** 2026-10-08T06:10:45Z
- **Verdict:** **PASS**

## Provenance and reproduction

- Case (ASC): [case.asc](../experiments/signal.out_of_range/warm_nominal/case.asc)
- Ground truth: [case.ground_truth.yaml](../experiments/signal.out_of_range/warm_nominal/case.ground_truth.yaml)
- Oracle: [case.oracle.yaml](../experiments/signal.out_of_range/warm_nominal/case.oracle.yaml)
- Experiment: [experiment.yaml](../experiments/signal.out_of_range/warm_nominal/experiment.yaml)
- Logs: `can.log`, `collector.log`, `dfm.log`, `dfm_sovd_bridge.log`, `guardian.log`, `vss_bridge.log`, `collector.out`
- Case path (as recorded): `/app/reports/campaign-20261008-055450/experiments/signal.out_of_range/warm_nominal/case`

## Diagnostic chain

```text
replay (ASC) -> KUKSA CAN Provider -> KUKSA Data Broker -> VSS uProtocol Publisher -> Battery Thermal Guardian -> DFM -> OpenSOVD -> Evidence Collector
```

## Fault catalog

| Fault code | Category | Severity | Description |
|---|---|---|---|
| BatteryOverTempCritical | Hardware | Fatal | Maximum cell temperature reached the configured critical band. |
| BatterySignalStuck | Communication | Error | A battery signal stayed flat while other signals changed (stuck signal). |
| BatteryTempAbsoluteLimit | Hardware | Fatal | Battery temperature outside the absolute physical limits. |
| BatteryTempHotspot | Hardware | Error | Max temperature deviates from average beyond the hotspot limit. |
| BatteryTempRate | Configuration | Error | Temperature changed faster than physically possible. |
| BatteryTempSpread | Hardware | Error | Spread between max and min temperature exceeds the physical limit. |
| BatteryTempStreamStale | Communication | Error | No battery temperature sample received within the missing-packet timeout. |

## Injections

### signal-out_of_range-1 - signal.out_of_range

- Verdict: **PASS** (10/10 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 1000..1500 ms (slot 1000..4500)
- `temp_min` / `out_of_range`: requested duration_samples=5, value=-30; executed [-30, -30, -30, -30, -30]

### signal-out_of_range-2 - signal.out_of_range

- Verdict: **PASS** (12/12 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 4500..5000 ms (slot 4500..8000)
- `temp_min` / `out_of_range`: requested duration_samples=5, value=-30.5; executed [-30.5, -30.5, -30.5, -30.5, -30.5]

### signal-out_of_range-3 - signal.out_of_range

- Verdict: **PASS** (14/14 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 8000..8500 ms (slot 8000..11500)
- `temp_max` / `out_of_range`: requested duration_samples=5, value=70; executed [70, 70, 70, 70, 70]

### signal-out_of_range-4 - signal.out_of_range

- Verdict: **PASS** (14/14 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 11500..12000 ms (slot 11500..15000)
- `temp_max` / `out_of_range`: requested duration_samples=5, value=70.5; executed [70.5, 70.5, 70.5, 70.5, 70.5]

### signal-out_of_range-5 - signal.out_of_range

- Verdict: **PASS** (14/14 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 15000..15500 ms (slot 15000..-)
- `temp_max` / `out_of_range`: requested duration_samples=5, value=75; executed [75, 75, 75, 75, 75]

## Expected vs. observed

Oracle: 64 expected, 64 matched, 0 missing, 0 not reached, 0 unexpected, 0 not applicable

| Status | Fault | Class | Level | Stage | Expected ms | Observed ms | Signal | OpenSOVD ms |
|---|---|---|---|---|---|---|---|---|
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 1000 | 1000 | temp_avg | 1074 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 1000 | 1000 | temp_min | 1074 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | 1000 | 1000 | - | 1074 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 1100 | 1100 | temp_min | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 1200 | 1200 | temp_avg | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 1500 | 1500 | temp_min | 1572 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | 1500 | 1500 | - | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 1600 | 1600 | temp_min | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 2100 | 2100 | temp_max | 2174 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 2400 | 2400 | temp_avg | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 4500 | 4500 | temp_max | 4576 |
| MATCHED | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Failed | 4500 | 4500 | temp_min | 4576 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 4500 | 4500 | temp_min | 4576 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | 4500 | 4500 | - | 4576 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 4600 | 4600 | temp_min | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 4800 | 4800 | temp_avg | - |
| MATCHED | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Passed | 5000 | 5000 | temp_min | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 5000 | 5000 | temp_min | 5075 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | 5000 | 5000 | - | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 5100 | 5100 | temp_min | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 5700 | 5700 | temp_avg | 5778 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 5900 | 5900 | temp_avg | - |
| MATCHED | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Failed | 8000 | 8000 | temp_max | 8077 |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | 8000 | 8000 | temp_max | 8077 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 8000 | 8000 | temp_max | 8077 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | 8000 | 8000 | - | 8077 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 8100 | 8100 | temp_avg | 8179 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 8100 | 8100 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 8400 | 8400 | temp_avg | - |
| MATCHED | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Passed | 8500 | 8500 | temp_max | - |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | 8500 | 8500 | temp_max | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 8500 | 8500 | temp_max | 8577 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | 8500 | 8500 | - | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 8600 | 8600 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 9300 | 9300 | temp_min | 9371 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 9400 | 9400 | temp_avg | - |
| MATCHED | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Failed | 11500 | 11500 | temp_max | 11573 |
| MATCHED | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Failed | 11500 | 11500 | temp_max | 11573 |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | 11500 | 11500 | temp_max | 11573 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 11500 | 11500 | temp_max | 11573 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | 11500 | 11500 | - | 11573 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 11600 | 11600 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 11700 | 11700 | temp_min | 11777 |
| MATCHED | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Passed | 12000 | 12000 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 12000 | 12000 | temp_min | - |
| MATCHED | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Passed | 12000 | 12000 | temp_max | - |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | 12000 | 12000 | temp_max | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 12000 | 12000 | temp_max | 12073 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | 12000 | 12000 | - | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 12100 | 12100 | temp_max | - |
| MATCHED | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Failed | 15000 | 15000 | temp_max | 15077 |
| MATCHED | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Failed | 15000 | 15000 | temp_max | 15077 |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | 15000 | 15000 | temp_max | 15077 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 15000 | 15000 | temp_max | 15077 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | 15000 | 15000 | - | 15077 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 15100 | 15100 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 15300 | 15300 | temp_avg | 15373 |
| MATCHED | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Passed | 15500 | 15500 | temp_max | - |
| MATCHED | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Passed | 15500 | 15500 | temp_max | - |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | 15500 | 15500 | temp_max | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 15500 | 15500 | temp_max | 15577 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | 15500 | 15500 | - | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 15600 | 15600 | temp_avg | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 15600 | 15600 | temp_max | - |

## Detection evidence

| t_ms | Fault | Class | Level | Stage | Signal | Observed | Limit | Residual | Utilization | Interval ms |
|---|---|---|---|---|---|---|---|---|---|---|
| 1000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_avg | 0 | 0.25 | - | - | - |
| 1000 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | - | 61.5 | 11 | 50.5 | 5.590909 | - |
| 1000 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_min | 575 | 6 | 569 | 95.833336 | 100 |
| 1100 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 1200 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 1500 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_min | 580 | 7.37 | 572.63 | 78.697426 | 100 |
| 1500 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | - | - | - | - | - | - |
| 1600 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 2100 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_max | 0 | 0.25 | - | - | - |
| 2400 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 4500 | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Failed | temp_min | -30.5 | -30 | 0.5 | - | - |
| 4500 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_max | 0 | 0.25 | - | - | - |
| 4500 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | - | 63.5 | 10.85 | 52.65 | 5.8525343 | - |
| 4500 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_min | 595 | 6 | 589 | 99.166664 | 100 |
| 4600 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 4800 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 5000 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_min | 600 | 7.28 | 592.72 | 82.41758 | 100 |
| 5000 | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 5000 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | - | - | - | - | - | - |
| 5100 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 5700 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_avg | 0 | 0.25 | - | - | - |
| 5900 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 8000 | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Failed | temp_max | 70 | 70 | 0 | - | - |
| 8000 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | temp_max | 37 | 4.2200003 | 32.78 | 8.767772 | - |
| 8000 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_max | 355 | 7.2200003 | 347.78 | 49.168972 | 100 |
| 8000 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | - | 39.5 | 10.7 | 28.8 | 3.6915889 | - |
| 8100 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_avg | 0 | 0.25 | - | - | - |
| 8100 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 8400 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 8500 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_max | 350 | 6 | 344 | 58.333332 | 100 |
| 8500 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 8500 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | - | - | - | - | - | - |
| 8500 | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Passed | temp_max | - | - | - | - | - |
| 8600 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 9300 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 9400 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 11500 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | temp_max | 36 | 4.13 | 31.869999 | 8.716707 | - |
| 11500 | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Failed | temp_max | 70.5 | 70 | 0.5 | - | - |
| 11500 | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Failed | temp_max | 70.5 | 70 | 0.5 | - | - |
| 11500 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | - | 38.5 | 10.55 | 27.95 | 3.6492891 | - |
| 11500 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_max | 345 | 7.13 | 337.87 | 48.387096 | 100 |
| 11600 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 11700 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 12000 | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 12000 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_max | 340 | 6 | 334 | 56.666668 | 100 |
| 12000 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | - | - | - | - | - | - |
| 12000 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 12000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 12000 | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Passed | temp_max | - | - | - | - | - |
| 12100 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 15000 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_max | 375 | 7.04 | 367.96 | 53.267044 | 100 |
| 15000 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | - | 41.5 | 10.4 | 31.1 | 3.9903848 | - |
| 15000 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | temp_max | 39 | 4.04 | 34.96 | 9.653465 | - |
| 15000 | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Failed | temp_max | 75 | 70 | 5 | - | - |
| 15000 | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Failed | temp_max | 75 | 70 | 5 | - | - |
| 15100 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 15300 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_avg | 0 | 0.25 | - | - | - |
| 15500 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_max | 375 | 6 | 369 | 62.5 | 100 |
| 15500 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 15500 | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 15500 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | - | - | - | - | - | - |
| 15500 | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Passed | temp_max | - | - | - | - | - |
| 15600 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 15600 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 20500 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | - | 547.38324 | 500 | 47.38324 | - | - |

## DFM / OpenSOVD correlation

- URL: `http://127.0.0.1:7690/sovd/v1/components/battery_guardian/data/faults`
- Polls: 234 (0 failed)
- Activations: 33; not visible: 0; unexplained: 1

| t_ms | Code |
|---|---|
| 1074 | BatterySignalStuck |
| 1074 | BatteryTempRate |
| 1074 | BatteryTempSpread |
| 1572 | BatteryTempRate |
| 2174 | BatterySignalStuck |
| 4576 | BatterySignalStuck |
| 4576 | BatteryTempAbsoluteLimit |
| 4576 | BatteryTempRate |
| 4576 | BatteryTempSpread |
| 5075 | BatteryTempRate |
| 5778 | BatterySignalStuck |
| 8077 | BatteryOverTempCritical |
| 8077 | BatteryTempHotspot |
| 8077 | BatteryTempRate |
| 8077 | BatteryTempSpread |
| 8179 | BatterySignalStuck |
| 8577 | BatteryTempRate |
| 9371 | BatterySignalStuck |
| 11573 | BatteryOverTempCritical |
| 11573 | BatteryTempAbsoluteLimit |
| 11573 | BatteryTempHotspot |
| 11573 | BatteryTempRate |
| 11573 | BatteryTempSpread |
| 11777 | BatterySignalStuck |
| 12073 | BatteryTempRate |
| 15077 | BatteryOverTempCritical |
| 15077 | BatteryTempAbsoluteLimit |
| 15077 | BatteryTempHotspot |
| 15077 | BatteryTempRate |
| 15077 | BatteryTempSpread |
| 15373 | BatterySignalStuck |
| 15577 | BatteryTempRate |
| 20471 | BatteryTempStreamStale |

Unexplained: `BatteryTempStreamStale`@20471ms

## Timing

- Replay end: 19900 ms; battery stream end: 19900 ms

| Injection | Fault | Injected ms | Detected ms | Detection latency ms | OpenSOVD latency ms |
|---|---|---|---|---|---|
| signal-out_of_range-1 | BatterySignalStuck | 1000 | 1000 | 0 | 74 |
| signal-out_of_range-1 | BatteryTempRate | 1000 | 1000 | 0 | 74 |
| signal-out_of_range-1 | BatteryTempSpread | 1000 | 1000 | 0 | 74 |
| signal-out_of_range-1 | BatteryTempRate | 1000 | 1100 | 100 | - |
| signal-out_of_range-1 | BatterySignalStuck | 1000 | 1200 | 200 | - |
| signal-out_of_range-1 | BatteryTempRate | 1000 | 1500 | 500 | 72 |
| signal-out_of_range-1 | BatteryTempSpread | 1000 | 1500 | 500 | - |
| signal-out_of_range-1 | BatteryTempRate | 1000 | 1600 | 600 | - |
| signal-out_of_range-1 | BatterySignalStuck | 1000 | 2100 | 1100 | 74 |
| signal-out_of_range-1 | BatterySignalStuck | 1000 | 2400 | 1400 | - |
| signal-out_of_range-2 | BatterySignalStuck | 4500 | 4500 | 0 | 76 |
| signal-out_of_range-2 | BatteryTempAbsoluteLimit | 4500 | 4500 | 0 | 76 |
| signal-out_of_range-2 | BatteryTempRate | 4500 | 4500 | 0 | 76 |
| signal-out_of_range-2 | BatteryTempSpread | 4500 | 4500 | 0 | 76 |
| signal-out_of_range-2 | BatteryTempRate | 4500 | 4600 | 100 | - |
| signal-out_of_range-2 | BatterySignalStuck | 4500 | 4800 | 300 | - |
| signal-out_of_range-2 | BatteryTempAbsoluteLimit | 4500 | 5000 | 500 | - |
| signal-out_of_range-2 | BatteryTempRate | 4500 | 5000 | 500 | 75 |
| signal-out_of_range-2 | BatteryTempSpread | 4500 | 5000 | 500 | - |
| signal-out_of_range-2 | BatteryTempRate | 4500 | 5100 | 600 | - |
| signal-out_of_range-2 | BatterySignalStuck | 4500 | 5700 | 1200 | 78 |
| signal-out_of_range-2 | BatterySignalStuck | 4500 | 5900 | 1400 | - |
| signal-out_of_range-3 | BatteryOverTempCritical | 8000 | 8000 | 0 | 77 |
| signal-out_of_range-3 | BatteryTempHotspot | 8000 | 8000 | 0 | 77 |
| signal-out_of_range-3 | BatteryTempRate | 8000 | 8000 | 0 | 77 |
| signal-out_of_range-3 | BatteryTempSpread | 8000 | 8000 | 0 | 77 |
| signal-out_of_range-3 | BatterySignalStuck | 8000 | 8100 | 100 | 79 |
| signal-out_of_range-3 | BatteryTempRate | 8000 | 8100 | 100 | - |
| signal-out_of_range-3 | BatterySignalStuck | 8000 | 8400 | 400 | - |
| signal-out_of_range-3 | BatteryOverTempCritical | 8000 | 8500 | 500 | - |
| signal-out_of_range-3 | BatteryTempHotspot | 8000 | 8500 | 500 | - |
| signal-out_of_range-3 | BatteryTempRate | 8000 | 8500 | 500 | 77 |
| signal-out_of_range-3 | BatteryTempSpread | 8000 | 8500 | 500 | - |
| signal-out_of_range-3 | BatteryTempRate | 8000 | 8600 | 600 | - |
| signal-out_of_range-3 | BatterySignalStuck | 8000 | 9300 | 1300 | 71 |
| signal-out_of_range-3 | BatterySignalStuck | 8000 | 9400 | 1400 | - |
| signal-out_of_range-4 | BatteryOverTempCritical | 11500 | 11500 | 0 | 73 |
| signal-out_of_range-4 | BatteryTempAbsoluteLimit | 11500 | 11500 | 0 | 73 |
| signal-out_of_range-4 | BatteryTempHotspot | 11500 | 11500 | 0 | 73 |
| signal-out_of_range-4 | BatteryTempRate | 11500 | 11500 | 0 | 73 |
| signal-out_of_range-4 | BatteryTempSpread | 11500 | 11500 | 0 | 73 |
| signal-out_of_range-4 | BatteryTempRate | 11500 | 11600 | 100 | - |
| signal-out_of_range-4 | BatterySignalStuck | 11500 | 11700 | 200 | 77 |
| signal-out_of_range-4 | BatteryOverTempCritical | 11500 | 12000 | 500 | - |
| signal-out_of_range-4 | BatterySignalStuck | 11500 | 12000 | 500 | - |
| signal-out_of_range-4 | BatteryTempAbsoluteLimit | 11500 | 12000 | 500 | - |
| signal-out_of_range-4 | BatteryTempHotspot | 11500 | 12000 | 500 | - |
| signal-out_of_range-4 | BatteryTempRate | 11500 | 12000 | 500 | 73 |
| signal-out_of_range-4 | BatteryTempSpread | 11500 | 12000 | 500 | - |
| signal-out_of_range-4 | BatteryTempRate | 11500 | 12100 | 600 | - |
| signal-out_of_range-5 | BatteryOverTempCritical | 15000 | 15000 | 0 | 77 |
| signal-out_of_range-5 | BatteryTempAbsoluteLimit | 15000 | 15000 | 0 | 77 |
| signal-out_of_range-5 | BatteryTempHotspot | 15000 | 15000 | 0 | 77 |
| signal-out_of_range-5 | BatteryTempRate | 15000 | 15000 | 0 | 77 |
| signal-out_of_range-5 | BatteryTempSpread | 15000 | 15000 | 0 | 77 |
| signal-out_of_range-5 | BatteryTempRate | 15000 | 15100 | 100 | - |
| signal-out_of_range-5 | BatterySignalStuck | 15000 | 15300 | 300 | 73 |
| signal-out_of_range-5 | BatteryOverTempCritical | 15000 | 15500 | 500 | - |
| signal-out_of_range-5 | BatteryTempAbsoluteLimit | 15000 | 15500 | 500 | - |
| signal-out_of_range-5 | BatteryTempHotspot | 15000 | 15500 | 500 | - |
| signal-out_of_range-5 | BatteryTempRate | 15000 | 15500 | 500 | 77 |
| signal-out_of_range-5 | BatteryTempSpread | 15000 | 15500 | 500 | - |
| signal-out_of_range-5 | BatterySignalStuck | 15000 | 15600 | 600 | - |
| signal-out_of_range-5 | BatteryTempRate | 15000 | 15600 | 600 | - |

## Verdict rationale

All 64 expected Guardian change(s) matched and no unexpected change was observed.

## Observer artifacts

- Final live-observer view: [observer.html](observer.html)

Observer artifacts are illustrative only and never a source of evaluation facts.

## Gaps and limitations

- **Mitigation:** not instrumented (v1 is event-only, ADR-007) - no mitigation event is recorded; this chain link is intentionally absent.
- **OpenSOVD fault status:** only activation times are captured; the `testFailed`/`confirmedDtc`/`warningIndicator` triple is not observable.
- **Unmapped Guardian warnings:** only DFM-mapped `class/level` pairs reach the collector stream (ADR-016 section 11); utilization warnings may be invisible.

## Notes

- BatteryTempStreamStale at the end of the replay ignored (1 change(s))
