# Evidence Report - transport.drop--warm_nominal

- **Campaign:** transport.drop
- **Scenario:** warm_nominal
- **Run ID:** transport.drop--warm_nominal
- **Generated:** 2026-10-08T06:10:45Z
- **Verdict:** **PASS**

## Provenance and reproduction

- Case (ASC): [case.asc](../experiments/transport.drop/warm_nominal/case.asc)
- Ground truth: [case.ground_truth.yaml](../experiments/transport.drop/warm_nominal/case.ground_truth.yaml)
- Oracle: [case.oracle.yaml](../experiments/transport.drop/warm_nominal/case.oracle.yaml)
- Experiment: [experiment.yaml](../experiments/transport.drop/warm_nominal/experiment.yaml)
- Logs: `can.log`, `collector.log`, `dfm.log`, `dfm_sovd_bridge.log`, `guardian.log`, `vss_bridge.log`, `collector.out`
- Case path (as recorded): `/app/reports/campaign-20261008-055450/experiments/transport.drop/warm_nominal/case`

## Diagnostic chain

```text
replay (ASC) -> KUKSA CAN Provider -> KUKSA Data Broker -> VSS uProtocol Publisher -> Battery Thermal Guardian -> DFM -> OpenSOVD -> Evidence Collector
```

## Fault catalog

| Fault code | Category | Severity | Description |
|---|---|---|---|
| BatteryTempGenerationGap | Communication | Error | Source timestamps skipped at least one generation; battery samples were lost. |
| BatteryTempStreamStale | Communication | Error | No battery temperature sample received within the missing-packet timeout. |

## Injections

### transport-drop-1 - transport.drop

- Verdict: **PASS** (2/2 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 1000..1300 ms (slot 1000..4500)
- Mutations: _(none - transport/source fault)_

### transport-drop-2 - transport.drop

- Verdict: **PASS** (2/2 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 4500..4900 ms (slot 4500..8000)
- Mutations: _(none - transport/source fault)_

### transport-drop-3 - transport.drop

- Verdict: **PASS** (4/4 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 8000..8600 ms (slot 8000..11500)
- Mutations: _(none - transport/source fault)_

### transport-drop-4 - transport.drop

- Verdict: **PASS** (4/4 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 11500..12400 ms (slot 11500..15000)
- Mutations: _(none - transport/source fault)_

### transport-drop-5 - transport.drop

- Verdict: **PASS** (4/4 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 15000..16900 ms (slot 15000..-)
- Mutations: _(none - transport/source fault)_

## Expected vs. observed

Oracle: 16 expected, 16 matched, 0 missing, 0 not reached, 0 unexpected, 0 not applicable

| Status | Fault | Class | Level | Stage | Expected ms | Observed ms | Signal | OpenSOVD ms |
|---|---|---|---|---|---|---|---|---|
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | 1300 | 1300 | - | 1364 |
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | 1400 | 1400 | - | - |
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | 4900 | 4900 | - | 4964 |
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | 5000 | 5000 | - | - |
| MATCHED | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | 8500 | 8500 | - | 8462 |
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | 8600 | 8600 | - | 8665 |
| MATCHED | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Passed | 8600 | 8600 | - | - |
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | 8700 | 8700 | - | - |
| MATCHED | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | 12000 | 12000 | - | 11961 |
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | 12400 | 12400 | - | 12459 |
| MATCHED | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Passed | 12400 | 12400 | - | - |
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | 12500 | 12500 | - | - |
| MATCHED | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | 15500 | 15500 | - | 15467 |
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | 16900 | 16900 | - | 16961 |
| MATCHED | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Passed | 16900 | 16900 | - | - |
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | 17000 | 17000 | - | - |

## Detection evidence

| t_ms | Fault | Class | Level | Stage | Signal | Observed | Limit | Residual | Utilization | Interval ms |
|---|---|---|---|---|---|---|---|---|---|---|
| 1300 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | - | 400 | 150 | 250 | - | 400 |
| 1400 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | - | - | - | - | - | - |
| 4900 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | - | 500 | 150 | 350 | - | 500 |
| 5000 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | - | - | - | - | - | - |
| 8500 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | - | 541.04034 | 500 | 41.040344 | - | - |
| 8600 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | - | 700 | 150 | 550 | - | 700 |
| 8600 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Passed | - | - | - | - | - | - |
| 8700 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | - | - | - | - | - | - |
| 12000 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | - | 540.7192 | 500 | 40.719177 | - | - |
| 12400 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Passed | - | - | - | - | - | - |
| 12400 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | - | 1000 | 150 | 850 | - | 1000 |
| 12500 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | - | - | - | - | - | - |
| 15500 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | - | 540.11914 | 500 | 40.11914 | - | - |
| 16900 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | - | 2000 | 150 | 1850 | - | 2000 |
| 16900 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Passed | - | - | - | - | - | - |
| 17000 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | - | - | - | - | - | - |
| 20500 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | - | 540.0872 | 500 | 40.08722 | - | - |

## DFM / OpenSOVD correlation

- URL: `http://127.0.0.1:7690/sovd/v1/components/battery_guardian/data/faults`
- Polls: 234 (0 failed)
- Activations: 9; not visible: 0; unexplained: 1

| t_ms | Code |
|---|---|
| 1364 | BatteryTempGenerationGap |
| 4964 | BatteryTempGenerationGap |
| 8462 | BatteryTempStreamStale |
| 8665 | BatteryTempGenerationGap |
| 11961 | BatteryTempStreamStale |
| 12459 | BatteryTempGenerationGap |
| 15467 | BatteryTempStreamStale |
| 16961 | BatteryTempGenerationGap |
| 20460 | BatteryTempStreamStale |

Unexplained: `BatteryTempStreamStale`@20460ms

## Timing

- Replay end: 19900 ms; battery stream end: 19900 ms

| Injection | Fault | Injected ms | Detected ms | Detection latency ms | OpenSOVD latency ms |
|---|---|---|---|---|---|
| transport-drop-1 | BatteryTempGenerationGap | 1000 | 1300 | 300 | 64 |
| transport-drop-1 | BatteryTempGenerationGap | 1000 | 1400 | 400 | - |
| transport-drop-2 | BatteryTempGenerationGap | 4500 | 4900 | 400 | 64 |
| transport-drop-2 | BatteryTempGenerationGap | 4500 | 5000 | 500 | - |
| transport-drop-3 | BatteryTempStreamStale | 8000 | 8500 | 500 | -38 |
| transport-drop-3 | BatteryTempGenerationGap | 8000 | 8600 | 600 | 65 |
| transport-drop-3 | BatteryTempStreamStale | 8000 | 8600 | 600 | - |
| transport-drop-3 | BatteryTempGenerationGap | 8000 | 8700 | 700 | - |
| transport-drop-4 | BatteryTempStreamStale | 11500 | 12000 | 500 | -39 |
| transport-drop-4 | BatteryTempGenerationGap | 11500 | 12400 | 900 | 59 |
| transport-drop-4 | BatteryTempStreamStale | 11500 | 12400 | 900 | - |
| transport-drop-4 | BatteryTempGenerationGap | 11500 | 12500 | 1000 | - |
| transport-drop-5 | BatteryTempStreamStale | 15000 | 15500 | 500 | -33 |
| transport-drop-5 | BatteryTempGenerationGap | 15000 | 16900 | 1900 | 61 |
| transport-drop-5 | BatteryTempStreamStale | 15000 | 16900 | 1900 | - |
| transport-drop-5 | BatteryTempGenerationGap | 15000 | 17000 | 2000 | - |

## Verdict rationale

All 16 expected Guardian change(s) matched and no unexpected change was observed.

## Observer artifacts

- Final live-observer view: [observer.html](observer.html)

Observer artifacts are illustrative only and never a source of evaluation facts.

## Gaps and limitations

- **Mitigation:** not instrumented (v1 is event-only, ADR-007) - no mitigation event is recorded; this chain link is intentionally absent.
- **OpenSOVD fault status:** only activation times are captured; the `testFailed`/`confirmedDtc`/`warningIndicator` triple is not observable.
- **Unmapped Guardian warnings:** only DFM-mapped `class/level` pairs reach the collector stream (ADR-016 section 11); utilization warnings may be invisible.

## Notes

- BatteryTempStreamStale at the end of the replay ignored (1 change(s))
