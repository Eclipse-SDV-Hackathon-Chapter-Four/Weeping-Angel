# Evidence Report - campaign-20261008-055450

- **Generated:** 2026-10-08T06:10:45Z
- **Runs:** 25 (PASS: 25)

## Runs

| Run | Injected class(es) | Verdict | Expected | Matched | Missing | Unexpected | Report |
|---|---|---|---|---|---|---|---|
| baseline--cold_nominal | (none) | PASS | 0 | 0 | 0 | 0 | [report.md](baseline--cold_nominal/report.md) |
| baseline--hot_nominal | (none) | PASS | 1 | 1 | 0 | 0 | [report.md](baseline--hot_nominal/report.md) |
| baseline--warm_nominal | (none) | PASS | 0 | 0 | 0 | 0 | [report.md](baseline--warm_nominal/report.md) |
| combined_example--warm_nominal | signal.combination | PASS | 64 | 64 | 0 | 0 | [report.md](combined_example--warm_nominal/report.md) |
| signal.drift--cold_nominal | signal.drift | PASS | 44 | 44 | 0 | 0 | [report.md](signal.drift--cold_nominal/report.md) |
| signal.drift--hot_nominal | signal.drift | PASS | 51 | 51 | 0 | 0 | [report.md](signal.drift--hot_nominal/report.md) |
| signal.drift--warm_nominal | signal.drift | PASS | 66 | 66 | 0 | 0 | [report.md](signal.drift--warm_nominal/report.md) |
| signal.out_of_range--cold_nominal | signal.out_of_range | PASS | 58 | 58 | 0 | 0 | [report.md](signal.out_of_range--cold_nominal/report.md) |
| signal.out_of_range--hot_nominal | signal.out_of_range | PASS | 65 | 65 | 0 | 0 | [report.md](signal.out_of_range--hot_nominal/report.md) |
| signal.out_of_range--warm_nominal | signal.out_of_range | PASS | 64 | 64 | 0 | 0 | [report.md](signal.out_of_range--warm_nominal/report.md) |
| signal.spike--cold_nominal | signal.spike | PASS | 8 | 8 | 0 | 0 | [report.md](signal.spike--cold_nominal/report.md) |
| signal.spike--hot_nominal | signal.spike | PASS | 9 | 9 | 0 | 0 | [report.md](signal.spike--hot_nominal/report.md) |
| signal.spike--warm_nominal | signal.spike | PASS | 8 | 8 | 0 | 0 | [report.md](signal.spike--warm_nominal/report.md) |
| signal.stuck--cold_nominal | signal.stuck | PASS | 26 | 26 | 0 | 0 | [report.md](signal.stuck--cold_nominal/report.md) |
| signal.stuck--hot_nominal | signal.stuck | PASS | 17 | 17 | 0 | 0 | [report.md](signal.stuck--hot_nominal/report.md) |
| signal.stuck--warm_nominal | signal.stuck | PASS | 24 | 24 | 0 | 0 | [report.md](signal.stuck--warm_nominal/report.md) |
| source.dropout--cold_nominal | source.dropout | PASS | 16 | 16 | 0 | 0 | [report.md](source.dropout--cold_nominal/report.md) |
| source.dropout--hot_nominal | source.dropout | PASS | 29 | 29 | 0 | 0 | [report.md](source.dropout--hot_nominal/report.md) |
| source.dropout--warm_nominal | source.dropout | PASS | 16 | 16 | 0 | 0 | [report.md](source.dropout--warm_nominal/report.md) |
| transport.delay--cold_nominal | transport.delay | PASS | 6 | 6 | 0 | 0 | [report.md](transport.delay--cold_nominal/report.md) |
| transport.delay--hot_nominal | transport.delay | PASS | 7 | 7 | 0 | 0 | [report.md](transport.delay--hot_nominal/report.md) |
| transport.delay--warm_nominal | transport.delay | PASS | 6 | 6 | 0 | 0 | [report.md](transport.delay--warm_nominal/report.md) |
| transport.drop--cold_nominal | transport.drop | PASS | 16 | 16 | 0 | 0 | [report.md](transport.drop--cold_nominal/report.md) |
| transport.drop--hot_nominal | transport.drop | PASS | 29 | 29 | 0 | 0 | [report.md](transport.drop--hot_nominal/report.md) |
| transport.drop--warm_nominal | transport.drop | PASS | 16 | 16 | 0 | 0 | [report.md](transport.drop--warm_nominal/report.md) |

## Fault-class coverage

| Layer | Injected class | Runs / result |
|---|---|---|
| Transport | transport.delay | transport.delay--cold_nominal=PASS, transport.delay--hot_nominal=PASS, transport.delay--warm_nominal=PASS |
| Transport | transport.duplicate | not attempted |
| Transport | transport.drop | transport.drop--cold_nominal=PASS, transport.drop--hot_nominal=PASS, transport.drop--warm_nominal=PASS |
| Transport | transport.reorder | not attempted |
| Signal | signal.stuck | signal.stuck--cold_nominal=PASS, signal.stuck--hot_nominal=PASS, signal.stuck--warm_nominal=PASS |
| Signal | signal.spike | signal.spike--cold_nominal=PASS, signal.spike--hot_nominal=PASS, signal.spike--warm_nominal=PASS |
| Signal | signal.drift | signal.drift--cold_nominal=PASS, signal.drift--hot_nominal=PASS, signal.drift--warm_nominal=PASS |
| Signal | signal.out_of_range | signal.out_of_range--cold_nominal=PASS, signal.out_of_range--hot_nominal=PASS, signal.out_of_range--warm_nominal=PASS |
| Signal | signal.combination | combined_example--warm_nominal=PASS |
| Source | source.dropout | source.dropout--cold_nominal=PASS, source.dropout--hot_nominal=PASS, source.dropout--warm_nominal=PASS |
| Source | source.replay_interruption | not attempted |
| Diagnostics | diagnostics.dfm_write_delay | not attempted |
| Diagnostics | diagnostics.opensovd_partial_visibility | not attempted |

## Non-PASS runs

_Every run passed._

## Aggregate gaps and limitations

- **Mitigation:** not instrumented (v1 is event-only, ADR-007) - no mitigation event is recorded; this chain link is intentionally absent.
- **OpenSOVD fault status:** only activation times are captured; the `testFailed`/`confirmedDtc`/`warningIndicator` triple is not observable.
- **Unmapped Guardian warnings:** only DFM-mapped `class/level` pairs reach the collector stream (ADR-016 section 11); utilization warnings may be invisible.

## Reproduction

- Campaign directory: `reports/campaign-20261008-055450`
- Re-run: `tools/run_campaign.sh` (optionally `--campaign ID --scenario ID`).
- Per-run detail: see each run's `report.md`.
