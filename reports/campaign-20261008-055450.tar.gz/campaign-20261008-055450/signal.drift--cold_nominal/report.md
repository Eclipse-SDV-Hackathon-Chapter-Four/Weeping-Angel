# Evidence Report - signal.drift--cold_nominal

- **Campaign:** signal.drift
- **Scenario:** cold_nominal
- **Run ID:** signal.drift--cold_nominal
- **Generated:** 2026-10-08T06:10:45Z
- **Verdict:** **PASS**

## Provenance and reproduction

- Case (ASC): [case.asc](../experiments/signal.drift/cold_nominal/case.asc)
- Ground truth: [case.ground_truth.yaml](../experiments/signal.drift/cold_nominal/case.ground_truth.yaml)
- Oracle: [case.oracle.yaml](../experiments/signal.drift/cold_nominal/case.oracle.yaml)
- Experiment: [experiment.yaml](../experiments/signal.drift/cold_nominal/experiment.yaml)
- Logs: `can.log`, `collector.log`, `dfm.log`, `dfm_sovd_bridge.log`, `guardian.log`, `vss_bridge.log`, `collector.out`
- Case path (as recorded): `/app/reports/campaign-20261008-055450/experiments/signal.drift/cold_nominal/case`

## Diagnostic chain

```text
replay (ASC) -> KUKSA CAN Provider -> KUKSA Data Broker -> VSS uProtocol Publisher -> Battery Thermal Guardian -> DFM -> OpenSOVD -> Evidence Collector
```

## Fault catalog

| Fault code | Category | Severity | Description |
|---|---|---|---|
| BatterySignalStuck | Communication | Error | A battery signal stayed flat while other signals changed (stuck signal). |
| BatteryTempHotspot | Hardware | Error | Max temperature deviates from average beyond the hotspot limit. |
| BatteryTempRate | Configuration | Error | Temperature changed faster than physically possible. |
| BatteryTempSpread | Hardware | Error | Spread between max and min temperature exceeds the physical limit. |
| BatteryTempStreamStale | Communication | Error | No battery temperature sample received within the missing-packet timeout. |

## Injections

### signal-drift-1 - signal.drift

- Verdict: **PASS** (0/0 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 1000..1100 ms (slot 1000..4500)
- `temp_max` / `drift`: requested duration_samples=1, rate_per_sample=0.5; executed [-6]

### signal-drift-2 - signal.drift

- Verdict: **PASS** (12/12 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 4500..6500 ms (slot 4500..8000)
- `temp_max` / `drift`: requested duration_samples=20, rate_per_sample=0.5; executed [-4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]

### signal-drift-3 - signal.drift

- Verdict: **PASS** (10/10 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 8000..10000 ms (slot 8000..11500)
- `temp_max` / `drift`: requested duration_samples=20, rate_per_sample=0.5; executed [-2, -0.5, 1, 2.5, 4, 5.5, 7, 8.5, 10, 11.5, 13, 14.5, 16, 17.5, 19, 20.5, 22, 23.5, 25, 26.5]

### signal-drift-4 - signal.drift

- Verdict: **PASS** (12/12 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 11500..13500 ms (slot 11500..15000)
- `temp_max` / `drift`: requested duration_samples=20, rate_per_sample=0.5; executed [-1, -0.5, 0, 0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5, 5.5, 6, 6.5, 7, 7.5, 8, 8.5]

### signal-drift-5 - signal.drift

- Verdict: **PASS** (10/10 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 15000..17000 ms (slot 15000..-)
- `temp_max` / `drift`: requested duration_samples=20, rate_per_sample=0.5; executed [1.5, 3, 4.5, 6, 7.5, 9, 10.5, 12, 13.5, 15, 16.5, 18, 19.5, 21, 22.5, 24, 25.5, 27, 28.5, 30]

## Expected vs. observed

Oracle: 44 expected, 44 matched, 0 missing, 0 not reached, 0 unexpected, 18 not applicable

| Status | Fault | Class | Level | Stage | Expected ms | Observed ms | Signal | OpenSOVD ms |
|---|---|---|---|---|---|---|---|---|
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 4500 | 4500 | temp_max | 4563 |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | 4700 | 4700 | temp_max | 4766 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 4900 | 4900 | temp_avg | 4970 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 5000 | 5000 | temp_min | - |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | 5300 | 5300 | - | 5367 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 5900 | 5900 | temp_min | 5966 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 6000 | 6000 | temp_avg | - |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | 6500 | 6500 | temp_max | - |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | 6500 | 6500 | - | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 6600 | 6600 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 6900 | 6900 | temp_avg | 6965 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 7000 | 7000 | temp_min | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 8000 | 8000 | temp_max | 8069 |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | 8200 | 8200 | temp_max | 8262 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | 8500 | 8500 | - | 8569 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 8900 | 8900 | temp_min | 8965 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 9000 | 9000 | temp_avg | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 9900 | 9900 | temp_min | 9963 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 10000 | 10000 | temp_avg | - |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | 10000 | 10000 | temp_max | - |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | 10000 | 10000 | - | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 10100 | 10100 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 11900 | 11900 | temp_min | 11968 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 12000 | 12000 | temp_avg | - |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | 12100 | 12100 | temp_max | 12172 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 12900 | 12900 | temp_avg | 12966 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 13000 | 13000 | temp_min | - |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | 13200 | 13200 | - | 13272 |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | 13500 | 13500 | temp_max | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 13500 | 13500 | temp_max | 13568 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | 13500 | 13500 | - | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 13600 | 13600 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 13900 | 13900 | temp_avg | 13965 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 14000 | 14000 | temp_min | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 15000 | 15000 | temp_max | 15067 |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | 15200 | 15200 | temp_max | 15269 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | 15500 | 15500 | - | 15564 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 15900 | 15900 | temp_avg | 15971 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 16000 | 16000 | temp_min | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 16900 | 16900 | temp_min | 16970 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 17000 | 17000 | temp_avg | - |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | 17000 | 17000 | temp_max | - |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | 17000 | 17000 | - | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 17100 | 17100 | temp_max | - |

## Detection evidence

| t_ms | Fault | Class | Level | Stage | Signal | Observed | Limit | Residual | Utilization | Interval ms |
|---|---|---|---|---|---|---|---|---|---|---|
| 4500 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_max | 10 | 8 | 2 | 1.25 | 100 |
| 4700 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | temp_max | 5.5 | 5 | 0.5 | 1.1 | - |
| 4900 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_avg | 0 | 0.25 | - | - | - |
| 5000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 5300 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | - | 13 | 12 | 1 | 1.0833334 | - |
| 5900 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 6000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 6500 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 6500 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | - | - | - | - | - | - |
| 6600 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 6900 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_avg | 0 | 0.25 | - | - | - |
| 7000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 8000 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_max | 15 | 8 | 7 | 1.875 | 100 |
| 8200 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | temp_max | 6.5 | 5 | 1.5 | 1.3 | - |
| 8500 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | - | 13 | 12 | 1 | 1.0833334 | - |
| 8900 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 9000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 9900 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 10000 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | - | - | - | - | - | - |
| 10000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 10000 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 10100 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 11900 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 12000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 12100 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | temp_max | 5.5 | 5 | 0.5 | 1.1 | - |
| 12900 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_avg | 0 | 0.25 | - | - | - |
| 13000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 13200 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | - | 12.5 | 12 | 0.5 | 1.0416666 | - |
| 13500 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_max | 90 | 6 | 84 | 15 | 100 |
| 13500 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | - | - | - | - | - | - |
| 13500 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 13600 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 13900 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_avg | 0 | 0.25 | - | - | - |
| 14000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 15000 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_max | 15 | 8 | 7 | 1.875 | 100 |
| 15200 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | temp_max | 6.5 | 5 | 1.5 | 1.3 | - |
| 15500 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | - | 13 | 12 | 1 | 1.0833334 | - |
| 15900 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_avg | 0 | 0.25 | - | - | - |
| 16000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 16900 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 17000 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | - | - | - | - | - | - |
| 17000 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 17000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 17100 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 20500 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | - | 539.9726 | 500 | 39.972595 | - | - |

## DFM / OpenSOVD correlation

- URL: `http://127.0.0.1:7690/sovd/v1/components/battery_guardian/data/faults`
- Polls: 234 (0 failed)
- Activations: 23; not visible: 0; unexplained: 1

| t_ms | Code |
|---|---|
| 4563 | BatteryTempRate |
| 4766 | BatteryTempHotspot |
| 4970 | BatterySignalStuck |
| 5367 | BatteryTempSpread |
| 5966 | BatterySignalStuck |
| 6965 | BatterySignalStuck |
| 8069 | BatteryTempRate |
| 8262 | BatteryTempHotspot |
| 8569 | BatteryTempSpread |
| 8965 | BatterySignalStuck |
| 9963 | BatterySignalStuck |
| 11968 | BatterySignalStuck |
| 12172 | BatteryTempHotspot |
| 12966 | BatterySignalStuck |
| 13272 | BatteryTempSpread |
| 13568 | BatteryTempRate |
| 13965 | BatterySignalStuck |
| 15067 | BatteryTempRate |
| 15269 | BatteryTempHotspot |
| 15564 | BatteryTempSpread |
| 15971 | BatterySignalStuck |
| 16970 | BatterySignalStuck |
| 20473 | BatteryTempStreamStale |

Unexplained: `BatteryTempStreamStale`@20473ms

## Timing

- Replay end: 19900 ms; battery stream end: 19900 ms

| Injection | Fault | Injected ms | Detected ms | Detection latency ms | OpenSOVD latency ms |
|---|---|---|---|---|---|
| signal-drift-2 | BatteryTempRate | 4500 | 4500 | 0 | 63 |
| signal-drift-2 | BatteryTempHotspot | 4500 | 4700 | 200 | 66 |
| signal-drift-2 | BatterySignalStuck | 4500 | 4900 | 400 | 70 |
| signal-drift-2 | BatterySignalStuck | 4500 | 5000 | 500 | - |
| signal-drift-2 | BatteryTempSpread | 4500 | 5300 | 800 | 67 |
| signal-drift-2 | BatterySignalStuck | 4500 | 5900 | 1400 | 66 |
| signal-drift-2 | BatterySignalStuck | 4500 | 6000 | 1500 | - |
| signal-drift-2 | BatteryTempHotspot | 4500 | 6500 | 2000 | - |
| signal-drift-2 | BatteryTempSpread | 4500 | 6500 | 2000 | - |
| signal-drift-2 | BatteryTempRate | 4500 | 6600 | 2100 | - |
| signal-drift-2 | BatterySignalStuck | 4500 | 6900 | 2400 | 65 |
| signal-drift-2 | BatterySignalStuck | 4500 | 7000 | 2500 | - |
| signal-drift-3 | BatteryTempRate | 8000 | 8000 | 0 | 69 |
| signal-drift-3 | BatteryTempHotspot | 8000 | 8200 | 200 | 62 |
| signal-drift-3 | BatteryTempSpread | 8000 | 8500 | 500 | 69 |
| signal-drift-3 | BatterySignalStuck | 8000 | 8900 | 900 | 65 |
| signal-drift-3 | BatterySignalStuck | 8000 | 9000 | 1000 | - |
| signal-drift-3 | BatterySignalStuck | 8000 | 9900 | 1900 | 63 |
| signal-drift-3 | BatterySignalStuck | 8000 | 10000 | 2000 | - |
| signal-drift-3 | BatteryTempHotspot | 8000 | 10000 | 2000 | - |
| signal-drift-3 | BatteryTempSpread | 8000 | 10000 | 2000 | - |
| signal-drift-3 | BatteryTempRate | 8000 | 10100 | 2100 | - |
| signal-drift-4 | BatterySignalStuck | 11500 | 11900 | 400 | 68 |
| signal-drift-4 | BatterySignalStuck | 11500 | 12000 | 500 | - |
| signal-drift-4 | BatteryTempHotspot | 11500 | 12100 | 600 | 72 |
| signal-drift-4 | BatterySignalStuck | 11500 | 12900 | 1400 | 66 |
| signal-drift-4 | BatterySignalStuck | 11500 | 13000 | 1500 | - |
| signal-drift-4 | BatteryTempSpread | 11500 | 13200 | 1700 | 72 |
| signal-drift-4 | BatteryTempHotspot | 11500 | 13500 | 2000 | - |
| signal-drift-4 | BatteryTempRate | 11500 | 13500 | 2000 | 68 |
| signal-drift-4 | BatteryTempSpread | 11500 | 13500 | 2000 | - |
| signal-drift-4 | BatteryTempRate | 11500 | 13600 | 2100 | - |
| signal-drift-4 | BatterySignalStuck | 11500 | 13900 | 2400 | 65 |
| signal-drift-4 | BatterySignalStuck | 11500 | 14000 | 2500 | - |
| signal-drift-5 | BatteryTempRate | 15000 | 15000 | 0 | 67 |
| signal-drift-5 | BatteryTempHotspot | 15000 | 15200 | 200 | 69 |
| signal-drift-5 | BatteryTempSpread | 15000 | 15500 | 500 | 64 |
| signal-drift-5 | BatterySignalStuck | 15000 | 15900 | 900 | 71 |
| signal-drift-5 | BatterySignalStuck | 15000 | 16000 | 1000 | - |
| signal-drift-5 | BatterySignalStuck | 15000 | 16900 | 1900 | 70 |
| signal-drift-5 | BatterySignalStuck | 15000 | 17000 | 2000 | - |
| signal-drift-5 | BatteryTempHotspot | 15000 | 17000 | 2000 | - |
| signal-drift-5 | BatteryTempSpread | 15000 | 17000 | 2000 | - |
| signal-drift-5 | BatteryTempRate | 15000 | 17100 | 2100 | - |

## Verdict rationale

All 44 expected Guardian change(s) matched and no unexpected change was observed.

## Observer artifacts

- Final live-observer view: [observer.html](observer.html)

Observer artifacts are illustrative only and never a source of evaluation facts.

## Gaps and limitations

- **Mitigation:** not instrumented (v1 is event-only, ADR-007) - no mitigation event is recorded; this chain link is intentionally absent.
- **OpenSOVD fault status:** only activation times are captured; the `testFailed`/`confirmedDtc`/`warningIndicator` triple is not observable.
- **Unmapped Guardian warnings:** only DFM-mapped `class/level` pairs reach the collector stream (ADR-016 section 11); utilization warnings may be invisible.

## Notes

- BatteryTempStreamStale at the end of the replay ignored (1 change(s))
