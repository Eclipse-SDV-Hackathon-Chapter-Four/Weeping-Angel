# Evidence Report - signal.stuck--warm_nominal

- **Campaign:** signal.stuck
- **Scenario:** warm_nominal
- **Run ID:** signal.stuck--warm_nominal
- **Generated:** 2026-10-08T06:10:45Z
- **Verdict:** **PASS**

## Provenance and reproduction

- Case (ASC): [case.asc](../experiments/signal.stuck/warm_nominal/case.asc)
- Ground truth: [case.ground_truth.yaml](../experiments/signal.stuck/warm_nominal/case.ground_truth.yaml)
- Oracle: [case.oracle.yaml](../experiments/signal.stuck/warm_nominal/case.oracle.yaml)
- Experiment: [experiment.yaml](../experiments/signal.stuck/warm_nominal/experiment.yaml)
- Logs: `can.log`, `collector.log`, `dfm.log`, `dfm_sovd_bridge.log`, `guardian.log`, `vss_bridge.log`, `collector.out`
- Case path (as recorded): `/app/reports/campaign-20261008-055450/experiments/signal.stuck/warm_nominal/case`

## Diagnostic chain

```text
replay (ASC) -> KUKSA CAN Provider -> KUKSA Data Broker -> VSS uProtocol Publisher -> Battery Thermal Guardian -> DFM -> OpenSOVD -> Evidence Collector
```

## Fault catalog

| Fault code | Category | Severity | Description |
|---|---|---|---|
| BatterySignalStuck | Communication | Error | A battery signal stayed flat while other signals changed (stuck signal). |
| BatterySocRate | Configuration | Error | State of charge changed faster than physically possible. |
| BatteryTempRate | Configuration | Error | Temperature changed faster than physically possible. |
| BatteryTempStreamStale | Communication | Error | No battery temperature sample received within the missing-packet timeout. |

## Injections

### signal-stuck-1 - signal.stuck

- Verdict: **PASS** (0/0 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 1000..1900 ms (slot 1000..4500)
- `temp_avg` / `stuck`: requested duration_samples=9; executed [30, 30, 30, 30, 30, 30, 30, 30, 30]

### signal-stuck-2 - signal.stuck

- Verdict: **PASS** (6/6 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 4500..5500 ms (slot 4500..8000)
- `temp_avg` / `stuck`: requested duration_samples=10; executed [31.5, 31.5, 31.5, 31.5, 31.5, 31.5, 31.5, 31.5, 31.5, 31.5]
- `soc` / `drift`: requested duration_samples=10, rate_per_sample=-0.5; executed [46, 45.5, 45, 44.5, 44, 43.5, 43, 42.5, 42, 41.5]

### signal-stuck-3 - signal.stuck

- Verdict: **PASS** (6/6 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 8000..9100 ms (slot 8000..11500)
- `temp_avg` / `stuck`: requested duration_samples=11; executed [33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33]
- `soc` / `drift`: requested duration_samples=11, rate_per_sample=-0.5; executed [47, 46.5, 46, 45.5, 45, 44.5, 44, 43.5, 43, 42.5, 42]

### signal-stuck-4 - signal.stuck

- Verdict: **PASS** (4/4 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 11500..13000 ms (slot 11500..15000)
- `temp_avg` / `stuck`: requested duration_samples=15; executed [34.5, 34.5, 34.5, 34.5, 34.5, 34.5, 34.5, 34.5, 34.5, 34.5, 34.5, 34.5, 34.5, 34.5, 34.5]
- `soc` / `drift`: requested duration_samples=15, rate_per_sample=-0.5; executed [48.5, 48, 47.5, 47, 46.5, 46, 45.5, 45, 44.5, 44, 43.5, 43, 42.5, 42, 41.5]

### signal-stuck-5 - signal.stuck

- Verdict: **PASS** (8/8 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 15000..17000 ms (slot 15000..-)
- `temp_avg` / `stuck`: requested duration_samples=20; executed [36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36]
- `soc` / `drift`: requested duration_samples=20, rate_per_sample=-0.5; executed [49.5, 49, 48.5, 48, 47.5, 47, 46.5, 46, 45.5, 45, 44.5, 44, 43.5, 43, 42.5, 42, 41.5, 41, 40.5, 40]

## Expected vs. observed

Oracle: 24 expected, 24 matched, 0 missing, 0 not reached, 0 unexpected, 0 not applicable

| Status | Fault | Class | Level | Stage | Expected ms | Observed ms | Signal | OpenSOVD ms |
|---|---|---|---|---|---|---|---|---|
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 4600 | 4600 | temp_max | 4668 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 5500 | 5500 | temp_avg | - |
| MATCHED | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Failed | 5500 | 5500 | soc | 5565 |
| MATCHED | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Passed | 5600 | 5600 | soc | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 5700 | 5700 | temp_min | 5769 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 6000 | 6000 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 8100 | 8100 | temp_min | 8169 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 9100 | 9100 | temp_avg | - |
| MATCHED | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Failed | 9100 | 9100 | soc | 9166 |
| MATCHED | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Passed | 9200 | 9200 | soc | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 9300 | 9300 | temp_min | 9369 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 9600 | 9600 | temp_min | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 11700 | 11700 | temp_avg | 11769 |
| MATCHED | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Failed | 13000 | 13000 | soc | 13072 |
| MATCHED | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Passed | 13100 | 13100 | soc | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 13200 | 13200 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 15300 | 15300 | temp_min | 15371 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 17000 | 17000 | temp_avg | - |
| MATCHED | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Failed | 17000 | 17000 | soc | 17069 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 17000 | 17000 | temp_avg | 17069 |
| MATCHED | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Passed | 17100 | 17100 | soc | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 17100 | 17100 | temp_avg | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 17700 | 17700 | temp_min | 17773 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 17900 | 17900 | temp_max | - |

## Detection evidence

| t_ms | Fault | Class | Level | Stage | Signal | Observed | Limit | Residual | Utilization | Interval ms |
|---|---|---|---|---|---|---|---|---|---|---|
| 4600 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_max | 0 | 0.25 | - | - | - |
| 5500 | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Failed | soc | 50 | 5 | 45 | - | 100 |
| 5500 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 5600 | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Passed | soc | - | - | - | - | - |
| 5700 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 6000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 8100 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 9100 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 9100 | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Failed | soc | 60 | 5 | 55 | - | 100 |
| 9200 | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Passed | soc | - | - | - | - | - |
| 9300 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 9600 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 11700 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_avg | 0 | 0.25 | - | - | - |
| 13000 | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Failed | soc | 80 | 5 | 75 | - | 100 |
| 13100 | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Passed | soc | - | - | - | - | - |
| 13200 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 15300 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 17000 | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Failed | soc | 110 | 5 | 105 | - | 100 |
| 17000 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_avg | 10 | 7.04 | 2.96 | 1.4204545 | 100 |
| 17000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 17100 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 17100 | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Passed | soc | - | - | - | - | - |
| 17700 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 17900 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 20500 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | - | 543.74786 | 500 | 43.747864 | - | - |

## DFM / OpenSOVD correlation

- URL: `http://127.0.0.1:7690/sovd/v1/components/battery_guardian/data/faults`
- Polls: 234 (0 failed)
- Activations: 13; not visible: 0; unexplained: 1

| t_ms | Code |
|---|---|
| 4668 | BatterySignalStuck |
| 5565 | BatterySocRate |
| 5769 | BatterySignalStuck |
| 8169 | BatterySignalStuck |
| 9166 | BatterySocRate |
| 9369 | BatterySignalStuck |
| 11769 | BatterySignalStuck |
| 13072 | BatterySocRate |
| 15371 | BatterySignalStuck |
| 17069 | BatterySocRate |
| 17069 | BatteryTempRate |
| 17773 | BatterySignalStuck |
| 20468 | BatteryTempStreamStale |

Unexplained: `BatteryTempStreamStale`@20468ms

## Timing

- Replay end: 19900 ms; battery stream end: 19900 ms

| Injection | Fault | Injected ms | Detected ms | Detection latency ms | OpenSOVD latency ms |
|---|---|---|---|---|---|
| signal-stuck-2 | BatterySignalStuck | 4500 | 4600 | 100 | 68 |
| signal-stuck-2 | BatterySignalStuck | 4500 | 5500 | 1000 | - |
| signal-stuck-2 | BatterySocRate | 4500 | 5500 | 1000 | 65 |
| signal-stuck-2 | BatterySocRate | 4500 | 5600 | 1100 | - |
| signal-stuck-2 | BatterySignalStuck | 4500 | 5700 | 1200 | 69 |
| signal-stuck-2 | BatterySignalStuck | 4500 | 6000 | 1500 | - |
| signal-stuck-3 | BatterySignalStuck | 8000 | 8100 | 100 | 69 |
| signal-stuck-3 | BatterySignalStuck | 8000 | 9100 | 1100 | - |
| signal-stuck-3 | BatterySocRate | 8000 | 9100 | 1100 | 66 |
| signal-stuck-3 | BatterySocRate | 8000 | 9200 | 1200 | - |
| signal-stuck-3 | BatterySignalStuck | 8000 | 9300 | 1300 | 69 |
| signal-stuck-3 | BatterySignalStuck | 8000 | 9600 | 1600 | - |
| signal-stuck-4 | BatterySignalStuck | 11500 | 11700 | 200 | 69 |
| signal-stuck-4 | BatterySocRate | 11500 | 13000 | 1500 | 72 |
| signal-stuck-4 | BatterySocRate | 11500 | 13100 | 1600 | - |
| signal-stuck-4 | BatterySignalStuck | 11500 | 13200 | 1700 | - |
| signal-stuck-5 | BatterySignalStuck | 15000 | 15300 | 300 | 71 |
| signal-stuck-5 | BatterySignalStuck | 15000 | 17000 | 2000 | - |
| signal-stuck-5 | BatterySocRate | 15000 | 17000 | 2000 | 69 |
| signal-stuck-5 | BatteryTempRate | 15000 | 17000 | 2000 | 69 |
| signal-stuck-5 | BatterySocRate | 15000 | 17100 | 2100 | - |
| signal-stuck-5 | BatteryTempRate | 15000 | 17100 | 2100 | - |
| signal-stuck-5 | BatterySignalStuck | 15000 | 17700 | 2700 | 73 |
| signal-stuck-5 | BatterySignalStuck | 15000 | 17900 | 2900 | - |

## Verdict rationale

All 24 expected Guardian change(s) matched and no unexpected change was observed.

## Observer artifacts

- Final live-observer view: [observer.html](observer.html)

Observer artifacts are illustrative only and never a source of evaluation facts.

## Gaps and limitations

- **Mitigation:** not instrumented (v1 is event-only, ADR-007) - no mitigation event is recorded; this chain link is intentionally absent.
- **OpenSOVD fault status:** only activation times are captured; the `testFailed`/`confirmedDtc`/`warningIndicator` triple is not observable.
- **Unmapped Guardian warnings:** only DFM-mapped `class/level` pairs reach the collector stream (ADR-016 section 11); utilization warnings may be invisible.

## Notes

- BatteryTempStreamStale at the end of the replay ignored (1 change(s))
