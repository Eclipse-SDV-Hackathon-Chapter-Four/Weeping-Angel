# Evidence Report - combined_example--warm_nominal

- **Campaign:** combined_example
- **Scenario:** warm_nominal
- **Run ID:** combined_example--warm_nominal
- **Generated:** 2026-10-08T06:10:45Z
- **Verdict:** **PASS**

## Provenance and reproduction

- Case (ASC): [case.asc](../experiments/combined_example/warm_nominal/case.asc)
- Ground truth: [case.ground_truth.yaml](../experiments/combined_example/warm_nominal/case.ground_truth.yaml)
- Oracle: [case.oracle.yaml](../experiments/combined_example/warm_nominal/case.oracle.yaml)
- Experiment: [experiment.yaml](../experiments/combined_example/warm_nominal/experiment.yaml)
- Logs: `can.log`, `collector.log`, `dfm.log`, `dfm_sovd_bridge.log`, `guardian.log`, `vss_bridge.log`, `collector.out`
- Case path (as recorded): `/app/reports/campaign-20261008-055450/experiments/combined_example/warm_nominal/case`

## Diagnostic chain

```text
replay (ASC) -> KUKSA CAN Provider -> KUKSA Data Broker -> VSS uProtocol Publisher -> Battery Thermal Guardian -> DFM -> OpenSOVD -> Evidence Collector
```

## Fault catalog

| Fault code | Category | Severity | Description |
|---|---|---|---|
| BatteryOverTempCritical | Hardware | Fatal | Maximum cell temperature reached the configured critical band. |
| BatterySignalStuck | Communication | Error | A battery signal stayed flat while other signals changed (stuck signal). |
| BatteryTempAbsoluteLimit | Hardware | Fatal | Battery temperature outside the absolute physical limits. |
| BatteryTempHotspot | Hardware | Error | Max temperature deviates from average beyond the hotspot limit. |
| BatteryTempOrdering | Configuration | Error | Temperature ordering violated (min <= avg <= max). |
| BatteryTempRate | Configuration | Error | Temperature changed faster than physically possible. |
| BatteryTempSpread | Hardware | Error | Spread between max and min temperature exceeds the physical limit. |
| BatteryTempStreamStale | Communication | Error | No battery temperature sample received within the missing-packet timeout. |

## Injections

### combined_example-1 - signal.combination

- Verdict: **PASS** (8/8 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 2000..3500 ms (slot 2000..5500)
- `temp_avg` / `stuck`: requested duration_samples=15; executed [30.5, 30.5, 30.5, 30.5, 30.5, 30.5, 30.5, 30.5, 30.5, 30.5, 30.5, 30.5, 30.5, 30.5, 30.5]
- `temp_max` / `spike`: requested duration_samples=1, delta=8; executed [40]

### combined_example-2 - signal.combination

- Verdict: **PASS** (16/16 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 5500..7500 ms (slot 5500..9000)
- `temp_max` / `drift`: requested duration_samples=20, rate_per_sample=0.5; executed [34, 34.5, 35, 35.5, 36, 36.5, 37, 37.5, 38, 38.5, 39, 39.5, 40, 40.5, 41, 41.5, 42, 42.5, 43, 43.5]
- `temp_min` / `spike`: requested duration_samples=1, delta=3; executed [32.5]

### combined_example-3 - signal.combination

- Verdict: **PASS** (14/14 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 9000..11000 ms (slot 9000..12500)
- `temp_min` / `out_of_range`: requested duration_samples=5, value=-30.5; executed [-30.5, -30.5, -30.5, -30.5, -30.5]
- `temp_avg` / `stuck`: requested duration_samples=20; executed [33.5, 33.5, 33.5, 33.5, 33.5, 33.5, 33.5, 33.5, 33.5, 33.5, 33.5, 33.5, 33.5, 33.5, 33.5, 33.5, 33.5, 33.5, 33.5, 33.5]

### combined_example-4 - signal.combination

- Verdict: **PASS** (12/12 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 12500..14500 ms (slot 12500..16000)
- `temp_min` / `drift`: requested duration_samples=20, rate_per_sample=1; executed [33.5, 34.5, 35.5, 36.5, 37.5, 38.5, 39.5, 40.5, 41.5, 42.5, 43.5, 44.5, 45.5, 46.5, 47.5, 48.5, 49.5, 50.5, 51.5, 52.5]
- `temp_avg` / `spike`: requested duration_samples=1, delta=8; executed [43]

### combined_example-5 - signal.combination

- Verdict: **PASS** (14/14 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 16000..17000 ms (slot 16000..-)
- `temp_min` / `stuck`: requested duration_samples=10; executed [34, 34, 34, 34, 34, 34, 34, 34, 34, 34]
- `temp_max` / `out_of_range`: requested duration_samples=5, value=75; executed [75, 75, 75, 75, 75]

## Expected vs. observed

Oracle: 64 expected, 64 matched, 0 missing, 0 not reached, 0 unexpected, 4 not applicable

| Status | Fault | Class | Level | Stage | Expected ms | Observed ms | Signal | OpenSOVD ms |
|---|---|---|---|---|---|---|---|---|
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | 2000 | 2000 | temp_max | 2061 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 2000 | 2000 | temp_max | 2061 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | 2000 | 2000 | - | 2061 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 2100 | 2100 | temp_avg | 2163 |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | 2100 | 2100 | temp_max | - |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | 2100 | 2100 | - | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 2200 | 2200 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 3000 | 3000 | temp_avg | - |
| MATCHED | BatteryTempOrdering | PHYSICAL_TEMP_ORDERING | VIOLATION | Failed | 5500 | 5500 | temp_min | 5563 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 5500 | 5500 | temp_min | 5563 |
| MATCHED | BatteryTempOrdering | PHYSICAL_TEMP_ORDERING | VIOLATION | Passed | 5600 | 5600 | temp_min | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 5700 | 5700 | temp_avg | 5767 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 5700 | 5700 | temp_min | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 6000 | 6000 | temp_avg | - |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | 6100 | 6100 | temp_max | 6164 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 6900 | 6900 | temp_min | 6960 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | 6900 | 6900 | - | 6960 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 7200 | 7200 | temp_avg | - |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | 7500 | 7500 | temp_max | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 7500 | 7500 | temp_max | 7560 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | 7500 | 7500 | - | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 7600 | 7600 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 8100 | 8100 | temp_min | 8160 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 8400 | 8400 | temp_avg | - |
| MATCHED | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Failed | 9000 | 9000 | temp_min | 9066 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 9000 | 9000 | temp_min | 9066 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | 9000 | 9000 | - | 9066 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 9100 | 9100 | temp_min | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 9300 | 9300 | temp_max | 9362 |
| MATCHED | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Passed | 9500 | 9500 | temp_min | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 9500 | 9500 | temp_min | 9567 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | 9500 | 9500 | - | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 9600 | 9600 | temp_min | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 10400 | 10400 | temp_avg | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 11000 | 11000 | temp_avg | 11066 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 11100 | 11100 | temp_avg | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 11700 | 11700 | temp_max | 11767 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 11900 | 11900 | temp_min | - |
| MATCHED | BatteryTempOrdering | PHYSICAL_TEMP_ORDERING | VIOLATION | Failed | 12500 | 12500 | temp_avg | 12561 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 12500 | 12500 | temp_avg | 12561 |
| MATCHED | BatteryTempOrdering | PHYSICAL_TEMP_ORDERING | VIOLATION | Passed | 12600 | 12600 | temp_avg | - |
| MATCHED | BatteryTempOrdering | PHYSICAL_TEMP_ORDERING | VIOLATION | Failed | 12700 | 12700 | temp_min | 12765 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 12900 | 12900 | temp_max | 12968 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 13200 | 13200 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 14100 | 14100 | temp_avg | 14160 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 14400 | 14400 | temp_max | - |
| MATCHED | BatteryTempOrdering | PHYSICAL_TEMP_ORDERING | VIOLATION | Passed | 14500 | 14500 | temp_min | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 14600 | 14600 | temp_min | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 15300 | 15300 | temp_max | 15360 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 15400 | 15400 | temp_avg | - |
| MATCHED | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Failed | 16000 | 16000 | temp_max | 16064 |
| MATCHED | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Failed | 16000 | 16000 | temp_max | 16064 |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | 16000 | 16000 | temp_max | 16064 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 16000 | 16000 | temp_max | 16064 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | 16000 | 16000 | - | 16064 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 16100 | 16100 | temp_max | - |
| MATCHED | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Passed | 16500 | 16500 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 16500 | 16500 | temp_avg | 16564 |
| MATCHED | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Passed | 16500 | 16500 | temp_max | - |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | 16500 | 16500 | temp_max | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 16500 | 16500 | temp_max | 16564 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | 16500 | 16500 | - | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 16600 | 16600 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 17000 | 17000 | temp_min | - |

## Detection evidence

| t_ms | Fault | Class | Level | Stage | Signal | Observed | Limit | Residual | Utilization | Interval ms |
|---|---|---|---|---|---|---|---|---|---|---|
| 2000 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | - | 12 | 10.95 | 1.0500002 | 1.0958904 | - |
| 2000 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | temp_max | 9.5 | 4.37 | 5.13 | 2.173913 | - |
| 2000 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_max | 80 | 7.37 | 72.63 | 10.854817 | 100 |
| 2100 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 2100 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_avg | 0 | 0.25 | - | - | - |
| 2100 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | - | - | - | - | - | - |
| 2200 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 3000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 5500 | BatteryTempOrdering | PHYSICAL_TEMP_ORDERING | VIOLATION | Failed | temp_min | 32.5 | 32 | 0.5 | - | - |
| 5500 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_min | 30 | 7.28 | 22.72 | 4.120879 | 100 |
| 5600 | BatteryTempOrdering | PHYSICAL_TEMP_ORDERING | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 5700 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 5700 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_avg | 0 | 0.25 | - | - | - |
| 6000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 6100 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | temp_max | 4.5 | 4.25 | 0.25 | 1.0588236 | - |
| 6900 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 6900 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | - | 11 | 10.75 | 0.25 | 1.0232558 | - |
| 7200 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 7500 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_max | 90 | 6 | 84 | 15 | 100 |
| 7500 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | - | - | - | - | - | - |
| 7500 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 7600 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 8100 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 8400 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 9000 | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Failed | temp_min | -30.5 | -30 | 0.5 | - | - |
| 9000 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | - | 65.5 | 10.65 | 54.85 | 6.150235 | - |
| 9000 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_min | 615 | 6 | 609 | 102.5 | 100 |
| 9100 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 9300 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_max | 0 | 0.25 | - | - | - |
| 9500 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_min | 615 | 7.19 | 607.81 | 85.53547 | 100 |
| 9500 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | - | - | - | - | - | - |
| 9500 | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 9600 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 10400 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 11000 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_avg | 10 | 7.19 | 2.81 | 1.3908206 | 100 |
| 11100 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 11700 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_max | 0 | 0.25 | - | - | - |
| 11900 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 12500 | BatteryTempOrdering | PHYSICAL_TEMP_ORDERING | VIOLATION | Failed | temp_avg | 43 | 36.5 | 6.5 | - | - |
| 12500 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_avg | 80 | 7.1 | 72.9 | 11.267606 | 100 |
| 12600 | BatteryTempOrdering | PHYSICAL_TEMP_ORDERING | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 12700 | BatteryTempOrdering | PHYSICAL_TEMP_ORDERING | VIOLATION | Failed | temp_min | 35.5 | 35 | 0.5 | - | - |
| 12900 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_max | 0 | 0.25 | - | - | - |
| 13200 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 14100 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_avg | 0 | 0.25 | - | - | - |
| 14400 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 14500 | BatteryTempOrdering | PHYSICAL_TEMP_ORDERING | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 14600 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 15300 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_max | 0 | 0.25 | - | - | - |
| 15400 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 16000 | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Failed | temp_max | 75 | 70 | 5 | - | - |
| 16000 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | - | 41 | 10.35 | 30.65 | 3.9613526 | - |
| 16000 | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Failed | temp_max | 75 | 70 | 5 | - | - |
| 16000 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | temp_max | 38.5 | 4.01 | 34.489998 | 9.600997 | - |
| 16000 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_max | 370 | 7.01 | 362.99 | 52.78174 | 100 |
| 16100 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 16500 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_avg | 0 | 0.25 | - | - | - |
| 16500 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_max | 370 | 6 | 364 | 61.666668 | 100 |
| 16500 | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Passed | temp_max | - | - | - | - | - |
| 16500 | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 16500 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | - | - | - | - | - | - |
| 16500 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 16600 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 17000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 20500 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | - | 537.42017 | 500 | 37.420166 | - | - |

## DFM / OpenSOVD correlation

- URL: `http://127.0.0.1:7690/sovd/v1/components/battery_guardian/data/faults`
- Polls: 234 (0 failed)
- Activations: 33; not visible: 0; unexplained: 1

| t_ms | Code |
|---|---|
| 2061 | BatteryTempHotspot |
| 2061 | BatteryTempRate |
| 2061 | BatteryTempSpread |
| 2163 | BatterySignalStuck |
| 5563 | BatteryTempOrdering |
| 5563 | BatteryTempRate |
| 5767 | BatterySignalStuck |
| 6164 | BatteryTempHotspot |
| 6960 | BatterySignalStuck |
| 6960 | BatteryTempSpread |
| 7560 | BatteryTempRate |
| 8160 | BatterySignalStuck |
| 9066 | BatteryTempAbsoluteLimit |
| 9066 | BatteryTempRate |
| 9066 | BatteryTempSpread |
| 9362 | BatterySignalStuck |
| 9567 | BatteryTempRate |
| 11066 | BatteryTempRate |
| 11767 | BatterySignalStuck |
| 12561 | BatteryTempOrdering |
| 12561 | BatteryTempRate |
| 12765 | BatteryTempOrdering |
| 12968 | BatterySignalStuck |
| 14160 | BatterySignalStuck |
| 15360 | BatterySignalStuck |
| 16064 | BatteryOverTempCritical |
| 16064 | BatteryTempAbsoluteLimit |
| 16064 | BatteryTempHotspot |
| 16064 | BatteryTempRate |
| 16064 | BatteryTempSpread |
| 16564 | BatterySignalStuck |
| 16564 | BatteryTempRate |
| 20463 | BatteryTempStreamStale |

Unexplained: `BatteryTempStreamStale`@20463ms

## Timing

- Replay end: 19900 ms; battery stream end: 19900 ms

| Injection | Fault | Injected ms | Detected ms | Detection latency ms | OpenSOVD latency ms |
|---|---|---|---|---|---|
| combined_example-1 | BatteryTempHotspot | 2000 | 2000 | 0 | 61 |
| combined_example-1 | BatteryTempRate | 2000 | 2000 | 0 | 61 |
| combined_example-1 | BatteryTempSpread | 2000 | 2000 | 0 | 61 |
| combined_example-1 | BatterySignalStuck | 2000 | 2100 | 100 | 63 |
| combined_example-1 | BatteryTempHotspot | 2000 | 2100 | 100 | - |
| combined_example-1 | BatteryTempSpread | 2000 | 2100 | 100 | - |
| combined_example-1 | BatteryTempRate | 2000 | 2200 | 200 | - |
| combined_example-1 | BatterySignalStuck | 2000 | 3000 | 1000 | - |
| combined_example-2 | BatteryTempOrdering | 5500 | 5500 | 0 | 63 |
| combined_example-2 | BatteryTempRate | 5500 | 5500 | 0 | 63 |
| combined_example-2 | BatteryTempOrdering | 5500 | 5600 | 100 | - |
| combined_example-2 | BatterySignalStuck | 5500 | 5700 | 200 | 67 |
| combined_example-2 | BatteryTempRate | 5500 | 5700 | 200 | - |
| combined_example-2 | BatterySignalStuck | 5500 | 6000 | 500 | - |
| combined_example-2 | BatteryTempHotspot | 5500 | 6100 | 600 | 64 |
| combined_example-2 | BatterySignalStuck | 5500 | 6900 | 1400 | 60 |
| combined_example-2 | BatteryTempSpread | 5500 | 6900 | 1400 | 60 |
| combined_example-2 | BatterySignalStuck | 5500 | 7200 | 1700 | - |
| combined_example-2 | BatteryTempHotspot | 5500 | 7500 | 2000 | - |
| combined_example-2 | BatteryTempRate | 5500 | 7500 | 2000 | 60 |
| combined_example-2 | BatteryTempSpread | 5500 | 7500 | 2000 | - |
| combined_example-2 | BatteryTempRate | 5500 | 7600 | 2100 | - |
| combined_example-2 | BatterySignalStuck | 5500 | 8100 | 2600 | 60 |
| combined_example-2 | BatterySignalStuck | 5500 | 8400 | 2900 | - |
| combined_example-3 | BatteryTempAbsoluteLimit | 9000 | 9000 | 0 | 66 |
| combined_example-3 | BatteryTempRate | 9000 | 9000 | 0 | 66 |
| combined_example-3 | BatteryTempSpread | 9000 | 9000 | 0 | 66 |
| combined_example-3 | BatteryTempRate | 9000 | 9100 | 100 | - |
| combined_example-3 | BatterySignalStuck | 9000 | 9300 | 300 | 62 |
| combined_example-3 | BatteryTempAbsoluteLimit | 9000 | 9500 | 500 | - |
| combined_example-3 | BatteryTempRate | 9000 | 9500 | 500 | 67 |
| combined_example-3 | BatteryTempSpread | 9000 | 9500 | 500 | - |
| combined_example-3 | BatteryTempRate | 9000 | 9600 | 600 | - |
| combined_example-3 | BatterySignalStuck | 9000 | 10400 | 1400 | - |
| combined_example-3 | BatteryTempRate | 9000 | 11000 | 2000 | 66 |
| combined_example-3 | BatteryTempRate | 9000 | 11100 | 2100 | - |
| combined_example-3 | BatterySignalStuck | 9000 | 11700 | 2700 | 67 |
| combined_example-3 | BatterySignalStuck | 9000 | 11900 | 2900 | - |
| combined_example-4 | BatteryTempOrdering | 12500 | 12500 | 0 | 61 |
| combined_example-4 | BatteryTempRate | 12500 | 12500 | 0 | 61 |
| combined_example-4 | BatteryTempOrdering | 12500 | 12600 | 100 | - |
| combined_example-4 | BatteryTempOrdering | 12500 | 12700 | 200 | 65 |
| combined_example-4 | BatterySignalStuck | 12500 | 12900 | 400 | 68 |
| combined_example-4 | BatterySignalStuck | 12500 | 13200 | 700 | - |
| combined_example-4 | BatterySignalStuck | 12500 | 14100 | 1600 | 60 |
| combined_example-4 | BatterySignalStuck | 12500 | 14400 | 1900 | - |
| combined_example-4 | BatteryTempOrdering | 12500 | 14500 | 2000 | - |
| combined_example-4 | BatteryTempRate | 12500 | 14600 | 2100 | - |
| combined_example-4 | BatterySignalStuck | 12500 | 15300 | 2800 | 60 |
| combined_example-4 | BatterySignalStuck | 12500 | 15400 | 2900 | - |
| combined_example-5 | BatteryOverTempCritical | 16000 | 16000 | 0 | 64 |
| combined_example-5 | BatteryTempAbsoluteLimit | 16000 | 16000 | 0 | 64 |
| combined_example-5 | BatteryTempHotspot | 16000 | 16000 | 0 | 64 |
| combined_example-5 | BatteryTempRate | 16000 | 16000 | 0 | 64 |
| combined_example-5 | BatteryTempSpread | 16000 | 16000 | 0 | 64 |
| combined_example-5 | BatteryTempRate | 16000 | 16100 | 100 | - |
| combined_example-5 | BatteryOverTempCritical | 16000 | 16500 | 500 | - |
| combined_example-5 | BatterySignalStuck | 16000 | 16500 | 500 | 64 |
| combined_example-5 | BatteryTempAbsoluteLimit | 16000 | 16500 | 500 | - |
| combined_example-5 | BatteryTempHotspot | 16000 | 16500 | 500 | - |
| combined_example-5 | BatteryTempRate | 16000 | 16500 | 500 | 64 |
| combined_example-5 | BatteryTempSpread | 16000 | 16500 | 500 | - |
| combined_example-5 | BatteryTempRate | 16000 | 16600 | 600 | - |
| combined_example-5 | BatterySignalStuck | 16000 | 17000 | 1000 | - |

## Verdict rationale

All 64 expected Guardian change(s) matched and no unexpected change was observed.

## Observer artifacts

- Final live-observer view: [observer.html](observer.html)

Observer artifacts are illustrative only and never a source of evaluation facts.

## Gaps and limitations

- **Mitigation:** not instrumented (v1 is event-only, ADR-007) - no mitigation event is recorded; this chain link is intentionally absent.
- **OpenSOVD fault status:** only activation times are captured; the `testFailed`/`confirmedDtc`/`warningIndicator` triple is not observable.
- **Unmapped Guardian warnings:** only DFM-mapped `class/level` pairs reach the collector stream (ADR-016 section 11); utilization warnings may be invisible.

## Notes

- BatteryTempStreamStale at the end of the replay ignored (1 change(s))
