# Evidence Report - baseline--hot_nominal

- **Campaign:** baseline
- **Scenario:** hot_nominal
- **Run ID:** baseline--hot_nominal
- **Generated:** 2026-10-08T06:10:45Z
- **Verdict:** **PASS**

## Provenance and reproduction

- Case (ASC): [case.asc](../experiments/baseline/hot_nominal/case.asc)
- Ground truth: [case.ground_truth.yaml](../experiments/baseline/hot_nominal/case.ground_truth.yaml)
- Oracle: [case.oracle.yaml](../experiments/baseline/hot_nominal/case.oracle.yaml)
- Experiment: [experiment.yaml](../experiments/baseline/hot_nominal/experiment.yaml)
- Logs: `can.log`, `collector.log`, `dfm.log`, `dfm_sovd_bridge.log`, `guardian.log`, `vss_bridge.log`, `collector.out`
- Case path (as recorded): `/app/reports/campaign-20261008-055450/experiments/baseline/hot_nominal/case`

## Diagnostic chain

```text
replay (ASC) -> KUKSA CAN Provider -> KUKSA Data Broker -> VSS uProtocol Publisher -> Battery Thermal Guardian -> DFM -> OpenSOVD -> Evidence Collector
```

## Fault catalog

| Fault code | Category | Severity | Description |
|---|---|---|---|
| BatteryOverTempWarning | Hardware | Warn | Maximum cell temperature entered the configured warning band. |
| BatteryTempStreamStale | Communication | Error | No battery temperature sample received within the missing-packet timeout. |

## Injections

_No injections in this case (baseline)._

## Expected vs. observed

Oracle: 1 expected, 1 matched, 0 missing, 0 not reached, 0 unexpected, 0 not applicable

| Status | Fault | Class | Level | Stage | Expected ms | Observed ms | Signal | OpenSOVD ms |
|---|---|---|---|---|---|---|---|---|
| MATCHED | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Failed | 0 | 0 | temp_max | 50 |

## Detection evidence

| t_ms | Fault | Class | Level | Stage | Signal | Observed | Limit | Residual | Utilization | Interval ms |
|---|---|---|---|---|---|---|---|---|---|---|
| 0 | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Failed | temp_max | 60 | 60 | 0 | - | - |
| 20500 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | - | 536.6401 | 500 | 36.640076 | - | - |

## DFM / OpenSOVD correlation

- URL: `http://127.0.0.1:7690/sovd/v1/components/battery_guardian/data/faults`
- Polls: 234 (0 failed)
- Activations: 2; not visible: 0; unexplained: 1

| t_ms | Code |
|---|---|
| 50 | BatteryOverTempWarning |
| 20463 | BatteryTempStreamStale |

Unexplained: `BatteryTempStreamStale`@20463ms

## Timing

- Replay end: 19900 ms; battery stream end: 19900 ms

| Injection | Fault | Injected ms | Detected ms | Detection latency ms | OpenSOVD latency ms |
|---|---|---|---|---|---|
| - | BatteryOverTempWarning | - | 0 | - | 50 |

## Verdict rationale

All 1 expected Guardian change(s) matched and no unexpected change was observed.

## Observer artifacts

- Final live-observer view: [observer.html](observer.html)

Observer artifacts are illustrative only and never a source of evaluation facts.

## Gaps and limitations

- **Mitigation:** not instrumented (v1 is event-only, ADR-007) - no mitigation event is recorded; this chain link is intentionally absent.
- **OpenSOVD fault status:** only activation times are captured; the `testFailed`/`confirmedDtc`/`warningIndicator` triple is not observable.
- **Unmapped Guardian warnings:** only DFM-mapped `class/level` pairs reach the collector stream (ADR-016 section 11); utilization warnings may be invisible.

## Notes

- BatteryTempStreamStale at the end of the replay ignored (1 change(s))
