# Evidence Report - signal.spike--hot_nominal

- **Campaign:** signal.spike
- **Scenario:** hot_nominal
- **Run ID:** signal.spike--hot_nominal
- **Generated:** 2026-10-08T06:10:45Z
- **Verdict:** **PASS**

## Provenance and reproduction

- Case (ASC): [case.asc](../experiments/signal.spike/hot_nominal/case.asc)
- Ground truth: [case.ground_truth.yaml](../experiments/signal.spike/hot_nominal/case.ground_truth.yaml)
- Oracle: [case.oracle.yaml](../experiments/signal.spike/hot_nominal/case.oracle.yaml)
- Experiment: [experiment.yaml](../experiments/signal.spike/hot_nominal/experiment.yaml)
- Logs: `can.log`, `collector.log`, `dfm.log`, `dfm_sovd_bridge.log`, `guardian.log`, `vss_bridge.log`, `collector.out`
- Case path (as recorded): `/app/reports/campaign-20261008-055450/experiments/signal.spike/hot_nominal/case`

## Diagnostic chain

```text
replay (ASC) -> KUKSA CAN Provider -> KUKSA Data Broker -> VSS uProtocol Publisher -> Battery Thermal Guardian -> DFM -> OpenSOVD -> Evidence Collector
```

## Fault catalog

| Fault code | Category | Severity | Description |
|---|---|---|---|
| BatteryOverTempWarning | Hardware | Warn | Maximum cell temperature entered the configured warning band. |
| BatterySignalStuck | Communication | Error | A battery signal stayed flat while other signals changed (stuck signal). |
| BatteryTempRate | Configuration | Error | Temperature changed faster than physically possible. |
| BatteryTempStreamStale | Communication | Error | No battery temperature sample received within the missing-packet timeout. |

## Injections

### signal-spike-1 - signal.spike

- Verdict: **PASS** (0/0 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 1000..1100 ms (slot 1000..4500)
- `temp_max` / `spike`: requested duration_samples=1, delta=0.5; executed [60.5]

### signal-spike-2 - signal.spike

- Verdict: **PASS** (0/0 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 4500..4600 ms (slot 4500..8000)
- `temp_max` / `spike`: requested duration_samples=1, delta=0.5; executed [60.5]

### signal-spike-3 - signal.spike

- Verdict: **PASS** (0/0 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 8000..8100 ms (slot 8000..11500)
- `temp_max` / `spike`: requested duration_samples=1, delta=0.5; executed [60.5]

### signal-spike-4 - signal.spike

- Verdict: **PASS** (4/4 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 11500..11600 ms (slot 11500..15000)
- `temp_max` / `spike`: requested duration_samples=1, delta=0.5; executed [61]

### signal-spike-5 - signal.spike

- Verdict: **PASS** (4/4 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 15000..15100 ms (slot 15000..-)
- `temp_max` / `spike`: requested duration_samples=1, delta=0.5; executed [61]

## Expected vs. observed

Oracle: 9 expected, 9 matched, 0 missing, 0 not reached, 0 unexpected, 10 not applicable

| Status | Fault | Class | Level | Stage | Expected ms | Observed ms | Signal | OpenSOVD ms |
|---|---|---|---|---|---|---|---|---|
| MATCHED | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Failed | 0 | 0 | temp_max | 57 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 11500 | 11500 | temp_min | 11564 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 11500 | 11500 | temp_max | 11564 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 11700 | 11700 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 12500 | 12500 | temp_avg | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 15000 | 15000 | temp_avg | 15064 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 15000 | 15000 | temp_max | 15064 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 15200 | 15200 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 16000 | 16000 | temp_avg | - |

## Detection evidence

| t_ms | Fault | Class | Level | Stage | Signal | Observed | Limit | Residual | Utilization | Interval ms |
|---|---|---|---|---|---|---|---|---|---|---|
| 0 | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Failed | temp_max | 60 | 60 | 0 | - | - |
| 11500 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 11500 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_max | 10 | 5.69 | 4.31 | 1.7574692 | 100 |
| 11700 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 12500 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 15000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_avg | 0 | 0.25 | - | - | - |
| 15000 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_max | 10 | 5.69 | 4.31 | 1.7574692 | 100 |
| 15200 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 16000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 20500 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | - | 537.62305 | 500 | 37.623047 | - | - |

## DFM / OpenSOVD correlation

- URL: `http://127.0.0.1:7690/sovd/v1/components/battery_guardian/data/faults`
- Polls: 234 (0 failed)
- Activations: 6; not visible: 0; unexplained: 1

| t_ms | Code |
|---|---|
| 57 | BatteryOverTempWarning |
| 11564 | BatterySignalStuck |
| 11564 | BatteryTempRate |
| 15064 | BatterySignalStuck |
| 15064 | BatteryTempRate |
| 20464 | BatteryTempStreamStale |

Unexplained: `BatteryTempStreamStale`@20464ms

## Timing

- Replay end: 19900 ms; battery stream end: 19900 ms

| Injection | Fault | Injected ms | Detected ms | Detection latency ms | OpenSOVD latency ms |
|---|---|---|---|---|---|
| - | BatteryOverTempWarning | - | 0 | - | 57 |
| signal-spike-4 | BatterySignalStuck | 11500 | 11500 | 0 | 64 |
| signal-spike-4 | BatteryTempRate | 11500 | 11500 | 0 | 64 |
| signal-spike-4 | BatteryTempRate | 11500 | 11700 | 200 | - |
| signal-spike-4 | BatterySignalStuck | 11500 | 12500 | 1000 | - |
| signal-spike-5 | BatterySignalStuck | 15000 | 15000 | 0 | 64 |
| signal-spike-5 | BatteryTempRate | 15000 | 15000 | 0 | 64 |
| signal-spike-5 | BatteryTempRate | 15000 | 15200 | 200 | - |
| signal-spike-5 | BatterySignalStuck | 15000 | 16000 | 1000 | - |

## Verdict rationale

All 9 expected Guardian change(s) matched and no unexpected change was observed.

## Observer artifacts

- Final live-observer view: [observer.html](observer.html)

Observer artifacts are illustrative only and never a source of evaluation facts.

## Gaps and limitations

- **Mitigation:** not instrumented (v1 is event-only, ADR-007) - no mitigation event is recorded; this chain link is intentionally absent.
- **OpenSOVD fault status:** only activation times are captured; the `testFailed`/`confirmedDtc`/`warningIndicator` triple is not observable.
- **Unmapped Guardian warnings:** only DFM-mapped `class/level` pairs reach the collector stream (ADR-016 section 11); utilization warnings may be invisible.

## Notes

- BatteryTempStreamStale at the end of the replay ignored (1 change(s))
