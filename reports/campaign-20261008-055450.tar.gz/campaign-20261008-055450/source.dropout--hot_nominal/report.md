# Evidence Report - source.dropout--hot_nominal

- **Campaign:** source.dropout
- **Scenario:** hot_nominal
- **Run ID:** source.dropout--hot_nominal
- **Generated:** 2026-10-08T06:10:45Z
- **Verdict:** **PASS**

## Provenance and reproduction

- Case (ASC): [case.asc](../experiments/source.dropout/hot_nominal/case.asc)
- Ground truth: [case.ground_truth.yaml](../experiments/source.dropout/hot_nominal/case.ground_truth.yaml)
- Oracle: [case.oracle.yaml](../experiments/source.dropout/hot_nominal/case.oracle.yaml)
- Experiment: [experiment.yaml](../experiments/source.dropout/hot_nominal/experiment.yaml)
- Logs: `can.log`, `collector.log`, `dfm.log`, `dfm_sovd_bridge.log`, `guardian.log`, `vss_bridge.log`, `collector.out`
- Case path (as recorded): `/app/reports/campaign-20261008-055450/experiments/source.dropout/hot_nominal/case`

## Diagnostic chain

```text
replay (ASC) -> KUKSA CAN Provider -> KUKSA Data Broker -> VSS uProtocol Publisher -> Battery Thermal Guardian -> DFM -> OpenSOVD -> Evidence Collector
```

## Fault catalog

| Fault code | Category | Severity | Description |
|---|---|---|---|
| BatteryOverTempWarning | Hardware | Warn | Maximum cell temperature entered the configured warning band. |
| BatterySignalStuck | Communication | Error | A battery signal stayed flat while other signals changed (stuck signal). |
| BatteryTempGenerationGap | Communication | Error | Source timestamps skipped at least one generation; battery samples were lost. |
| BatteryTempStreamStale | Communication | Error | No battery temperature sample received within the missing-packet timeout. |

## Injections

### source-dropout-1 - source.dropout

- Verdict: **PASS** (4/4 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 1000..1300 ms (slot 1000..4500)
- Mutations: _(none - transport/source fault)_

### source-dropout-2 - source.dropout

- Verdict: **PASS** (4/4 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 4500..4900 ms (slot 4500..8000)
- Mutations: _(none - transport/source fault)_

### source-dropout-3 - source.dropout

- Verdict: **PASS** (6/6 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 8000..8600 ms (slot 8000..11500)
- Mutations: _(none - transport/source fault)_

### source-dropout-4 - source.dropout

- Verdict: **PASS** (8/8 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 11500..12400 ms (slot 11500..15000)
- Mutations: _(none - transport/source fault)_

### source-dropout-5 - source.dropout

- Verdict: **PASS** (6/6 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 15000..16900 ms (slot 15000..-)
- Mutations: _(none - transport/source fault)_

## Expected vs. observed

Oracle: 29 expected, 29 matched, 0 missing, 0 not reached, 0 unexpected, 0 not applicable

| Status | Fault | Class | Level | Stage | Expected ms | Observed ms | Signal | OpenSOVD ms |
|---|---|---|---|---|---|---|---|---|
| MATCHED | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Failed | 0 | 0 | temp_max | 71 |
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | 1300 | 1300 | - | 1379 |
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | 1400 | 1400 | - | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 2000 | 2000 | temp_max | 2072 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 2200 | 2200 | temp_max | - |
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | 4900 | 4900 | - | 4975 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 5000 | 5000 | temp_min | 5077 |
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | 5000 | 5000 | - | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 5300 | 5300 | temp_avg | - |
| MATCHED | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | 8500 | 8500 | - | 8475 |
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | 8600 | 8600 | - | 8679 |
| MATCHED | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Passed | 8600 | 8600 | - | - |
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | 8700 | 8700 | - | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 9000 | 9000 | temp_min | 9077 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 9500 | 9500 | temp_avg | - |
| MATCHED | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | 12000 | 12000 | - | 11978 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 12400 | 12400 | temp_max | 12476 |
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | 12400 | 12400 | - | 12476 |
| MATCHED | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Passed | 12400 | 12400 | - | - |
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | 12500 | 12500 | - | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 12800 | 12800 | temp_min | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 13000 | 13000 | temp_min | 13079 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 13300 | 13300 | temp_avg | - |
| MATCHED | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | 15500 | 15500 | - | 15471 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 16900 | 16900 | temp_avg | 16977 |
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | 16900 | 16900 | - | 16977 |
| MATCHED | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Passed | 16900 | 16900 | - | - |
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | 17000 | 17000 | - | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 17800 | 17800 | temp_max | - |

## Detection evidence

| t_ms | Fault | Class | Level | Stage | Signal | Observed | Limit | Residual | Utilization | Interval ms |
|---|---|---|---|---|---|---|---|---|---|---|
| 0 | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Failed | temp_max | 60 | 60 | 0 | - | - |
| 1300 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | - | 400 | 150 | 250 | - | 400 |
| 1400 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | - | - | - | - | - | - |
| 2000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_max | 0 | 0.25 | - | - | - |
| 2200 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 4900 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | - | 500 | 150 | 350 | - | 500 |
| 5000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 5000 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | - | - | - | - | - | - |
| 5300 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 8500 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | - | 550.53253 | 500 | 50.53253 | - | - |
| 8600 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | - | 700 | 150 | 550 | - | 700 |
| 8600 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Passed | - | - | - | - | - | - |
| 8700 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | - | - | - | - | - | - |
| 9000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 9500 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 12000 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | - | 551.0304 | 500 | 51.030396 | - | - |
| 12400 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_max | 0 | 0.25 | - | - | - |
| 12400 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | - | 1000 | 150 | 850 | - | 1000 |
| 12400 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Passed | - | - | - | - | - | - |
| 12500 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | - | - | - | - | - | - |
| 12800 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 13000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 13300 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 15500 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | - | 551.7091 | 500 | 51.709106 | - | - |
| 16900 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | - | 2000 | 150 | 1850 | - | 2000 |
| 16900 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_avg | 0 | 0.25 | - | - | - |
| 16900 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Passed | - | - | - | - | - | - |
| 17000 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | - | - | - | - | - | - |
| 17800 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 20500 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | - | 551.26025 | 500 | 51.260254 | - | - |

## DFM / OpenSOVD correlation

- URL: `http://127.0.0.1:7690/sovd/v1/components/battery_guardian/data/faults`
- Polls: 234 (0 failed)
- Activations: 16; not visible: 0; unexplained: 1

| t_ms | Code |
|---|---|
| 71 | BatteryOverTempWarning |
| 1379 | BatteryTempGenerationGap |
| 2072 | BatterySignalStuck |
| 4975 | BatteryTempGenerationGap |
| 5077 | BatterySignalStuck |
| 8475 | BatteryTempStreamStale |
| 8679 | BatteryTempGenerationGap |
| 9077 | BatterySignalStuck |
| 11978 | BatteryTempStreamStale |
| 12476 | BatterySignalStuck |
| 12476 | BatteryTempGenerationGap |
| 13079 | BatterySignalStuck |
| 15471 | BatteryTempStreamStale |
| 16977 | BatterySignalStuck |
| 16977 | BatteryTempGenerationGap |
| 20476 | BatteryTempStreamStale |

Unexplained: `BatteryTempStreamStale`@20476ms

## Timing

- Replay end: 19900 ms; battery stream end: 19900 ms

| Injection | Fault | Injected ms | Detected ms | Detection latency ms | OpenSOVD latency ms |
|---|---|---|---|---|---|
| - | BatteryOverTempWarning | - | 0 | - | 71 |
| source-dropout-1 | BatteryTempGenerationGap | 1000 | 1300 | 300 | 79 |
| source-dropout-1 | BatteryTempGenerationGap | 1000 | 1400 | 400 | - |
| source-dropout-1 | BatterySignalStuck | 1000 | 2000 | 1000 | 72 |
| source-dropout-1 | BatterySignalStuck | 1000 | 2200 | 1200 | - |
| source-dropout-2 | BatteryTempGenerationGap | 4500 | 4900 | 400 | 75 |
| source-dropout-2 | BatterySignalStuck | 4500 | 5000 | 500 | 77 |
| source-dropout-2 | BatteryTempGenerationGap | 4500 | 5000 | 500 | - |
| source-dropout-2 | BatterySignalStuck | 4500 | 5300 | 800 | - |
| source-dropout-3 | BatteryTempStreamStale | 8000 | 8500 | 500 | -25 |
| source-dropout-3 | BatteryTempGenerationGap | 8000 | 8600 | 600 | 79 |
| source-dropout-3 | BatteryTempStreamStale | 8000 | 8600 | 600 | - |
| source-dropout-3 | BatteryTempGenerationGap | 8000 | 8700 | 700 | - |
| source-dropout-3 | BatterySignalStuck | 8000 | 9000 | 1000 | 77 |
| source-dropout-3 | BatterySignalStuck | 8000 | 9500 | 1500 | - |
| source-dropout-4 | BatteryTempStreamStale | 11500 | 12000 | 500 | -22 |
| source-dropout-4 | BatterySignalStuck | 11500 | 12400 | 900 | 76 |
| source-dropout-4 | BatteryTempGenerationGap | 11500 | 12400 | 900 | 76 |
| source-dropout-4 | BatteryTempStreamStale | 11500 | 12400 | 900 | - |
| source-dropout-4 | BatteryTempGenerationGap | 11500 | 12500 | 1000 | - |
| source-dropout-4 | BatterySignalStuck | 11500 | 12800 | 1300 | - |
| source-dropout-4 | BatterySignalStuck | 11500 | 13000 | 1500 | 79 |
| source-dropout-4 | BatterySignalStuck | 11500 | 13300 | 1800 | - |
| source-dropout-5 | BatteryTempStreamStale | 15000 | 15500 | 500 | -29 |
| source-dropout-5 | BatterySignalStuck | 15000 | 16900 | 1900 | 77 |
| source-dropout-5 | BatteryTempGenerationGap | 15000 | 16900 | 1900 | 77 |
| source-dropout-5 | BatteryTempStreamStale | 15000 | 16900 | 1900 | - |
| source-dropout-5 | BatteryTempGenerationGap | 15000 | 17000 | 2000 | - |
| source-dropout-5 | BatterySignalStuck | 15000 | 17800 | 2800 | - |

## Verdict rationale

All 29 expected Guardian change(s) matched and no unexpected change was observed.

## Observer artifacts

- Final live-observer view: [observer.html](observer.html)

Observer artifacts are illustrative only and never a source of evaluation facts.

## Gaps and limitations

- **Mitigation:** not instrumented (v1 is event-only, ADR-007) - no mitigation event is recorded; this chain link is intentionally absent.
- **OpenSOVD fault status:** only activation times are captured; the `testFailed`/`confirmedDtc`/`warningIndicator` triple is not observable.
- **Unmapped Guardian warnings:** only DFM-mapped `class/level` pairs reach the collector stream (ADR-016 section 11); utilization warnings may be invisible.

## Notes

- BatteryTempStreamStale at the end of the replay ignored (1 change(s))
