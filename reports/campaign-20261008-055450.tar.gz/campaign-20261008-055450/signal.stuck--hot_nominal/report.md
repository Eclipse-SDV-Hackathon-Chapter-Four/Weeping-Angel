# Evidence Report - signal.stuck--hot_nominal

- **Campaign:** signal.stuck
- **Scenario:** hot_nominal
- **Run ID:** signal.stuck--hot_nominal
- **Generated:** 2026-10-08T06:10:45Z
- **Verdict:** **PASS**

## Provenance and reproduction

- Case (ASC): [case.asc](../experiments/signal.stuck/hot_nominal/case.asc)
- Ground truth: [case.ground_truth.yaml](../experiments/signal.stuck/hot_nominal/case.ground_truth.yaml)
- Oracle: [case.oracle.yaml](../experiments/signal.stuck/hot_nominal/case.oracle.yaml)
- Experiment: [experiment.yaml](../experiments/signal.stuck/hot_nominal/experiment.yaml)
- Logs: `can.log`, `collector.log`, `dfm.log`, `dfm_sovd_bridge.log`, `guardian.log`, `vss_bridge.log`, `collector.out`
- Case path (as recorded): `/app/reports/campaign-20261008-055450/experiments/signal.stuck/hot_nominal/case`

## Diagnostic chain

```text
replay (ASC) -> KUKSA CAN Provider -> KUKSA Data Broker -> VSS uProtocol Publisher -> Battery Thermal Guardian -> DFM -> OpenSOVD -> Evidence Collector
```

## Fault catalog

| Fault code | Category | Severity | Description |
|---|---|---|---|
| BatteryOverTempWarning | Hardware | Warn | Maximum cell temperature entered the configured warning band. |
| BatterySignalStuck | Communication | Error | A battery signal stayed flat while other signals changed (stuck signal). |
| BatterySocRate | Configuration | Error | State of charge changed faster than physically possible. |
| BatteryTempStreamStale | Communication | Error | No battery temperature sample received within the missing-packet timeout. |

## Injections

### signal-stuck-1 - signal.stuck

- Verdict: **PASS** (0/0 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 1000..1900 ms (slot 1000..4500)
- `temp_avg` / `stuck`: requested duration_samples=9; executed [58.5, 58.5, 58.5, 58.5, 58.5, 58.5, 58.5, 58.5, 58.5]

### signal-stuck-2 - signal.stuck

- Verdict: **PASS** (4/4 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 4500..5500 ms (slot 4500..8000)
- `temp_avg` / `stuck`: requested duration_samples=10; executed [58.5, 58.5, 58.5, 58.5, 58.5, 58.5, 58.5, 58.5, 58.5, 58.5]
- `soc` / `drift`: requested duration_samples=10, rate_per_sample=-0.5; executed [75.5, 75, 74.5, 74, 73.5, 73, 72.5, 72, 71.5, 71]

### signal-stuck-3 - signal.stuck

- Verdict: **PASS** (4/4 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 8000..9100 ms (slot 8000..11500)
- `temp_avg` / `stuck`: requested duration_samples=11; executed [58.5, 58.5, 58.5, 58.5, 58.5, 58.5, 58.5, 58.5, 58.5, 58.5, 58.5]
- `soc` / `drift`: requested duration_samples=11, rate_per_sample=-0.5; executed [74, 73.5, 73, 72.5, 72, 71.5, 71, 70.5, 70, 69.5, 69]

### signal-stuck-4 - signal.stuck

- Verdict: **PASS** (4/4 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 11500..13000 ms (slot 11500..15000)
- `temp_avg` / `stuck`: requested duration_samples=15; executed [58.5, 58.5, 58.5, 58.5, 58.5, 58.5, 58.5, 58.5, 58.5, 58.5, 58.5, 58.5, 58.5, 58.5, 58.5]
- `soc` / `drift`: requested duration_samples=15, rate_per_sample=-0.5; executed [72, 71.5, 71, 70.5, 70, 69.5, 69, 68.5, 68, 67.5, 67, 66.5, 66, 65.5, 65]

### signal-stuck-5 - signal.stuck

- Verdict: **PASS** (4/4 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 15000..17000 ms (slot 15000..-)
- `temp_avg` / `stuck`: requested duration_samples=20; executed [58.5, 58.5, 58.5, 58.5, 58.5, 58.5, 58.5, 58.5, 58.5, 58.5, 58.5, 58.5, 58.5, 58.5, 58.5, 58.5, 58.5, 58.5, 58.5, 58.5]
- `soc` / `drift`: requested duration_samples=20, rate_per_sample=-0.5; executed [70.5, 70, 69.5, 69, 68.5, 68, 67.5, 67, 66.5, 66, 65.5, 65, 64.5, 64, 63.5, 63, 62.5, 62, 61.5, 61]

## Expected vs. observed

Oracle: 17 expected, 17 matched, 0 missing, 0 not reached, 0 unexpected, 0 not applicable

| Status | Fault | Class | Level | Stage | Expected ms | Observed ms | Signal | OpenSOVD ms |
|---|---|---|---|---|---|---|---|---|
| MATCHED | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Failed | 0 | 0 | temp_max | 56 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 4500 | 4500 | temp_avg | 4563 |
| MATCHED | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Failed | 5500 | 5500 | soc | 5560 |
| MATCHED | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Passed | 5600 | 5600 | soc | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 6400 | 6400 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 8100 | 8100 | temp_min | 8166 |
| MATCHED | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Failed | 9100 | 9100 | soc | 9164 |
| MATCHED | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Passed | 9200 | 9200 | soc | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 10000 | 10000 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 11500 | 11500 | temp_max | 11564 |
| MATCHED | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Failed | 13000 | 13000 | soc | 13060 |
| MATCHED | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Passed | 13100 | 13100 | soc | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 13900 | 13900 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 15100 | 15100 | temp_avg | 15165 |
| MATCHED | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Failed | 17000 | 17000 | soc | 17059 |
| MATCHED | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Passed | 17100 | 17100 | soc | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 17900 | 17900 | temp_min | - |

## Detection evidence

| t_ms | Fault | Class | Level | Stage | Signal | Observed | Limit | Residual | Utilization | Interval ms |
|---|---|---|---|---|---|---|---|---|---|---|
| 0 | BatteryOverTempWarning | THERMAL_LIMIT | WARNING | Failed | temp_max | 60 | 60 | 0 | - | - |
| 4500 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_avg | 0 | 0.25 | - | - | - |
| 5500 | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Failed | soc | 45 | 5 | 40 | - | 100 |
| 5600 | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Passed | soc | - | - | - | - | - |
| 6400 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 8100 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 9100 | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Failed | soc | 45 | 5 | 40 | - | 100 |
| 9200 | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Passed | soc | - | - | - | - | - |
| 10000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 11500 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_max | 0 | 0.25 | - | - | - |
| 13000 | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Failed | soc | 65 | 5 | 60 | - | 100 |
| 13100 | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Passed | soc | - | - | - | - | - |
| 13900 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 15100 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_avg | 0 | 0.25 | - | - | - |
| 17000 | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Failed | soc | 85 | 5 | 80 | - | 100 |
| 17100 | BatterySocRate | PHYSICAL_SOC_RATE | VIOLATION | Passed | soc | - | - | - | - | - |
| 17900 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 20500 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | - | 536.9548 | 500 | 36.954773 | - | - |

## DFM / OpenSOVD correlation

- URL: `http://127.0.0.1:7690/sovd/v1/components/battery_guardian/data/faults`
- Polls: 234 (0 failed)
- Activations: 10; not visible: 0; unexplained: 1

| t_ms | Code |
|---|---|
| 56 | BatteryOverTempWarning |
| 4563 | BatterySignalStuck |
| 5560 | BatterySocRate |
| 8166 | BatterySignalStuck |
| 9164 | BatterySocRate |
| 11564 | BatterySignalStuck |
| 13060 | BatterySocRate |
| 15165 | BatterySignalStuck |
| 17059 | BatterySocRate |
| 20458 | BatteryTempStreamStale |

Unexplained: `BatteryTempStreamStale`@20458ms

## Timing

- Replay end: 19900 ms; battery stream end: 19900 ms

| Injection | Fault | Injected ms | Detected ms | Detection latency ms | OpenSOVD latency ms |
|---|---|---|---|---|---|
| - | BatteryOverTempWarning | - | 0 | - | 56 |
| signal-stuck-2 | BatterySignalStuck | 4500 | 4500 | 0 | 63 |
| signal-stuck-2 | BatterySocRate | 4500 | 5500 | 1000 | 60 |
| signal-stuck-2 | BatterySocRate | 4500 | 5600 | 1100 | - |
| signal-stuck-2 | BatterySignalStuck | 4500 | 6400 | 1900 | - |
| signal-stuck-3 | BatterySignalStuck | 8000 | 8100 | 100 | 66 |
| signal-stuck-3 | BatterySocRate | 8000 | 9100 | 1100 | 64 |
| signal-stuck-3 | BatterySocRate | 8000 | 9200 | 1200 | - |
| signal-stuck-3 | BatterySignalStuck | 8000 | 10000 | 2000 | - |
| signal-stuck-4 | BatterySignalStuck | 11500 | 11500 | 0 | 64 |
| signal-stuck-4 | BatterySocRate | 11500 | 13000 | 1500 | 60 |
| signal-stuck-4 | BatterySocRate | 11500 | 13100 | 1600 | - |
| signal-stuck-4 | BatterySignalStuck | 11500 | 13900 | 2400 | - |
| signal-stuck-5 | BatterySignalStuck | 15000 | 15100 | 100 | 65 |
| signal-stuck-5 | BatterySocRate | 15000 | 17000 | 2000 | 59 |
| signal-stuck-5 | BatterySocRate | 15000 | 17100 | 2100 | - |
| signal-stuck-5 | BatterySignalStuck | 15000 | 17900 | 2900 | - |

## Verdict rationale

All 17 expected Guardian change(s) matched and no unexpected change was observed.

## Observer artifacts

- Final live-observer view: [observer.html](observer.html)

Observer artifacts are illustrative only and never a source of evaluation facts.

## Gaps and limitations

- **Mitigation:** not instrumented (v1 is event-only, ADR-007) - no mitigation event is recorded; this chain link is intentionally absent.
- **OpenSOVD fault status:** only activation times are captured; the `testFailed`/`confirmedDtc`/`warningIndicator` triple is not observable.
- **Unmapped Guardian warnings:** only DFM-mapped `class/level` pairs reach the collector stream (ADR-016 section 11); utilization warnings may be invisible.

## Notes

- BatteryTempStreamStale at the end of the replay ignored (1 change(s))
