# Evidence Report - signal.out_of_range--cold_nominal

- **Campaign:** signal.out_of_range
- **Scenario:** cold_nominal
- **Run ID:** signal.out_of_range--cold_nominal
- **Generated:** 2026-10-08T06:10:45Z
- **Verdict:** **PASS**

## Provenance and reproduction

- Case (ASC): [case.asc](../experiments/signal.out_of_range/cold_nominal/case.asc)
- Ground truth: [case.ground_truth.yaml](../experiments/signal.out_of_range/cold_nominal/case.ground_truth.yaml)
- Oracle: [case.oracle.yaml](../experiments/signal.out_of_range/cold_nominal/case.oracle.yaml)
- Experiment: [experiment.yaml](../experiments/signal.out_of_range/cold_nominal/experiment.yaml)
- Logs: `can.log`, `collector.log`, `dfm.log`, `dfm_sovd_bridge.log`, `guardian.log`, `vss_bridge.log`, `collector.out`
- Case path (as recorded): `/app/reports/campaign-20261008-055450/experiments/signal.out_of_range/cold_nominal/case`

## Diagnostic chain

```text
replay (ASC) -> KUKSA CAN Provider -> KUKSA Data Broker -> VSS uProtocol Publisher -> Battery Thermal Guardian -> DFM -> OpenSOVD -> Evidence Collector
```

## Fault catalog

| Fault code | Category | Severity | Description |
|---|---|---|---|
| BatteryOverTempCritical | Hardware | Fatal | Maximum cell temperature reached the configured critical band. |
| BatterySignalStuck | Communication | Error | A battery signal stayed flat while other signals changed (stuck signal). |
| BatteryTempAbsoluteLimit | Hardware | Fatal | Battery temperature outside the absolute physical limits. |
| BatteryTempHotspot | Hardware | Error | Max temperature deviates from average beyond the hotspot limit. |
| BatteryTempRate | Configuration | Error | Temperature changed faster than physically possible. |
| BatteryTempSpread | Hardware | Error | Spread between max and min temperature exceeds the physical limit. |
| BatteryTempStreamStale | Communication | Error | No battery temperature sample received within the missing-packet timeout. |

## Injections

### signal-out_of_range-1 - signal.out_of_range

- Verdict: **PASS** (8/8 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 1000..1500 ms (slot 1000..4500)
- `temp_min` / `out_of_range`: requested duration_samples=5, value=-30; executed [-30, -30, -30, -30, -30]

### signal-out_of_range-2 - signal.out_of_range

- Verdict: **PASS** (10/10 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 4500..5000 ms (slot 4500..8000)
- `temp_min` / `out_of_range`: requested duration_samples=5, value=-30.5; executed [-30.5, -30.5, -30.5, -30.5, -30.5]

### signal-out_of_range-3 - signal.out_of_range

- Verdict: **PASS** (12/12 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 8000..8500 ms (slot 8000..11500)
- `temp_max` / `out_of_range`: requested duration_samples=5, value=70; executed [70, 70, 70, 70, 70]

### signal-out_of_range-4 - signal.out_of_range

- Verdict: **PASS** (14/14 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 11500..12000 ms (slot 11500..15000)
- `temp_max` / `out_of_range`: requested duration_samples=5, value=70.5; executed [70.5, 70.5, 70.5, 70.5, 70.5]

### signal-out_of_range-5 - signal.out_of_range

- Verdict: **PASS** (14/14 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 15000..15500 ms (slot 15000..-)
- `temp_max` / `out_of_range`: requested duration_samples=5, value=75; executed [75, 75, 75, 75, 75]

## Expected vs. observed

Oracle: 58 expected, 58 matched, 0 missing, 0 not reached, 0 unexpected, 0 not applicable

| Status | Fault | Class | Level | Stage | Expected ms | Observed ms | Signal | OpenSOVD ms |
|---|---|---|---|---|---|---|---|---|
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 1000 | 1000 | temp_min | 1064 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | 1000 | 1000 | - | 1064 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 1100 | 1100 | temp_min | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 1500 | 1500 | temp_max | 1564 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 1500 | 1500 | temp_min | 1564 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | 1500 | 1500 | - | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 1600 | 1600 | temp_min | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 2000 | 2000 | temp_avg | - |
| MATCHED | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Failed | 4500 | 4500 | temp_min | 4557 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 4500 | 4500 | temp_min | 4557 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | 4500 | 4500 | - | 4557 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 4600 | 4600 | temp_min | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 4900 | 4900 | temp_avg | 4964 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 5000 | 5000 | temp_max | - |
| MATCHED | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Passed | 5000 | 5000 | temp_min | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 5000 | 5000 | temp_min | 5057 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | 5000 | 5000 | - | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 5100 | 5100 | temp_min | - |
| MATCHED | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Failed | 8000 | 8000 | temp_max | 8058 |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | 8000 | 8000 | temp_max | 8058 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 8000 | 8000 | temp_max | 8058 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | 8000 | 8000 | - | 8058 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 8100 | 8100 | temp_max | - |
| MATCHED | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Passed | 8500 | 8500 | temp_max | - |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | 8500 | 8500 | temp_max | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 8500 | 8500 | temp_max | 8558 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | 8500 | 8500 | - | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 8600 | 8600 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 8900 | 8900 | temp_min | 8955 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 9000 | 9000 | temp_avg | - |
| MATCHED | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Failed | 11500 | 11500 | temp_max | 11566 |
| MATCHED | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Failed | 11500 | 11500 | temp_max | 11566 |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | 11500 | 11500 | temp_max | 11566 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 11500 | 11500 | temp_max | 11566 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | 11500 | 11500 | - | 11566 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 11600 | 11600 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 11900 | 11900 | temp_min | 11963 |
| MATCHED | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Passed | 12000 | 12000 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 12000 | 12000 | temp_avg | - |
| MATCHED | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Passed | 12000 | 12000 | temp_max | - |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | 12000 | 12000 | temp_max | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 12000 | 12000 | temp_max | 12055 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | 12000 | 12000 | - | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 12100 | 12100 | temp_max | - |
| MATCHED | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Failed | 15000 | 15000 | temp_max | 15060 |
| MATCHED | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Failed | 15000 | 15000 | temp_max | 15060 |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | 15000 | 15000 | temp_max | 15060 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 15000 | 15000 | temp_max | 15060 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | 15000 | 15000 | - | 15060 |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 15100 | 15100 | temp_max | - |
| MATCHED | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Passed | 15500 | 15500 | temp_max | - |
| MATCHED | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Passed | 15500 | 15500 | temp_max | - |
| MATCHED | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | 15500 | 15500 | temp_max | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | 15500 | 15500 | temp_max | 15559 |
| MATCHED | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | 15500 | 15500 | - | - |
| MATCHED | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | 15600 | 15600 | temp_max | - |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | 15900 | 15900 | temp_min | 15956 |
| MATCHED | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | 16000 | 16000 | temp_avg | - |

## Detection evidence

| t_ms | Fault | Class | Level | Stage | Signal | Observed | Limit | Residual | Utilization | Interval ms |
|---|---|---|---|---|---|---|---|---|---|---|
| 1000 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_min | 190 | 6 | 184 | 31.666666 | 100 |
| 1000 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | - | 23.5 | 12 | 11.5 | 1.9583334 | - |
| 1100 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 1500 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_min | 190 | 8 | 182 | 23.75 | 100 |
| 1500 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_max | 0 | 0.25 | - | - | - |
| 1500 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | - | - | - | - | - | - |
| 1600 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 2000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 4500 | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Failed | temp_min | -30.5 | -30 | 0.5 | - | - |
| 4500 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_min | 210 | 6 | 204 | 35 | 100 |
| 4500 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | - | 25.5 | 12 | 13.5 | 2.125 | - |
| 4600 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 4900 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_avg | 0 | 0.25 | - | - | - |
| 5000 | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 5000 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_min | 215 | 8 | 207 | 26.875 | 100 |
| 5000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 5000 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | - | - | - | - | - | - |
| 5100 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_min | - | - | - | - | - |
| 8000 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | - | 77.5 | 12 | 65.5 | 6.4583335 | - |
| 8000 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | temp_max | 75.5 | 5 | 70.5 | 15.1 | - |
| 8000 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_max | 735 | 8 | 727 | 91.875 | 100 |
| 8000 | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Failed | temp_max | 70 | 70 | 0 | - | - |
| 8100 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 8500 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_max | 730 | 6 | 724 | 121.666664 | 100 |
| 8500 | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Passed | temp_max | - | - | - | - | - |
| 8500 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 8500 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | - | - | - | - | - | - |
| 8600 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 8900 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 9000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 11500 | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Failed | temp_max | 70.5 | 70 | 0.5 | - | - |
| 11500 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_max | 720 | 8 | 712 | 90 | 100 |
| 11500 | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Failed | temp_max | 70.5 | 70 | 0.5 | - | - |
| 11500 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | temp_max | 74.5 | 5 | 69.5 | 14.9 | - |
| 11500 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | - | 76.5 | 12 | 64.5 | 6.375 | - |
| 11600 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 11900 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 12000 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_max | 715 | 6 | 709 | 119.166664 | 100 |
| 12000 | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Passed | temp_max | - | - | - | - | - |
| 12000 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | - | - | - | - | - | - |
| 12000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 12000 | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 12000 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 12100 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 15000 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Failed | temp_max | 77 | 5 | 72 | 15.4 | - |
| 15000 | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Failed | temp_max | 75 | 70 | 5 | - | - |
| 15000 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_max | 750 | 8 | 742 | 93.75 | 100 |
| 15000 | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Failed | temp_max | 75 | 70 | 5 | - | - |
| 15000 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Failed | - | 79 | 12 | 67 | 6.5833335 | - |
| 15100 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 15500 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Failed | temp_max | 745 | 6 | 739 | 124.166664 | 100 |
| 15500 | BatteryOverTempCritical | THERMAL_LIMIT | CRITICAL | Passed | temp_max | - | - | - | - | - |
| 15500 | BatteryTempSpread | PHYSICAL_TEMP_SPREAD | VIOLATION | Passed | - | - | - | - | - | - |
| 15500 | BatteryTempHotspot | PHYSICAL_TEMP_HOTSPOT | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 15500 | BatteryTempAbsoluteLimit | PHYSICAL_TEMP_ABSOLUTE_LIMIT | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 15600 | BatteryTempRate | PHYSICAL_TEMP_RATE | VIOLATION | Passed | temp_max | - | - | - | - | - |
| 15900 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Failed | temp_min | 0 | 0.25 | - | - | - |
| 16000 | BatterySignalStuck | SIGNAL_STUCK | VIOLATION | Passed | temp_avg | - | - | - | - | - |
| 20500 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | - | 534.0747 | 500 | 34.074707 | - | - |

## DFM / OpenSOVD correlation

- URL: `http://127.0.0.1:7690/sovd/v1/components/battery_guardian/data/faults`
- Polls: 234 (0 failed)
- Activations: 30; not visible: 0; unexplained: 1

| t_ms | Code |
|---|---|
| 1064 | BatteryTempRate |
| 1064 | BatteryTempSpread |
| 1564 | BatterySignalStuck |
| 1564 | BatteryTempRate |
| 4557 | BatteryTempAbsoluteLimit |
| 4557 | BatteryTempRate |
| 4557 | BatteryTempSpread |
| 4964 | BatterySignalStuck |
| 5057 | BatteryTempRate |
| 8058 | BatteryOverTempCritical |
| 8058 | BatteryTempHotspot |
| 8058 | BatteryTempRate |
| 8058 | BatteryTempSpread |
| 8558 | BatteryTempRate |
| 8955 | BatterySignalStuck |
| 11566 | BatteryOverTempCritical |
| 11566 | BatteryTempAbsoluteLimit |
| 11566 | BatteryTempHotspot |
| 11566 | BatteryTempRate |
| 11566 | BatteryTempSpread |
| 11963 | BatterySignalStuck |
| 12055 | BatteryTempRate |
| 15060 | BatteryOverTempCritical |
| 15060 | BatteryTempAbsoluteLimit |
| 15060 | BatteryTempHotspot |
| 15060 | BatteryTempRate |
| 15060 | BatteryTempSpread |
| 15559 | BatteryTempRate |
| 15956 | BatterySignalStuck |
| 20455 | BatteryTempStreamStale |

Unexplained: `BatteryTempStreamStale`@20455ms

## Timing

- Replay end: 19900 ms; battery stream end: 19900 ms

| Injection | Fault | Injected ms | Detected ms | Detection latency ms | OpenSOVD latency ms |
|---|---|---|---|---|---|
| signal-out_of_range-1 | BatteryTempRate | 1000 | 1000 | 0 | 64 |
| signal-out_of_range-1 | BatteryTempSpread | 1000 | 1000 | 0 | 64 |
| signal-out_of_range-1 | BatteryTempRate | 1000 | 1100 | 100 | - |
| signal-out_of_range-1 | BatterySignalStuck | 1000 | 1500 | 500 | 64 |
| signal-out_of_range-1 | BatteryTempRate | 1000 | 1500 | 500 | 64 |
| signal-out_of_range-1 | BatteryTempSpread | 1000 | 1500 | 500 | - |
| signal-out_of_range-1 | BatteryTempRate | 1000 | 1600 | 600 | - |
| signal-out_of_range-1 | BatterySignalStuck | 1000 | 2000 | 1000 | - |
| signal-out_of_range-2 | BatteryTempAbsoluteLimit | 4500 | 4500 | 0 | 57 |
| signal-out_of_range-2 | BatteryTempRate | 4500 | 4500 | 0 | 57 |
| signal-out_of_range-2 | BatteryTempSpread | 4500 | 4500 | 0 | 57 |
| signal-out_of_range-2 | BatteryTempRate | 4500 | 4600 | 100 | - |
| signal-out_of_range-2 | BatterySignalStuck | 4500 | 4900 | 400 | 64 |
| signal-out_of_range-2 | BatterySignalStuck | 4500 | 5000 | 500 | - |
| signal-out_of_range-2 | BatteryTempAbsoluteLimit | 4500 | 5000 | 500 | - |
| signal-out_of_range-2 | BatteryTempRate | 4500 | 5000 | 500 | 57 |
| signal-out_of_range-2 | BatteryTempSpread | 4500 | 5000 | 500 | - |
| signal-out_of_range-2 | BatteryTempRate | 4500 | 5100 | 600 | - |
| signal-out_of_range-3 | BatteryOverTempCritical | 8000 | 8000 | 0 | 58 |
| signal-out_of_range-3 | BatteryTempHotspot | 8000 | 8000 | 0 | 58 |
| signal-out_of_range-3 | BatteryTempRate | 8000 | 8000 | 0 | 58 |
| signal-out_of_range-3 | BatteryTempSpread | 8000 | 8000 | 0 | 58 |
| signal-out_of_range-3 | BatteryTempRate | 8000 | 8100 | 100 | - |
| signal-out_of_range-3 | BatteryOverTempCritical | 8000 | 8500 | 500 | - |
| signal-out_of_range-3 | BatteryTempHotspot | 8000 | 8500 | 500 | - |
| signal-out_of_range-3 | BatteryTempRate | 8000 | 8500 | 500 | 58 |
| signal-out_of_range-3 | BatteryTempSpread | 8000 | 8500 | 500 | - |
| signal-out_of_range-3 | BatteryTempRate | 8000 | 8600 | 600 | - |
| signal-out_of_range-3 | BatterySignalStuck | 8000 | 8900 | 900 | 55 |
| signal-out_of_range-3 | BatterySignalStuck | 8000 | 9000 | 1000 | - |
| signal-out_of_range-4 | BatteryOverTempCritical | 11500 | 11500 | 0 | 66 |
| signal-out_of_range-4 | BatteryTempAbsoluteLimit | 11500 | 11500 | 0 | 66 |
| signal-out_of_range-4 | BatteryTempHotspot | 11500 | 11500 | 0 | 66 |
| signal-out_of_range-4 | BatteryTempRate | 11500 | 11500 | 0 | 66 |
| signal-out_of_range-4 | BatteryTempSpread | 11500 | 11500 | 0 | 66 |
| signal-out_of_range-4 | BatteryTempRate | 11500 | 11600 | 100 | - |
| signal-out_of_range-4 | BatterySignalStuck | 11500 | 11900 | 400 | 63 |
| signal-out_of_range-4 | BatteryOverTempCritical | 11500 | 12000 | 500 | - |
| signal-out_of_range-4 | BatterySignalStuck | 11500 | 12000 | 500 | - |
| signal-out_of_range-4 | BatteryTempAbsoluteLimit | 11500 | 12000 | 500 | - |
| signal-out_of_range-4 | BatteryTempHotspot | 11500 | 12000 | 500 | - |
| signal-out_of_range-4 | BatteryTempRate | 11500 | 12000 | 500 | 55 |
| signal-out_of_range-4 | BatteryTempSpread | 11500 | 12000 | 500 | - |
| signal-out_of_range-4 | BatteryTempRate | 11500 | 12100 | 600 | - |
| signal-out_of_range-5 | BatteryOverTempCritical | 15000 | 15000 | 0 | 60 |
| signal-out_of_range-5 | BatteryTempAbsoluteLimit | 15000 | 15000 | 0 | 60 |
| signal-out_of_range-5 | BatteryTempHotspot | 15000 | 15000 | 0 | 60 |
| signal-out_of_range-5 | BatteryTempRate | 15000 | 15000 | 0 | 60 |
| signal-out_of_range-5 | BatteryTempSpread | 15000 | 15000 | 0 | 60 |
| signal-out_of_range-5 | BatteryTempRate | 15000 | 15100 | 100 | - |
| signal-out_of_range-5 | BatteryOverTempCritical | 15000 | 15500 | 500 | - |
| signal-out_of_range-5 | BatteryTempAbsoluteLimit | 15000 | 15500 | 500 | - |
| signal-out_of_range-5 | BatteryTempHotspot | 15000 | 15500 | 500 | - |
| signal-out_of_range-5 | BatteryTempRate | 15000 | 15500 | 500 | 59 |
| signal-out_of_range-5 | BatteryTempSpread | 15000 | 15500 | 500 | - |
| signal-out_of_range-5 | BatteryTempRate | 15000 | 15600 | 600 | - |
| signal-out_of_range-5 | BatterySignalStuck | 15000 | 15900 | 900 | 56 |
| signal-out_of_range-5 | BatterySignalStuck | 15000 | 16000 | 1000 | - |

## Verdict rationale

All 58 expected Guardian change(s) matched and no unexpected change was observed.

## Observer artifacts

- Final live-observer view: [observer.html](observer.html)

Observer artifacts are illustrative only and never a source of evaluation facts.

## Gaps and limitations

- **Mitigation:** not instrumented (v1 is event-only, ADR-007) - no mitigation event is recorded; this chain link is intentionally absent.
- **OpenSOVD fault status:** only activation times are captured; the `testFailed`/`confirmedDtc`/`warningIndicator` triple is not observable.
- **Unmapped Guardian warnings:** only DFM-mapped `class/level` pairs reach the collector stream (ADR-016 section 11); utilization warnings may be invisible.

## Notes

- BatteryTempStreamStale at the end of the replay ignored (1 change(s))
