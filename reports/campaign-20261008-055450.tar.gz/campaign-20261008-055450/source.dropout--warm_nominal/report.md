# Evidence Report - source.dropout--warm_nominal

- **Campaign:** source.dropout
- **Scenario:** warm_nominal
- **Run ID:** source.dropout--warm_nominal
- **Generated:** 2026-10-08T06:10:45Z
- **Verdict:** **PASS**

## Provenance and reproduction

- Case (ASC): [case.asc](../experiments/source.dropout/warm_nominal/case.asc)
- Ground truth: [case.ground_truth.yaml](../experiments/source.dropout/warm_nominal/case.ground_truth.yaml)
- Oracle: [case.oracle.yaml](../experiments/source.dropout/warm_nominal/case.oracle.yaml)
- Experiment: [experiment.yaml](../experiments/source.dropout/warm_nominal/experiment.yaml)
- Logs: `can.log`, `collector.log`, `dfm.log`, `dfm_sovd_bridge.log`, `guardian.log`, `vss_bridge.log`, `collector.out`
- Case path (as recorded): `/app/reports/campaign-20261008-055450/experiments/source.dropout/warm_nominal/case`

## Diagnostic chain

```text
replay (ASC) -> KUKSA CAN Provider -> KUKSA Data Broker -> VSS uProtocol Publisher -> Battery Thermal Guardian -> DFM -> OpenSOVD -> Evidence Collector
```

## Fault catalog

| Fault code | Category | Severity | Description |
|---|---|---|---|
| BatteryTempGenerationGap | Communication | Error | Source timestamps skipped at least one generation; battery samples were lost. |
| BatteryTempStreamStale | Communication | Error | No battery temperature sample received within the missing-packet timeout. |

## Injections

### source-dropout-1 - source.dropout

- Verdict: **PASS** (2/2 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 1000..1300 ms (slot 1000..4500)
- Mutations: _(none - transport/source fault)_

### source-dropout-2 - source.dropout

- Verdict: **PASS** (2/2 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 4500..4900 ms (slot 4500..8000)
- Mutations: _(none - transport/source fault)_

### source-dropout-3 - source.dropout

- Verdict: **PASS** (4/4 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 8000..8600 ms (slot 8000..11500)
- Mutations: _(none - transport/source fault)_

### source-dropout-4 - source.dropout

- Verdict: **PASS** (4/4 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 11500..12400 ms (slot 11500..15000)
- Mutations: _(none - transport/source fault)_

### source-dropout-5 - source.dropout

- Verdict: **PASS** (4/4 matched, 0 missing, 0 unexpected, 0 not in OpenSOVD)
- Source window: 15000..16900 ms (slot 15000..-)
- Mutations: _(none - transport/source fault)_

## Expected vs. observed

Oracle: 16 expected, 16 matched, 0 missing, 0 not reached, 0 unexpected, 0 not applicable

| Status | Fault | Class | Level | Stage | Expected ms | Observed ms | Signal | OpenSOVD ms |
|---|---|---|---|---|---|---|---|---|
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | 1300 | 1300 | - | 1363 |
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | 1400 | 1400 | - | - |
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | 4900 | 4900 | - | 4967 |
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | 5000 | 5000 | - | - |
| MATCHED | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | 8500 | 8500 | - | 8467 |
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | 8600 | 8600 | - | 8661 |
| MATCHED | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Passed | 8600 | 8600 | - | - |
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | 8700 | 8700 | - | - |
| MATCHED | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | 12000 | 12000 | - | 11968 |
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | 12400 | 12400 | - | 12468 |
| MATCHED | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Passed | 12400 | 12400 | - | - |
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | 12500 | 12500 | - | - |
| MATCHED | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | 15500 | 15500 | - | 15468 |
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | 16900 | 16900 | - | 16963 |
| MATCHED | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Passed | 16900 | 16900 | - | - |
| MATCHED | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | 17000 | 17000 | - | - |

## Detection evidence

| t_ms | Fault | Class | Level | Stage | Signal | Observed | Limit | Residual | Utilization | Interval ms |
|---|---|---|---|---|---|---|---|---|---|---|
| 1300 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | - | 400 | 150 | 250 | - | 400 |
| 1400 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | - | - | - | - | - | - |
| 4900 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | - | 500 | 150 | 350 | - | 500 |
| 5000 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | - | - | - | - | - | - |
| 8500 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | - | 540.44385 | 500 | 40.443848 | - | - |
| 8600 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | - | 700 | 150 | 550 | - | 700 |
| 8600 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Passed | - | - | - | - | - | - |
| 8700 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | - | - | - | - | - | - |
| 12000 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | - | 540.88824 | 500 | 40.888245 | - | - |
| 12400 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | - | 1000 | 150 | 850 | - | 1000 |
| 12400 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Passed | - | - | - | - | - | - |
| 12500 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | - | - | - | - | - | - |
| 15500 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | - | 541.02014 | 500 | 41.02014 | - | - |
| 16900 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Passed | - | - | - | - | - | - |
| 16900 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Failed | - | 2000 | 150 | 1850 | - | 2000 |
| 17000 | BatteryTempGenerationGap | STREAM_GENERATION_GAP | VIOLATION | Passed | - | - | - | - | - | - |
| 20500 | BatteryTempStreamStale | STREAM_STALE | VIOLATION | Failed | - | 540.7983 | 500 | 40.79828 | - | - |

## DFM / OpenSOVD correlation

- URL: `http://127.0.0.1:7690/sovd/v1/components/battery_guardian/data/faults`
- Polls: 234 (0 failed)
- Activations: 9; not visible: 0; unexplained: 1

| t_ms | Code |
|---|---|
| 1363 | BatteryTempGenerationGap |
| 4967 | BatteryTempGenerationGap |
| 8467 | BatteryTempStreamStale |
| 8661 | BatteryTempGenerationGap |
| 11968 | BatteryTempStreamStale |
| 12468 | BatteryTempGenerationGap |
| 15468 | BatteryTempStreamStale |
| 16963 | BatteryTempGenerationGap |
| 20466 | BatteryTempStreamStale |

Unexplained: `BatteryTempStreamStale`@20466ms

## Timing

- Replay end: 19900 ms; battery stream end: 19900 ms

| Injection | Fault | Injected ms | Detected ms | Detection latency ms | OpenSOVD latency ms |
|---|---|---|---|---|---|
| source-dropout-1 | BatteryTempGenerationGap | 1000 | 1300 | 300 | 63 |
| source-dropout-1 | BatteryTempGenerationGap | 1000 | 1400 | 400 | - |
| source-dropout-2 | BatteryTempGenerationGap | 4500 | 4900 | 400 | 67 |
| source-dropout-2 | BatteryTempGenerationGap | 4500 | 5000 | 500 | - |
| source-dropout-3 | BatteryTempStreamStale | 8000 | 8500 | 500 | -33 |
| source-dropout-3 | BatteryTempGenerationGap | 8000 | 8600 | 600 | 61 |
| source-dropout-3 | BatteryTempStreamStale | 8000 | 8600 | 600 | - |
| source-dropout-3 | BatteryTempGenerationGap | 8000 | 8700 | 700 | - |
| source-dropout-4 | BatteryTempStreamStale | 11500 | 12000 | 500 | -32 |
| source-dropout-4 | BatteryTempGenerationGap | 11500 | 12400 | 900 | 68 |
| source-dropout-4 | BatteryTempStreamStale | 11500 | 12400 | 900 | - |
| source-dropout-4 | BatteryTempGenerationGap | 11500 | 12500 | 1000 | - |
| source-dropout-5 | BatteryTempStreamStale | 15000 | 15500 | 500 | -32 |
| source-dropout-5 | BatteryTempGenerationGap | 15000 | 16900 | 1900 | 63 |
| source-dropout-5 | BatteryTempStreamStale | 15000 | 16900 | 1900 | - |
| source-dropout-5 | BatteryTempGenerationGap | 15000 | 17000 | 2000 | - |

## Verdict rationale

All 16 expected Guardian change(s) matched and no unexpected change was observed.

## Observer artifacts

- Final live-observer view: [observer.html](observer.html)

Observer artifacts are illustrative only and never a source of evaluation facts.

## Gaps and limitations

- **Mitigation:** not instrumented (v1 is event-only, ADR-007) - no mitigation event is recorded; this chain link is intentionally absent.
- **OpenSOVD fault status:** only activation times are captured; the `testFailed`/`confirmedDtc`/`warningIndicator` triple is not observable.
- **Unmapped Guardian warnings:** only DFM-mapped `class/level` pairs reach the collector stream (ADR-016 section 11); utilization warnings may be invisible.

## Notes

- BatteryTempStreamStale at the end of the replay ignored (1 change(s))
